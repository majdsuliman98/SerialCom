
import RPi.GPIO as GPIO


import time


DC_MOTORS= {
"DC_1_R":9,
"DC_1_L":10,
"DC_2_R":16,
"DC_2_L":11,
"DC_3_R":21,
"DC_3_L":20
}



def control_dc_motors(DIR,motor_dir):

    # To test the value of a pin use the .input method
    
    channel_is_on = GPIO.input(DIR[motor_dir])  # Returns 0 if OFF or 1 if ON

    if channel_is_on:
        GPIO.output(DC_MOTORS[motor_dir],GPIO.LOW)
    else:

        GPIO.output(DC_MOTORS[motor_dir],GPIO.HIGH)


GPIO.setmode(GPIO.BCM)
for channel in  DC_MOTORS.values():
    GPIO.setup(channel, GPIO.OUT)
    GPIO.output(channel, GPIO.LOW)

while True:
    print(GPIO.input(DC_MOTORS["DC_3_L"]))
    time.sleep(1)
    control_dc_motors(DC_MOTORS,"DC_3_L")

