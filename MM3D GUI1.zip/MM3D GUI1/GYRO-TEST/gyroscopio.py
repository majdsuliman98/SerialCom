from mpu9250_i2c import mpu9250_i2c
import numpy as np
import csv,datetime
import time
t0 = time.time()


try:
    GYRO=mpu9250_i2c()
except:
    print('No se pudo conectar')


cal_filename = 'mpu9250_cal_params.csv'
imu_devs   = ["ACCELEROMETER","GYROSCOPE","MAGNETOMETER"]
imu_labels = ["x-dir","y-dir","z-dir"]
imu_units  = ["g","g","g","dps","dps","dps","uT","uT","uT"]
cal_offsets = np.array([[],[],[],0.0,0.0,0.0,[],[],[]]) # cal vector

print('ok')
with open(cal_filename,'r',newline='') as csvfile:
                reader = csv.reader(csvfile,delimiter=',')
                iter_ii = 0
                for row in reader:
                    if len(row)>2:
                        row_vals = [float(ii) for ii in row[int((len(row)/2)+1):]]
                        cal_offsets[iter_ii] = row_vals
                    else:
                        cal_offsets[iter_ii] = float(row[1])
                    iter_ii+=1


#>offsets

ox1=cal_offsets[0][0]
ox2=cal_offsets[0][1]
oy1=cal_offsets[1][0]
oy2=cal_offsets[1][1]
oz1=cal_offsets[2][0]
oz2=cal_offsets[2][1]
owx=cal_offsets[3]
owy=cal_offsets[4]
owz=cal_offsets[5]



while True:
    ##################################
    # Reading and Printing IMU values
    ##################################
    try:
        ax,ay,az,wx,wy,wz = GYRO.mpu6050_conv() # read and convert mpu6050 data
        mx,my,mz = GYRO.AK8963_conv() # read and convert AK8963 magnetometer data
        #mpu_array= [ax,ay,az,wx,wy,wz,mx,my,mz] 
        print("ok")
    ##Adding the offsets
        #ax=(ax*ox1)+ox2
        ay=(ay*oy1)+oy2
        az=(az*oz1)+oz2


        wx=wx-owx
        wy=wy-owy
        wz=wz-owz
        
    except:
        continue 
        

    print(50*"-")
    for imu_ii,imu_val in enumerate([ax,ay,az,wx,wy,wz,mx,my,mz]):
        if imu_ii%3==0:
            print(20*"_"+"\n"+imu_devs[int(imu_ii/3)]) # print sensor header

        print("{0}: {1:3.2f} {2}".format(imu_labels[imu_ii%3],imu_val,imu_units[imu_ii]))
        
    time.sleep(1) # wait between prints