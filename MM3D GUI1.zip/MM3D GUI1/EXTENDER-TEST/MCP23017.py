import smbus2 as smbus


class MCP23017(object):

    def __init__(self, address, outputA, outputB):
        self.bus = smbus.SMBus(1)
        self.DEVICE_ADDRESS = address
        self.BANK_A_ADDRESS = 0x12
        self.BANK_B_ADDRESS = 0x13

        if outputA:
            self.output_state_a = 0
            self.bus.write_byte_data(self.DEVICE_ADDRESS, 0x00, 0x00)   # Port A as output
            self.bus.write_byte_data(self.DEVICE_ADDRESS, self.BANK_A_ADDRESS, 0x00)   # Initialize with zeros
        else:
            self.INPUT_STATE_A = 0
            self.bus.write_byte_data(self.DEVICE_ADDRESS, 0x00, 0xFF)   # Port A as input
            # self.bus.write_byte_data(self.DEVICE_ADDRESS, 0x0c, 0xFF)   # Activate internal pullups for Port A
            self.bus.write_byte_data(self.DEVICE_ADDRESS, 0x00, 0xFF)   # Deactivate internal pullups for Port A

        if outputB:
            self.output_state_b = 0
            self.bus.write_byte_data(self.DEVICE_ADDRESS, 0x01, 0x00)   # Port B as output
            self.bus.write_byte_data(self.DEVICE_ADDRESS, self.BANK_B_ADDRESS, 0x00)   # Initialize with zeros
        else:
            self.input_state_b = 0
            self.bus.write_byte_data(self.DEVICE_ADDRESS, 0x01, 0xFF)   # Port B as input
            # self.bus.write_byte_data(self.DEVICE_ADDRESS, 0x0d, 0xFF)   # Activate internal pullups for Port B
            self.bus.write_byte_data(self.DEVICE_ADDRESS, 0x00, 0xFF)   # Activate internal pullups for Port B

    def invert_output(self, bank, bit):
        if bank == 'A' or bank == 'a':
            bank_address = self.BANK_A_ADDRESS
            output_state = self.output_state_a
        elif bank == 'B' or bank == 'b':
            bank_address = self.BANK_B_ADDRESS
            output_state = self.output_state_b
        else:
            raise ValueError('Wrong bank ID given!')

        if output_state & 2**bit:
            output_state -= 2**bit
        else:
            output_state += 2**bit

        if bank_address == self.BANK_A_ADDRESS:
            self.output_state_a = output_state
        elif bank_address == self.BANK_B_ADDRESS:
            self.output_state_b = output_state

        self.bus.write_byte_data(self.DEVICE_ADDRESS, bank_address, output_state)

    def set_output(self, bank, bit, state):
        if bank == 'A' or bank == 'a':
            bank_address = self.BANK_A_ADDRESS
            output_state = self.output_state_a
        elif bank == 'B' or bank == 'b':
            bank_address = self.BANK_B_ADDRESS
            output_state = self.output_state_b
        else:
            raise ValueError('Wrong bank ID given!')

        if output_state & 2**bit and not state:
            output_state -= 2**bit

        elif not output_state & 2**bit and state:
            output_state += 2**bit

        if bank_address == self.BANK_A_ADDRESS:
            self.output_state_a = output_state
        elif bank_address == self.BANK_B_ADDRESS:
            self.output_state_b = output_state

        self.bus.write_byte_data(self.DEVICE_ADDRESS, bank_address, output_state)

    def read_input(self, bank):
        if bank == 'A' or bank == 'a':
            bank_address = self.BANK_A_ADDRESS
        elif bank == 'B' or bank == 'b':
            bank_address = self.BANK_B_ADDRESS
        else:
            raise ValueError('Wrong bank ID given!')

        input_state = self.bus.read_byte_data(self.DEVICE_ADDRESS, bank_address)

        if bank_address == self.BANK_A_ADDRESS:
            self.INPUT_STATE_A = input_state
            return self.INPUT_STATE_A
        elif bank_address == self.BANK_B_ADDRESS:
            self.input_state_b = input_state
            return self.input_state_b

    def read_input_bit(self, bank,bit):
        value=0
        if bank == 'A' or bank == 'a':
            bank_address = self.BANK_A_ADDRESS
        elif bank == 'B' or bank == 'b':
            bank_address = self.BANK_B_ADDRESS
        else:
            raise ValueError('Wrong bank ID given!')
        input_state = self.bus.read_byte_data(self.DEVICE_ADDRESS, bank_address)
        if bank_address == self.BANK_A_ADDRESS:
            self.INPUT_STATE_A = input_state
            if self.INPUT_STATE_A & (1 << bit) != 0: value = 1
            return value
        elif bank_address == self.BANK_B_ADDRESS:
            self.input_state_b = input_state
            if self.input_state_b & (1 << bit) != 0: value = 1
            return value

    def cleanup(self):
        #Make sure the outputs registers are set to off
        self.bus.write_byte_data(self.DEVICE_ADDRESS, self.BANK_A_ADDRESS, 0x00)
        self.bus.write_byte_data(self.DEVICE_ADDRESS, self.BANK_B_ADDRESS, 0x00)




