from MCP23017 import MCP23017
import time
inicio = time.time()
adress=0x21
try:
    mcp=MCP23017(adress,outputA=False, outputB=False)
    print('Si se conecto')
except:
    print('No se pudo conectar')

# while True:
    
#     time.sleep(0.1)
#     v=mcp.read_input_bit('A',0)
#     print(str(v))


# Código a medir
while True:

    v=mcp.read_input_bit('A',7)
    print(str(v))
    time.sleep(0.2)
# -------------

# fin = time.time()
# print(fin-inicio) # 1.0005340576171875