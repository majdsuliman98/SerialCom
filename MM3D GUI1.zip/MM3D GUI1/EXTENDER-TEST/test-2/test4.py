from Adafruit_I2C import Adafruit_I2C
from MCP23017 import MCP23017

import time
#>>Adresses
MCP23017_1_ADDRESS=0x21
MCP23017_2_ADDRESS=0x22

#>>Ports
#< MCP23017_1
#OUTPUTS
OUTPUTS_MCP={
"LATCH_TOP":0,
"LATCH_BACK":1,
"LATCH_FRONT":2,
"BUZZER_OUTPUT":3,
"LED_ORANGE_OUTPUT":4,
"LED_RED_OUTPUT":5,
"LED_PANEL_OUTPUT":6,
"FAN_OUTPUT":7
}


#INPUTS
##ENDSTOPS DC

ES_DC={
"ES_DC_1_1":10,
"ES_DC_1_2":11,

"ES_DC_2_1":12,
"ES_DC_2_2":13,

"ES_DC_3_1":14,
"ES_DC_3_2":15
}


#< MCP23017_2 
# INPUTS
##ENDSTOPS STEPPERS
ES_STEPPERS={
"ES_M_1_1":7,
"ES_M_1_2":6,
"ES_M_1_3":5,

"ES_M_2_1":4,
"ES_M_2_2":3,
"ES_M_2_3":2,

"ES_M_3_1":1,
"ES_M_3_2":0,
"ES_M_4_1":15,
"ES_M_4_2":14,

"ES_M_5_1":13,
"ES_M_5_2":12,
"ES_M_5_3":11,

"ES_M_6_1":10,
"ES_M_6_2":9}

#>>RASPBERRY GPIO

DC_MOTORS= {
"DC_1_R":9,
"DC_1_L":10,
"DC_2_R":16,
"DC_2_L":11,
"DC_3_R":21,
"DC_3_L":20
}



  #  <Initialization of MCP23017



# def initialize_mcp23017(Address):
#     try:
#         if Address==MCP23017_1_ADDRESS:
#             mcp_1 = MCP23017(address=Address, num_gpios= 16)  # MCP23017
#         elif Address==MCP23017_2_ADDRESS:
#             mcp_2 = MCP23017(address=Address, num_gpios= 16)
#         else:
#             print("Unknow adress")
#     except Exception as exception:
#         print(exception)






# initialize_mcp23017(MCP23017_1_ADDRESS)
# initialize_mcp23017(MCP23017_2_ADDRESS)
# initialize_IO_mcp()

Address= MCP23017_1_ADDRESS
try:
    if Address == MCP23017_1_ADDRESS:
        mcp_1 = MCP23017(address=Address, num_gpios= 16)  # MCP23017
    elif Address == MCP23017_2_ADDRESS:
        mcp_2 = MCP23017(address=Address, num_gpios= 16)
    else:
        print("Unknow adress")
except Exception as exception:
    print(exception)

for pin in ES_STEPPERS.values():
    mcp_1.pinMode(7, mcp_1.OUTPUT)

i= 0
while i < 15:

    print(str(i), "Pin %d = %d" % (7, mcp_1.currentVal(7)))
    mcp_1.output(7,not mcp_1.currentVal(7))
    time.sleep(1)
    i += 1
