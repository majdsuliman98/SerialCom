#!/usr/bin/python
from Adafruit_I2C import Adafruit_I2C
from MCP23017 import MCP23017

import time

mcp_1 = MCP23017(address = 0x21, num_gpios = 16) # MCP23017

inpin=1
mcp_1.pinMode(inpin, mcp_1.INPUT)

ledpin=2
# mcp_1.pullUp(inpin, 0)
mcp.pinMode(ledpin, mcp.OUTPUT)
# Read input pin and display the results
#print "Pin 3 = %d" % (mcp.input(3) >> 3)
Dev={"name":'mcp_1',"pin":0}

i=0
while i<10:
	#mcp.output(ledpin, 1)  # Pin 0 High
	# time.sleep(.1)
	print(str(i),"Pin %d = %d" % (Dev["pin"], mcp_1.input(Dev["pin"])))
	# print(str(i),"Pin %d = %d" % (inpin, mcp_1.input(inpin)))
	#mcp.output(ledpin, 0)  # Pin 0 Low
	time.sleep(1)
	i+=1

print("Limpiando...")
mcp_1.cleanup()


# v=mcp_1.input(0)
# print(str(v))
# fin=time.time()

# print(str(fin-inicio))