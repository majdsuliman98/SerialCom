# > Uncomment for garbage collector output or debugging features
import gc
import ptvsd

from app import MM3DFoundry

# Notes:

# > To run the app from VSCode:
# > 1. Run "xhost +local:" command on RPi using touchscreen (otherwise
# > app will fail to start with following trace:
# > [CRITICAL] [App         ] Unable to get a Window, abort.)
# > 2. Go to app folder
# > 3. Run "DISPLAY=:0 sudo python3 main.py"
# > To take a screenshot use a "DISPLAY=:0 scrot" command.
# > The rest of the most popular commands run without "DISPLAY=:0" prefix.

# > The phone app cannot start without the API being run first.
# > Without the API started it will throw a connection error and quit.
# > The phone app enables user to check current consumable data on both
# > phone and machine, but also add consumables and, most importantly,
# > run processes. This way we can track the consumable usage and make sure
# > that user doesn't abuse the system (unless user comes up with his own
# > control system using existing hardware, which can't really be helped
# > except for the authentication system implemented on Arduinos, which is
# > the last thing that might stop somebody for abusing this thing).

# > The app used to utilize over a 100 screens, having a separate one
# > for each process step, menu and etc. I found that approach was kinda laggy
# > and I decided to move closer to SPA approach having, at most, 3 screens
# > running simultaneously. It made the code a little bit more cluttered
# > I think, even though I tried to keep it clean and properly divided.
# > But, on the other hand, the app runs better now.


if __name__ == "__main__":
    # > Uncomment to attach VSCode debugegr
    # print("Waiting for debugger attach")
    # ptvsd.enable_attach(address=('localhost', 5678), redirect_output=True)
    # ptvsd.wait_for_attach()

    # > Uncomment to get garbage collector debug output
    # gc.set_debug(gc.DEBUG_STATS)
    # gc.set_debug(gc.DEBUG_LEAK)

    application = MM3DFoundry()
    application.run()
