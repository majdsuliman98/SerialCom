import re
import numpy as np
import serial
import select
import RPi.GPIO as GPIO
import time
from threading import Thread, Event
import json

#Extenders
from Adafruit_I2C2 import Adafruit_I2C
from MCP23017 import MCP23017
from time import sleep  # time, gmtime, strftime
from functools import partial

#GYROSCPE
from mpu9250_i2c import mpu9250_i2c

import csv, datetime

from kivy.clock import Clock
from kivy.logger import Logger
from kivy.event import EventDispatcher
from kivy.properties import (
    BooleanProperty, 
    ListProperty, 
    NumericProperty, 
    OptionProperty, 
    StringProperty
  )

from Constants import (
    # FAILSAFE_TEMP_CRUCIBLE,
    # FAILSAFE_TEMP_DIES,
    FAILSAFE_TEMP_CJC,
    FAILSAFE_TEMP_AMBIENT,
    # FAILSAFE_HUMIDITY_AMBIENT,
    FAILSAFE_VALVE_CLOSE_TIME,
    WARNING_TEMP_CJC,
    WARNING_TEMP_AMBIENT,
    HYSTERESIS_TEMP_CJC,
    # HYSTERESIS_TEMP_TC,
    HYSTERESIS_TEMP_AMBIENT,
    # HYSTERESIS_HUMIDITY_AMBIENT,
    MCP23017_ADDRESS,
    MCP23017_ADDRESS_2,
    LED_BLINK_INTERVAL,
    FULL_CRUCIBLE_CAP,
    SETTINGS_FILE,
    CONSUMABES_FILE,
    CONTROL_TEMP_HYSTERESIS,
    TYPE_ID_CRUCIBLE,
    CONSUMABLES_HARDWARE_FILE
)

from Faults import (
    ERROR_ARDUINO_USB0_INIT_CONNECTION,
    ERROR_ARDUINO_USB1_INIT_CONNECTION,
    ERROR_CRUCIBLE_DISCONNECTED,
    ERROR_MCP23017_INIT_CONNECTION,
    ERROR_MPU9250_INIT_CONNECTION,
    ERROR_ARDUINO_CONTROL_RESPONSE_FAILSAFE_TRIGGER,
    # ERROR_ARDUINO_STEPPER_RESPONSE_FAILSAFE_TRIGGER,
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_1,
    ERROR_TEMPERATURE_TOO_HIGH_AMBIENT,
    # ERROR_HUMIDITY_TOO_HIGH_AMBIENT,
    ERROR_ARDUINO_CONTROL_READ,
    ERROR_ARDUINO_STEPPER_READ,
    WARNING_TEMPERATURE_HIGH_AMBIENT,
    WARNING_EMERGENCY_BUTTON,
    # WARNING_TEMP_CRUCIBLE,
    # WARNING_TEMP_DIES,
    # WARNING_TEMP_AMBIENT,
    # WARNING_HUMIDITY_AMBIENT,
    WARNING_TEMPERATURE_HIGH_CRUCIBLE_1,
    ERROR_OPEN_DOORS,
    WARNING_OPEN_DOORS,
    UNEXPECTED_FAULT,
)

from Ports import (
    DOORS_ENDSTOP_PINS,
    VALVES_ENDSTOP_PINS,
    EMERGENCY_BUTTON_PIN,
    DC_MOTORS_PINS,
    ES_STEPPERS_PINS,
    ES_DC_PINS,
    OUTPUTS_MCP_PINS,
    VALVES_PINS,
    CRUCIBLE_MICROCHIP_PIN
)
from Strings import OTHER_STRINGS


class ComplexControlManager(EventDispatcher):
    # Sensors' data properties
    # MATERIAL = OptionProperty("null",options=["al","za","null"])
    
    WEIGHT = ListProperty([0, 0, 0])
    PRESSURE = ListProperty([0, 0])
    TEMP_CJC = ListProperty([0, 0, 0, 0])
    TEMP_TC = ListProperty([0, 0, 0, 0])
    AMBIENT_TEMP = NumericProperty(0)
    AMBIENT_HUMIDITY = NumericProperty(0)
    GYRO = ListProperty([0, 0, 0, 0, 0, 0])
    # Proportional valve control value (in %)
    PROP_VALVE_CV = NumericProperty(0)
    # Process values
    REQUIRED_WATER = NumericProperty(0)
    REQUIRED_MATERIAL = NumericProperty(0)
    NAME_PROFILE = StringProperty("")
    REQUIRED_RECYCLED = NumericProperty(0)
    PERCENTAGE_RECYCLED = NumericProperty(0)
    # Used for process time countdown, unused at this moment
    # TIME = StringProperty("")
    # Contains the doors' openness states
    DOORS_OPENED = ListProperty([False, False, False]) # TOP, Right LEFT
    # The idea behind that property was to use it a way to prevent faults from
    # setting while user opens any of doors when he's prompted to do so.
    DOORS_IGNORED = ListProperty([False, False, False])
    # Contains the valves' openness states
    VALVE_ENDSTOPS = ListProperty([False, False])
    # Contains the DC ' openness states
    DC_ENDSTOPS = ListProperty([False, False, False, False, False, False])

    # Contains the Steppers ' openness states
    STEPPER_ENDSTOPS = ListProperty([False, False, False, ## (0) *ES_CR1_1, (1) ES_CR1_2, (2) ES_CR1_3
                False, False,False,                       ## (3) *ES_CR2_1, (4) ES_CR2_2, (5) ES_CR2_3
                False, False,                             ## (6) ES_Z1_1, (7) *ES_Z1_2
                False, False,                             ## (8) ES_Z2_1, (9) *ES_Z2_2
                False,False, False,                       ## (10) *ES_TR_1, (11) ES_TR_2, (12) ES_TR_3
                False, False])

    # Heating temperature setpoints
    SETPOINT_CRUCIBLE = NumericProperty(0)
    SETPOINT_DIES = NumericProperty(0)
    TEMP_CRUCIBLE = NumericProperty(0)
    # Temperature control  
    TEMP_CONTROL_ON = BooleanProperty(False)
    TEMP_CONTROL = BooleanProperty(False)
    STATE_T = BooleanProperty(False)
    # Other, informative properties
    DATA_REFRESHED_ARDUINO_CONTROL = BooleanProperty(False)

    PROCESS_IN_PROGRESS = BooleanProperty(False)
    ADD_MATERIAL = BooleanProperty(False)
    MELTING = BooleanProperty(False)
    DEGASSING = BooleanProperty(False)
    SKIMMING = BooleanProperty(False)
    CRUCIBLE_TILTED = BooleanProperty(False)
    EMERGENCY_STOP = BooleanProperty(False)
    CRUCIBLE_MICROCHIP_EN = BooleanProperty(True)

    CHANGING_HARDWARE = BooleanProperty(False)

    STEP_PROCESS = StringProperty("")
    MATERIAL = StringProperty("")

    CRUCIBLE_VOLUME = NumericProperty(100)
    CRUCIBLE_LIFESPAN = NumericProperty(0)
    NEW_VOLUME_MATERIAL = NumericProperty(0)


    def __init__(self, manager, **kwargs):
        super(ComplexControlManager, self).__init__(**kwargs)
        self.full_crucible_volume = FULL_CRUCIBLE_CAP
        self.nucleo_gcode = None
        self.mcp_1 = None 
        self.mcp_2 = None
      
# ------------------------------------------------------------------------------------------------
        # Set up LED blinking
        
# ----------------------------------------------------------------------------------------------------

    # ---------------------------------------------------------------------------- #
    #                                INITIALIZATION                                #
    # ---------------------------------------------------------------------------- #
    

    
    # ---------------------------------------------------------------------------- #
    #                                AUTHENTICATION                                #
    # ---------------------------------------------------------------------------- #

   
    # ---------------------------------------------------------------------------- #
    #                                 DATA READING                                 #
    # ---------------------------------------------------------------------------- #

    