# coding=utf-8

import sys
from kivy.app import App
from kivy.lang import Builder

# Logging is now enabled through config.ini file
# from kivy.config import Config
# Config.set('kivy', 'log_level', 'trace')  # Enable in case of hard to find bugs
# Config.set('kivy', 'log_enable', 1)
# Config.set('kivy', 'log_dir', '/home/pi/kivy/logs/')
# Config.write()

Builder.load_file("./Backgrounds.kv")
Builder.load_file("./Buttons.kv")
Builder.load_file("./DebugPositioningGrid.kv")
Builder.load_file("./Icons.kv")
Builder.load_file("./Labels.kv")
Builder.load_file("./Layouts.kv")


sys.path.append("../images")
sys.path.append("../libraries")
sys.path.append("../libraries/eeprom")
sys.path.append('./tabs')
sys.path.append('./debug')
sys.path.append('./HardwareControlUtilities')

sys.path.append("./screens/menu")
sys.path.append("./screens/menu/main")
sys.path.append("./screens/menu/preprocess")
sys.path.append("./screens/processes/investment")
sys.path.append("./screens/processes/sand")
sys.path.append("./screens/processes/die")
sys.path.append("./screens/processes/casting")

sys.path.append("../Lib")

# Import modules after appending paths they're in
import SplashScreen
import WindowManager
import RecycleViewRow
import RefLabel
import TouchRippleButton
import ProfileSelectionSpinner
import ConsumableSelectionSpinner
from SelectableLabel import SelectableRecycleGridLayout, SelectableLabel
#To implement Debug Screen

import DebugScreen2

class MM3DFoundry(App):
    def build(self):
        return Builder.load_file("WindowManager.kv")

    def on_stop(self):
        # Call on_quit functions in managers such functions are defined in
        self.root.bcm.on_quit()
        self.root.ccm.on_quit()
        self.root.hcm.on_quit()
