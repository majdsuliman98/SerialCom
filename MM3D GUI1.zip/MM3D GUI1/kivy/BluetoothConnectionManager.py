import base64
import hashlib
import json
import pexpect
import select
import threading
from bluetooth import BluetoothSocket, RFCOMM, BluetoothError

from django.utils.encoding import force_bytes, force_text
from functools import partial
from kivy.clock import Clock
from kivy.event import EventDispatcher
from kivy.logger import Logger
from kivy.properties import (
    StringProperty, 
    NumericProperty, 
    BooleanProperty, 
    ListProperty
)

from threading import Thread, Event

from Constants import CODE_SUCCESS, MACHINE_ID
from Crypto import KeyExchange
from Exceptions import NoBluetoothConnection, DataRefreshTimeout
from Faults import (
    BLUETOOTH_EOF,
    BLUETOOTH_TIMEOUT,
    BLUETOOTH_AGENT_NOT_REGISTERED,
    BLUETOOTH_AGENT_NOT_UNREGISTERED,
    BLUETOOTH_DISCOVERABLE_OFF_FAILED,
    BLUETOOTH_DISCOVERY_IN_PROGRESS,
    BLUETOOTH_UNABLE_TO_START_DISCOVERY,
    BLUETOOTH_UNABLE_TO_STOP_DISCOVERY,
    BLUETOOTH_UNABLE_TO_GET_DEVICE_LIST,
    BLUETOOTH_PAIRING_ERROR,
    BLUETOOTH_UNABLE_TO_UNPAIR,
    BLUETOOTH_UNABLE_TO_CANCEL_PAIRING,
    BLUETOOTH_CANNOT_POWER_ON,
    BLUETOOTH_CONNECTION_LOST,
    BLUETOOTH_UNABLE_TO_DISCONNECT,
    BLUETOOTH_NOT_IMPLEMENTED_ERROR,
    # BLUETOOTH_UNKNOWN_ERROR,
    # BLUETOOTH_OTHER_ERROR,
)
from Images import (
    ICON_BLUETOOTH_DISABLED,
    ICON_BLUETOOTH_ENABLED,
    ICON_BLUETOOTH_CONNECTING_1,
    ICON_BLUETOOTH_CONNECTING_2,
    ICON_BLUETOOTH_CONNECTED,
    ICON_BLUETOOTH_FAULT,
    ICON_STATUS_OFFLINE,
    ICON_STATUS_UPLOADING,
    ICON_STATUS_DOWNLOADING,
    ICON_STATUS_UP_TO_DATE,
)
from Strings import FAULTS


class BluetoothConnectionManager(EventDispatcher):
    """Manager object created in order to manage the Bluetooth connection.
    """
    bluetooth_status = StringProperty("disabled")
    bluetooth_icon_source = StringProperty("")
    bluetooth_icon_opacity = NumericProperty(1)
    bluetooth_device_list = ListProperty([])
    bluetooth_scan_state = BooleanProperty(False)
    consumables_up_to_date = BooleanProperty(False)
    data_status_icon = StringProperty(ICON_STATUS_OFFLINE)
    selected_device_name = StringProperty("")
    selected_device_address = StringProperty("")
    bluetooth_connection_required = BooleanProperty(False)
    event_data = Event()

    def __init__(self, manager, **kwargs):
        super(BluetoothConnectionManager, self).__init__(**kwargs)
        self.manager = manager
        self.bluetooth_disconnecting = False
        self.bluetooth_listen_thread = None
        self.connectionListenThread = None
        self.client_socket = None
        self.server_socket = None
        self.address = None
        self.pairing_timeout = 30
        self.selected_arduino_type = None
        self.bluetooth_connecting_icon_animation = None
        self.pairing_canceled = False
        self.change_bluetooth_icon("disabled")
        self.type_id = ""
        
        # Sometimes, when the bluetoothctl seemed to be somehow blocked/bugged
        # this part was preventing the application from starting.
        # It was waiting for the 'Agent registered' message which failed.
        # It had to be moved to a moment the gui is spawned, so it is not
        # blocking it. After that the fault can be reported and shown on popup.
        self.btctl = pexpect.spawn("bluetoothctl", encoding="utf-8", echo=False, timeout=5)
        self.btctl.delaybeforesend = 0.1
        

        # Set up the bluetoothctl manager and report faults in case they happen
        try:
            if self.btctl.expect("Agent registered"):
                # Failed
                self.bluetooth_error_callback(BLUETOOTH_AGENT_NOT_REGISTERED["code"])
                return
            else:
                # Succeeded
                pass
        except pexpect.EOF:
            self.bluetooth_eof_error_callback(BLUETOOTH_AGENT_NOT_REGISTERED["code"])
        except pexpect.TIMEOUT:
            self.bluetooth_timeout_error_callback(BLUETOOTH_AGENT_NOT_REGISTERED["code"])

        try:
            self.btctl.sendline("power on")
            if self.btctl.expect("succeeded"):
                self.bluetooth_error_callback(BLUETOOTH_CANNOT_POWER_ON["code"])
                return
            else:
                pass
        except pexpect.EOF:
            self.bluetooth_eof_error_callback(BLUETOOTH_CANNOT_POWER_ON["code"])
        except pexpect.TIMEOUT:
            self.bluetooth_timeout_error_callback(BLUETOOTH_CANNOT_POWER_ON["code"])

        try:
            self.btctl.sendline("agent off")
            if self.btctl.expect("Agent unregistered"):
                self.bluetooth_error_callback(BLUETOOTH_AGENT_NOT_UNREGISTERED["code"])
                return
            else:
                pass
        except pexpect.EOF:
            self.bluetooth_eof_error_callback(BLUETOOTH_AGENT_NOT_UNREGISTERED["code"])
        except pexpect.TIMEOUT:
            self.bluetooth_timeout_error_callback(BLUETOOTH_AGENT_NOT_UNREGISTERED["code"])

        try:
            self.btctl.sendline("agent NoInputNoOutput")
            if self.btctl.expect("Agent registered"):
                self.bluetooth_error_callback(BLUETOOTH_AGENT_NOT_REGISTERED["code"])
                return
            else:
                pass
        except pexpect.EOF:
            self.bluetooth_eof_error_callback(BLUETOOTH_AGENT_NOT_REGISTERED["code"])
        except pexpect.TIMEOUT:
            self.bluetooth_timeout_error_callback(BLUETOOTH_AGENT_NOT_REGISTERED["code"])

        try:
            self.btctl.sendline("discoverable off")
            if self.btctl.expect("Changing discoverable off succeeded"):
                self.bluetooth_error_callback(BLUETOOTH_DISCOVERABLE_OFF_FAILED["code"])
                return
            else:
                pass
        except pexpect.EOF:
            self.bluetooth_eof_error_callback(BLUETOOTH_DISCOVERABLE_OFF_FAILED["code"])
        except pexpect.TIMEOUT:
            self.bluetooth_timeout_error_callback(BLUETOOTH_DISCOVERABLE_OFF_FAILED["code"])

        self.change_bluetooth_icon("enabled")
        self.create_sockets()

# ------------------------------ ERROR CALLBACKS ----------------------------- #

    def bluetooth_error_callback(self, fault_code):
        """Called in case of not getting an expected response from btctl.

        Args:
            fault_code (int): Fault code number.
        """
        self.manager.fm.fault_states[self.manager.fm.fault_codes.index(fault_code)] = True
        Logger.exception("BCM: " + FAULTS[fault_code][self.manager.lang])
        self.change_bluetooth_icon("error")

    def bluetooth_eof_error_callback(self, fault_code):
        """Called in case of EOF response from btctl.

        Args:
            fault_code (int): Fault code number.
        """
        self.manager.fm.fault_states[self.manager.fm.fault_codes.index(BLUETOOTH_EOF["code"])] = True
        self.manager.fm.fault_states[self.manager.fm.fault_codes.index(fault_code)] = True  # <- fault_code
        Logger.exception("BCM: " + FAULTS[fault_code][self.manager.lang])
        self.change_bluetooth_icon("error")

    def bluetooth_timeout_error_callback(self, fault_code):
        """Called in case of timeout response from btctl.

        Args:
            fault_code (int): Fault code number.
        """
        self.manager.fm.fault_states[self.manager.fm.fault_codes.index(BLUETOOTH_TIMEOUT["code"])] = True
        self.manager.fm.fault_states[self.manager.fm.fault_codes.index(fault_code)] = True  # <- fault_code
        Logger.exception("BCM: " + FAULTS[fault_code][self.manager.lang])
        self.change_bluetooth_icon("error")

# ------------- FUNCTIONS RESPONSIBLE FOR ESTABLISHING CONNECTION ------------ #

    def get_and_parse_devices_list(self, *args):
        """Function responsible for requesting the Bluetooth device list and
        parsing it for display. Performs this operation in a threaded manner.
        """

        def _get_and_parse_devices_list():
            """As described above, wrapped into callable for running with
            a thread.
            """
            names = []
            addresses = []

            try:
                self.btctl.sendline("devices")
                # Expect the [bluetooth]# tag after getting the device list
                # if self.btctl.expect("bluetooth"):
                # Cut down to "#" to avoid crashes when there is [device_name]# tag.
                # This way discovery can be stopped after a connection is established.
                if self.btctl.expect("#"):
                    self.bluetooth_error_callback(BLUETOOTH_UNABLE_TO_GET_DEVICE_LIST["code"])
                else:
                    pass
            except pexpect.EOF:
                self.bluetooth_eof_error_callback(BLUETOOTH_UNABLE_TO_GET_DEVICE_LIST["code"])
            except pexpect.TIMEOUT:
                self.bluetooth_timeout_error_callback(BLUETOOTH_UNABLE_TO_GET_DEVICE_LIST["code"])

            before_list = self.btctl.before.split("\r\n")
            for item in before_list:
                # Sometimes during the scan there are other infos being printed
                # to the output. This if below checks for them and ignores them.
                if (
                    "Device" in item
                    and "RSSI" not in item
                    and "UUID" not in item
                    and "ManufacturerData" not in item
                    and "TxPower" not in item
                    and "Controller" not in item
                    and "ServicesResolved" not in item
                    and "Connected" not in item
                ):
                    subdivided_list = item.split()
                    device_index = subdivided_list.index("Device")
                    addresses.append(subdivided_list[device_index + 1])
                    names.append(subdivided_list[device_index + 2])

            sorted_list = set(sorted(zip(names, addresses), key=lambda pair: pair[0]))
            unzipped_list = list(zip(*sorted_list))
            if len(unzipped_list) > 0:
                names = unzipped_list[0]
                addresses = unzipped_list[1]
                self.bluetooth_device_list = [names, addresses]

        # Run the thread
        Thread(target=_get_and_parse_devices_list, name="Bluetooth device scan thread").start()

    def connect_to_device_by_index(self, index):
        """Function responsible for connecting to a selected Bluetooth device.
        Performs this operation in a threaded manner.
        Called by SelectableLabel Class (via thread wrapper) after the desired
        Bluetooth device is selected.

        Args:
            index (int): Index of a device to connect to
        """
        def _connect_to_device_by_index(index):
            """As described above, wrapped into callable for running with
            a thread.
            """
            self.scan_off()
            Clock.schedule_once(self.manager.tpm.bluetooth_tab.pair_device_view)

            try:
                self.selected_device_name = self.bluetooth_device_list[0][index]
                self.selected_device_address = self.bluetooth_device_list[1][index]
                self.btctl.sendline("pair " + self.bluetooth_device_list[1][index])
                if self.btctl.expect("Attempting to pair"):
                    self.bluetooth_error_callback(BLUETOOTH_PAIRING_ERROR["code"])
                    return
                else:
                    bluetooth_tab = self.manager.tpm.bluetooth_tab
                    Clock.schedule_once(bluetooth_tab.pair_device_countdown_view)
                    self.pairing_countdown = Clock.schedule_interval(bluetooth_tab.pair_device_countdown_view, 1)
            except pexpect.EOF:
                self.bluetooth_eof_error_callback(BLUETOOTH_PAIRING_ERROR["code"])
            except pexpect.TIMEOUT:
                self.bluetooth_timeout_error_callback(BLUETOOTH_PAIRING_ERROR["code"])

            Logger.debug("bluetoothctl: " + str(self.btctl.after))

            # TODO: handling the timeout exception
            try:
                result = self.btctl.expect(["Pairing successful", "AlreadyExists"], timeout=self.pairing_timeout + 1)
                if result == 0:
                    Clock.schedule_once(self.manager.tpm.bluetooth_tab.success_view)
                elif result == 1:
                    Clock.schedule_once(self.manager.tpm.bluetooth_tab.already_paired_view)
                else:
                    pass
            except pexpect.EOF:
                self.bluetooth_eof_error_callback(BLUETOOTH_PAIRING_ERROR["code"])
            except pexpect.TIMEOUT:
                if self.pairing_canceled:
                    pass
                else:
                    pass
                    # self.bluetooth_timeout_error_callback(BLUETOOTH_PAIRING_ERROR)
            finally:
                Clock.unschedule(self.pairing_countdown)

            Logger.debug("bluetoothctl: " + str(self.btctl.after))

        # Run the thread
        Thread(target=_connect_to_device_by_index, args=(index,), name="Bluetooth connect to device thread").start()

    def unpair_device(self, *args):
        """Function responsible for unpairing a selected Bluetooth device.
        Performs this operation in a threaded manner.
        """

        def _unpair_device(*args):
            """As described above, wrapped into callable for running with
            a thread.
            """
            states = self.manager.fm.fault_states
            codes = self.manager.fm.fault_codes

            try:
                self.btctl.sendline("remove " + self.selected_device_address)
                expected = self.btctl.expect(["removed", "available"])
                if expected == 0:
                    Clock.schedule_once(self.manager.tpm.bluetooth_tab.success_view)
                elif expected == 1:
                    states[codes.index(BLUETOOTH_UNABLE_TO_UNPAIR["code"])] = True
                else:
                    states[codes.index(BLUETOOTH_UNABLE_TO_UNPAIR["code"])] = True
            except pexpect.EOF:
                self.bluetooth_eof_error_callback(BLUETOOTH_UNABLE_TO_UNPAIR["code"])
            except pexpect.TIMEOUT:
                self.bluetooth_timeout_error_callback(BLUETOOTH_UNABLE_TO_UNPAIR["code"])

            Logger.debug("bluetoothctl: " + str(self.btctl.after))

        # Run the thread
        Thread(target=_unpair_device, name="Bluetooth unpair device thread").start()

    def scan_on(self, *args):
        """Function responsible for starting scanning for Bluetooth devices.
        Performs this operation in a threaded manner.
        """

        def _scan_on():
            """As described above, wrapped into callable for running with
            a thread.
            """
            states = self.manager.fm.fault_states
            codes = self.manager.fm.fault_codes
            self.bluetooth_device_list = []

            try:
                self.btctl.sendline("scan on")
                expected = self.btctl.expect(["Discovery started", "InProgress"])
                if expected == 0:
                    self.bluetooth_scan_state = True
                elif expected == 1:  # Failed to start discovery: org.bluez.Error.InProgress
                    states[codes.index(BLUETOOTH_DISCOVERY_IN_PROGRESS["code"])] = True
                else:
                    states[codes.index(BLUETOOTH_UNABLE_TO_START_DISCOVERY["code"])] = True
            except pexpect.EOF:
                self.bluetooth_eof_error_callback(BLUETOOTH_UNABLE_TO_START_DISCOVERY["code"])
            except pexpect.TIMEOUT:
                self.bluetooth_timeout_error_callback(BLUETOOTH_UNABLE_TO_START_DISCOVERY["code"])

            Logger.debug("bluetoothctl: " + str(self.btctl.after))

            self.device_update = Clock.schedule_interval(self.get_and_parse_devices_list, 2)
            self.device_update_timeout = Clock.schedule_once(self.scan_off, 30)

        # Run the thread
        Thread(target=_scan_on, name="Bluetooth scan on thread").start()

    def scan_off(self, *args):
        """Function responsible for stopping scanning for Bluetooth devices.
        Performs this operation in a threaded manner.
        """

        def _scan_off(*args):
            """As described above, wrapped into callable for running with
            a thread.
            """
            # Prevent stopping already stopped device discovery which would produce an error
            if self.bluetooth_scan_state is True:
                try:
                    self.btctl.sendline("scan off")
                    if self.btctl.expect("Discovery stopped"):
                        self.bluetooth_error_callback(BLUETOOTH_UNABLE_TO_STOP_DISCOVERY["code"])
                    else:
                        pass
                except pexpect.EOF:
                    self.bluetooth_eof_error_callback(BLUETOOTH_UNABLE_TO_STOP_DISCOVERY["code"])
                except pexpect.TIMEOUT:
                    self.bluetooth_timeout_error_callback(BLUETOOTH_UNABLE_TO_STOP_DISCOVERY["code"])
                finally:
                    self.bluetooth_scan_state = False
                    Clock.unschedule(self.device_update)
                    Clock.unschedule(self.device_update_timeout)

                Logger.debug("bluetoothctl: " + str(self.btctl.after))

        # Run the thread
        Thread(target=_scan_off, name="Bluetooth scan off thread").start()

    def cancel_pairing(self, *args):
        """Function responsible for cancelling pairing with the currently
        selected device. Performs this operation in a threaded manner.
        """

        def _cancel_pairing(*args):
            """As described above, wrapped into callable for running with
            a thread.
            """
            states = self.manager.fm.fault_states
            codes = self.manager.fm.fault_codes

            try:
                self.btctl.sendline("remove " + self.selected_device_address)
                expected = self.btctl.expect(["AuthenticationCanceled", "ConnectionAttemptFailed", "removed"])
                if expected == 0 or expected == 1 or expected == 2:
                    # self.pairing_canceled = True
                    Clock.schedule_once(self.manager.tpm.bluetooth_tab.pairing_canceled_view)
                else:
                    states[codes.index(BLUETOOTH_UNABLE_TO_CANCEL_PAIRING["code"])] = True
            except pexpect.EOF:
                self.bluetooth_eof_error_callback(BLUETOOTH_UNABLE_TO_CANCEL_PAIRING["code"])
            except pexpect.TIMEOUT:
                # Trying to remove a device once again seems to do the trick and prevent timeouts
                # TODO: exception handling & moving the connection-related functions (with expects) into threads (they block UI)
                try:
                    self.btctl.sendline("remove " + self.selected_device_address)
                    expected = self.btctl.expect(["AuthenticationCanceled", "ConnectionAttemptFailed", "removed"])
                    if expected == 0 or expected == 1 or expected == 2:
                        # self.pairing_canceled = True
                        Clock.schedule_once(self.manager.tpm.bluetooth_tab.pairing_canceled_view)
                    else:
                        states[codes.index(BLUETOOTH_UNABLE_TO_CANCEL_PAIRING["code"])] = True
                except pexpect.EOF:
                    self.bluetooth_eof_error_callback(BLUETOOTH_UNABLE_TO_CANCEL_PAIRING["code"])
                except pexpect.TIMEOUT:
                    self.bluetooth_timeout_error_callback(BLUETOOTH_UNABLE_TO_CANCEL_PAIRING["code"])
                # self.bluetooth_timeout_error_callback(BLUETOOTH_UNABLE_TO_CANCEL_PAIRING)
            finally:
                self.pairing_canceled = True  # kinda unsure about this, what will happen in case of an exception?
                Clock.unschedule(self.pairing_countdown)

            Logger.debug("bluetoothctl: " + str(self.btctl.after))

        # Run the thread
        Thread(target=_cancel_pairing, name="Bluetooth cancel pairing thread").start()

    def disconnect(self, *args):
        """Function responsible for disconnecting from currently connected
        device. Performs this operation in a threaded manner.
        """

        def _disconnect(*args):
            """As described above, wrapped into callable for running with
            a thread.
            """
            try:
                states = self.manager.fm.fault_states
                codes = self.manager.fm.fault_codes.index
                self.bluetooth_disconnecting = True
                Clock.schedule_once(self.manager.tpm.bluetooth_tab.disconnecting_device_view)
                self.btctl.sendline("disconnect " + self.selected_device_address)
                expected = self.btctl.expect(["Successful", "available"], timeout=15)
                if expected == 0:
                    Clock.schedule_once(self.manager.tpm.bluetooth_tab.success_view)
                elif expected == 1:
                    states[codes(BLUETOOTH_UNABLE_TO_DISCONNECT["code"])] = True
                else:
                    states[codes(BLUETOOTH_UNABLE_TO_DISCONNECT["code"])] = True
            except pexpect.EOF:
                self.bluetooth_eof_error_callback(BLUETOOTH_UNABLE_TO_DISCONNECT["code"])
            except pexpect.TIMEOUT:
                self.bluetooth_timeout_error_callback(BLUETOOTH_UNABLE_TO_DISCONNECT["code"])

            Logger.debug("bluetoothctl: " + str(self.btctl.after))

        # Run the thread
        Thread(target=_disconnect, name="Bluetooth disconnect device thread").start()

    def scan_for_bluetooth_devices(self):
        """Simply starts the Bluetooth scan and sets an appropriate Bluetooth
        state.
        """
        if not self.bluetooth_scan_state:
            self.bluetooth_scan_state = True
            self.scan_on()

    def create_sockets(self):
        """Function responsible for constant creation of Bluetooth sockets
        the mobile app might connect to. Performs this operation in a threaded
        manner.
        """
        def _create_sockets():
            """As described above, wrapped into callable for running with
            a thread.
            """
        
            self.server_socket = BluetoothSocket(RFCOMM)
            self.server_socket.bind(("", 0))  # (address, port), 0 for any port, works only on 1 anyway
            self.server_socket.listen(1)  # backlog=1, number of pending connections the queue will hold
            self.server_socket.settimeout(1)  # Set timeout for making it possible to join this method's thread on exit
            self.accept_connections = True
  
            
            while self.accept_connections and self.address is None:
                try:
                    self.client_socket, self.address = self.server_socket.accept()
                    # print(self.address)
                except BluetoothError:
                    # print("No socket")
                    pass
                    # Do nothing, exceptions are thrown here after there is no
                    # connection established. Ignore them to allow next connection
                    # try to happen.
                    # Exceptions that are thrown here:
                    #    _bluetooth.timeout: timed out
                    #    bluetooth.btcommon.BluetoothError: timed out

            if self.address is not None:
                Clock.schedule_once(self.bluetooth_listen)
                # print("listen")

        # Run the thread
        self.create_sockets_thread = Thread(target=_create_sockets, name="Create Bluetooth sockets thread")
        self.create_sockets_thread.start()

    def bluetooth_listen(self, *args):
        """Function responsible for performing the handshake and key exchange
        with a currently connected device. After successful performance of
        these operations it listens for incoming data. Performs all these
        operations in a threaded manner.
        """

        def _bluetooth_listen():
            """As described above, wrapped into callable for running with
            a thread.
            """
            # Note: Probably sending some commands to the mobile app could be
            # > done more elegantly, like by sending them as JSON formatted
            # > strings or whatnot instead of "ok;pi_id" type of messages.
            # > But that's a thing for the future.

            self.change_bluetooth_icon("connecting")
            retry_limit = 3
            retries = 0
            self.timeout = 5
            piid = self.manager.dm.get_piid()
            self.waitForHandshake = True
            self.waitForKeyExchange = True
            self.waitForConfirmation = True
            self.waitForNewcomingData = True

            # > Handshake schema:
            # >     data[0] - Raspberry Pi UID
            # >     data[1] - Connected device name
            # >     data[2] - Android / iOS app version
            # >     data[3] - RPi app version (update indicator)
            # >     data[4] - Critical update indicator

            self.client_socket.setblocking(0)


            # Firstly, wait for handshake from mobile app
            while self.waitForHandshake:
                Logger.debug("BCM: Waiting for handshake from the app")
                # print(piid)
                try:
                    ready, _, _ = select.select([self.client_socket], [], [], self.timeout)
        
                    if ready:
                        try:
                            
                            raw_data = self.client_socket.recv(256).decode("utf-8")
                            data = raw_data.rstrip("\n").split(";")
                            # print(data)
                            
                        except Exception as exception:
                            Logger.debug("BCM: Failed to parse/receive handshake: " + str(exception))
                            #It is to avoid bug
                            self.close_connection()
                            self.waitForHandshake = False
                            self.waitForKeyExchange = False
                            self.waitForConfirmation = False
                            self.waitForNewcomingData = False
                            self.create_sockets()
                        else:
                            if data[0] == piid:
                                Logger.debug("BCM: Got handshake message from the app: {}".format(data))
                                self.waitForHandshake = False
                    else:
                        data = ""
                        if retries < retry_limit:
                            retries += 1
                        else:
                            Logger.debug("BCM/self.waitForHandshake: Retry amount reached, closing connection")
                            self.close_connection()
                            self.create_sockets()
                            return
                except ValueError as exception:
                    Logger.error("BCM: " + str(exception))

            # Secondly, send "okay" message and then wait for and handle key exchange
            while self.waitForKeyExchange:
                Logger.debug("BCM: Sending 'okay' message to the app")
                self.send_data_unsigned("ok;" + piid)
                Logger.debug("BCM: Waiting for key exchange data")
                ready, _, _ = select.select([self.client_socket], [], [], self.timeout)
                if ready:
                    try:
                        data = json.loads(self.client_socket.recv(256).decode("utf-8"))
                    except Exception as exception:
                        Logger.debug("BCM: Failed to parse/receive key exchange data: " + str(exception))
                    else:
                        if data["code"] != CODE_SUCCESS:
                            Logger.debug("BCM: Key exchange failed")
                            self.close_connection()
                            self.waitForConfirmation = False
                            self.waitForNewcomingData = False
                            self.create_sockets()
                            return
                        else:
                            self.ke = KeyExchange()
                            self.send_data_unsigned("key;" + self.ke.begin_key_exchange())
                            self.ke.finish_key_exchange(piid, data["peer_public_key"], data["salt"])
                            self.waitForKeyExchange = False
                  
                else:
                    data = ""
                    if retries < retry_limit:
                        retries += 1
                    else:
                        Logger.debug("BCM/self.waitForKeyExchange: Retry amount reached, closing connection")
                        self.close_connection()
                        self.waitForConfirmation = False
                        self.waitForNewcomingData = False
                        self.create_sockets()
                        return

            # Thirdly, wait for confirmation from API that it accepted the sent key
            while self.waitForConfirmation:
                ready, _, _ = select.select([self.client_socket], [], [], self.timeout)
                if ready:
                    try:
                        data = json.loads(self.client_socket.recv(256).decode("utf-8"))
                        # print(data)
                    except Exception as exception:
                        Logger.debug("BCM: Failed to parse/receive confirmation data: " + str(exception))
                    else:
                        if data["code"] != CODE_SUCCESS:
                            Logger.debug("BCM: Key exchange failed")
                            self.close_connection()
                            self.create_sockets()
                            return  # break
                        else:
                            self.waitForConfirmation = False
                            self.change_bluetooth_icon("connected")
                            # try:
                            #     event = self.request_consumable_list()
                            #     refresh_result = event.wait(5)
                                
                            #     if not refresh_result:
                            #         raise DataRefreshTimeout

                            # except DataRefreshTimeout:
                            #     Logger.debug("Bluetooth data get timed out, reading consumable data from locally stored file only")

                            # except NoBluetoothConnection:
                            #     Logger.debug("Bluetooth connection unavailable, reading consumable data from locally stored file only")


                else:
                    data = ""
                    if retries < retry_limit:
                        retries += 1
                    else:
                        Logger.debug("BCM/self.waitForConfirmation: Retry amount reached, closing connection")
                        self.close_connection()
                        self.create_sockets()
                        return  # break

            # Lastly, wait for any incoming data during later application runtime
            # TODO: Finishing of parsing of the incoming data
            data_raw = ""

            # Get connected device name:
            self.btctl.sendline("info " + str(self.client_socket.getpeername()[0]))
            try:
                if self.btctl.expect("Device " + str(self.client_socket.getpeername()[0])):
                    self.bluetooth_error_callback(BLUETOOTH_NOT_IMPLEMENTED_ERROR["code"])
                    return
                else:
                    if self.btctl.expect("Alias: "):
                        pass
                    else:
                        self.selected_device_name = self.btctl.readline()

            except pexpect.EOF:
                self.bluetooth_eof_error_callback(BLUETOOTH_NOT_IMPLEMENTED_ERROR["code"])
            except pexpect.TIMEOUT:
                self.bluetooth_timeout_error_callback(BLUETOOTH_NOT_IMPLEMENTED_ERROR["code"])

            self.selected_device_address = str(self.address[0])

            # Test Arduino Auth:
            self.request_arduino_authentication("0")
            #Clock.schedule_once(partial(self.request_arduino_authentication, "1"), 2)

            while self.waitForNewcomingData:
                # Logger.debug("BCM: Waiting for data")
                try:
                    try:
                        ready, _, _ = select.select([self.client_socket], [], [], self.timeout)

                    except ValueError as exception:
                        # self.waitForNewcomingData = False
                        Logger.exception("BCM: Nonexistent socket passed to select()")
                        # return
                        raise BluetoothError from exception

                    if ready:
                        try:
                            # Can't read more than 990 bytes at once
                            if data_raw == "":
                                data_raw = self.client_socket.recv(990).decode("utf-8")
                            else:
                                data_raw += self.client_socket.recv(990).decode("utf-8")
                            # print(data_raw)

                        except BluetoothError:
                            if not self.bluetooth_disconnecting:
                                states = self.manager.fm.fault_states
                                codes = self.manager.fm.fault_codes
                                states[codes.index(BLUETOOTH_CONNECTION_LOST["code"])] = True
                            else:
                                self.bluetooth_disconnecting = False

                            if self.bluetooth_connection_required:
                                self.manager.tpm.add_tab('confirmation')
                            else:
                                pass

                            raise BluetoothError from None  # Suppress chain exceptions

                        else:
                            try:
                                data = data_raw.split(";")
                                if data[0] == "request_consumable_list":
                                    digest = hashlib.md5(data[2].encode('utf-8')).digest()
                                    # Check if hashes are the same. If not then
                                    # it means that the transmission has not
                                    # ended yet (because of the 990 bytes limit)
                                    # or it means it was faulty.
                                    # > Request consumable schema:
                                    # >     data[0] - Request
                                    # >     data[1] - Digest
                                    # >     data[2] - Data
                            
                                    if data[1].strip() != force_text(base64.urlsafe_b64encode(force_bytes(digest))):
                                        print("continue")
                                        continue  # Continue reading
                                    else:
                                        try:
                                            json.loads(data[2])  # Check if JSON is valid

                                        except json.JSONDecodeError as exception:
                                            Logger.exception("BCM: " + str(exception))

                                # TODO: Proper exception handling
                                elif data[0] == "request_arduino_authentication":
                                    _json = None
                                    try:
                                        _json = json.loads(data[1])
                                    except Exception as exception:
                                        print(str(exception))
                                    else:
                                        if _json["status"] == "success":
                                            self.parse_arduino_authentication(data[1])
                                        else:
                                            pass  # TODO: exception handling

                            except ValueError as exception:
                                Logger.exception("BCM: " + str(exception))
                                pass  # Continue reading to get full JSON

                            else:
                                Logger.debug("BCM: Received: {} ".format(data_raw))
                                if data[0] == "request_consumable_list":
                                    self.parse_consumable_list(data[2])
                                if data[0] == "request_material_list":
                                    self.parse_material_list(data[2])
                                # # TODO: Proper exception handling
                                # elif data[0] == "request_arduino_authentication":
                                #     if data[1] == "error_not_found":
                                #         pass
                                #     elif data[1] == "error_multiple_found":
                                #         pass
                                #     elif data[1] == "error_other":
                                #         pass
                                #     else:
                                #         self.parse_arduino_authentication(data[1])

                                # TODO: Proper exception handling
                                elif data[0] == "request_consumable_removal":
                                    if data[1] == "success":
                                        # self.manager.get_screen("main").begin_consumable_data_reading_thread(1)
                                        # self.manager.dm.update_data()
                                        if  self.manager.get_screen("main").current_screen == "crucibles":
                                            self.manager.get_screen("main").crucibles_screen()
                                        elif self.manager.get_screen("main").current_screen == "nozzles":
                                            self.manager.get_screen("main").nozzles_screen()
                                        elif self.manager.get_screen("main").current_screen == "skimmers":
                                            self.manager.get_screen("main").skimmer_screen()
                                        elif self.manager.get_screen("main").current_screen == "materials":
                                            self.manager.get_screen("main").casting_materials_screen()
                                        else: pass
                                        pass  # refresh consumable list
                                    elif data[1] == "error_key_exchange_not_done":
                                        pass  # redo key exchange
                                    elif data[1] == "error_other":
                                        pass  # other server-side error
                                    else:
                                        pass  # unknown error

                                if data[0] == "start_process"and self.manager.ccm.STEP_PROCESS == "waiting":
                                    self.manager.get_screen("MetalCastingProcess").transition_start()
                                    Logger.info("BCM: Bluetooth signal start_ process received")

                                elif data[0] == "stop_process" and self.manager.ccm.STEP_PROCESS == "pouring":
                                    self.manager.get_screen("MetalCastingProcess").transition_finish()
                                    Logger.info("BCM: Bluetooth signal stop_ process received")

                                elif data[0] == "update_data_request":
                                    try:
                                        self.share_process_data()
                                    except Exception as exception:
                                        #todo: ADD ACTION WHAT TO DO WHEN THERE IS NO BLUETOOTH CONECTION
                                        Logger.exception("BCM: No connection present to share process data")
                                data_raw = ""
                    else:
                        data_raw = ""

                except BluetoothError as exception:
                    Logger.exception("BCM: " + "BluetoothError risen. Connection lost. " + str(exception))
                    self.close_connection()
                    self.waitForHandshake = False
                    self.waitForKeyExchange = False
                    self.waitForConfirmation = False
                    self.waitForNewcomingData = False
                    self.create_sockets()

                # Logger.debug("BCM: Received: {}".format(self.data_raw))

        self.bluetooth_listen_event = Event()
        self.bluetooth_listen_thread = Thread(target=_bluetooth_listen, name="Bluetooth listening thread")
        self.bluetooth_listen_thread.start()

    def close_connection(self):
        """Wrapper function for closing bluetooth connections and sockets.
        """
        try:
            if self.client_socket is not None:
                self.client_socket.close()
        except Exception as exception:
            Logger.exception("BCM: " + str(exception))

        try:
            if self.server_socket is not None:
                self.server_socket.close()
        except Exception as exception:
            Logger.exception("BCM: " + str(exception))

        self.change_bluetooth_icon("enabled")
        self.server_socket = None
        self.client_socket = None
        self.address = None

# -------------------------- DATA EXCHANGE FUNCTIONS ------------------------- #

    def send_data_unsigned(self, data):
        """Send plain (unsigned) data through Bluetooth connection.

        Args:
            data (string): Data string meant to be sent to the mobile app
        """
        if self.client_socket is not None and data is not None:
            self.client_socket.send(data)

    def send_data_signed(self, data):
        """Send data signed with X25519 key through Bluetooth connection.

        Args:
            data (string): Data string meant to be sent to the mobile app
        """
        if self.client_socket is not None and data is not None:
            try:
                signature = self.ke.sign(data)
                Logger.debug("BCM: " + data)
            except Exception as exception:
                Logger.exception("BCM: write_data_signed(): " + str(exception))
            else:
                self.client_socket.send(data + ";" + signature)

    def request_arduino_authentication(self, arduino_type, dt=None):
        """Sends the Arduino authentication request to the mobile app which
        sends it to the API.

        Args:
            arduino_type (int): 0 or 1, accordingly.
            dt (float, optional): Kivy Clock schedule time. Defaults to None.

        Raises:
            NoBluetoothConnection: Risen when there is no Bluetooth connection
            available.

        Returns:
            event: If requested by call without using kivy.Clock (external)
            return event which will notify about data received with Bluetooth.
        """
        if arduino_type == "0":
            self.selected_arduino_type = "control"
        else:
            self.selected_arduino_type = "stepper"

        if self.client_socket is not None:
            # self.data_status_icon = '../images/downloading.png'
            self.send_data_signed("request_arduino_authentication;" + str(MACHINE_ID) + ";" + arduino_type)
            Logger.debug("BCM: request_arduino_authentication sent")
        else:
            raise NoBluetoothConnection
            # self.data_status_icon = '../images/offline.png'
            Logger.exception("BCM: No connection present")

        if dt is None:
            return self.bluetooth_listen_event

    def parse_arduino_authentication(self, data):
        """Loads the authentication data to JSON, replaces the ":" placed
        in it instead of ";" and calls the CCM's method to start the auth.

        Args:
            data (string): Arduino aithentication data.
        """
        _json = json.loads(data)
        self.manager.ccm.arduino_authentication(
            _json["data"].replace(":", ";"), self.manager.ccm.arduino_type[self.selected_arduino_type]
        )

    def request_consumable_list(self, dt=None):
        """Requests consumable list update by providing the request name
        and this machine's ID.

        Args:
            dt (float, optional): Kivy Clock schedule time. Defaults to None.

        Raises:
            NoBluetoothConnection: Risen when there is no Bluetooth connection
            available.

        Returns:
            event: If requested by call without using kivy.Clock (external)
            return event which will notify about data received with Bluetooth.
        """
        # if dt is not None:
        if self.client_socket is not None:
            self.data_status_icon = ICON_STATUS_DOWNLOADING
            self.send_data_signed("request_consumable_list;" + str(MACHINE_ID))
            Logger.debug("BCM: request_consumable_list sent")
            self.event_data = threading.Event()
        else:
            raise NoBluetoothConnection
            self.data_status_icon = ICON_STATUS_OFFLINE
            Logger.exception("BCM: No connection present")

        if dt is None:  # else:
            return self.bluetooth_listen_event

    def request_update_material(self, consumable_key, amount, dt=None):
        # if dt is not None:
        if self.client_socket is not None:
            self.data_status_icon = ICON_STATUS_DOWNLOADING
            self.send_data_signed("request_update_material;" + consumable_key + ";" + str(amount)+ ";"+str(MACHINE_ID))
            Logger.debug("BCM: request_update_material sent")
            self.event_data = threading.Event()
        else:
            raise NoBluetoothConnection
            self.data_status_icon = ICON_STATUS_OFFLINE
            Logger.exception("BCM: No connection present")

        if dt is None:  # else:
            return self.bluetooth_listen_event

    def share_process_data(self, dt=None):
        # > Request consumable schema:3
        # >     data[0] - request
        # >     data[1] - Machine ID
        # >     data[2] - Material
        # >     data[3] - Temp set point
        # >     data[4] - Temp
        # >     data[5] - Step
        # >     data[6] - Volume

        material = self.manager.ccm.MATERIAL
        temp_setpoint = self.manager.ccm.SETPOINT_CRUCIBLE
        temp = self.manager.ccm.TEMP_CRUCIBLE
        step = self.manager.ccm.STEP_PROCESS
        volume = self.manager.ccm.CRUCIBLE_VOLUME

        if self.client_socket is not None:
            self.send_data_unsigned("share_process_data;"+ str(MACHINE_ID) + ";" + material + ";" + str(round(temp_setpoint)) + ";" + str(round(temp)) + ";" + step + ";" + str(volume))
            Logger.debug("BCM: share_process_data sent")
        else:
            raise NoBluetoothConnection
            Logger.exception("BCM: No connection present to share process data")

        if dt is None:
            return self.bluetooth_listen_event

    def parse_consumable_list(self, data):
        """Called when a consumable list data arrives. Requests parsing of it
        from DataManager and if it succeeds it sets the listening event and
        changes the data status icon to indicate that the data is up to date.

        Args:
            data (string): Consumable list data (JSON).
        """
        try:
            self.manager.dm.parse_loaded_data(json.loads(data), False)
        except Exception as exception:
            Logger.exception("BCM: " + str(exception))
        else:
            
            self.bluetooth_listen_event.set()
            self.consumables_up_to_date = True
            self.data_status_icon = ICON_STATUS_UP_TO_DATE

    def request_consumable_removal(self, serial_id, dt=None):
        """Sends a request to the API to set REMOVED flag of a consumable to 1.
        This flag prevents the consumable from being shown and used in
        furnace's system.

        Args:
            serial_id (string): Serial UID of a consumable to remove.
            dt (float, optional): Kivy Clock schedule time. Defaults to None.

        Raises:
            NoBluetoothConnection: Risen when there is no Bluetooth connection
            available.

        Returns:
            event: If requested by call without using kivy.Clock (external)
            return event which will notify about data received with Bluetooth.
        """
        # if dt is not None:
        if self.client_socket is not None:
            self.data_status_icon = ICON_STATUS_UPLOADING
            self.send_data_signed("request_consumable_removal;" + str(MACHINE_ID) + ";" + serial_id)
            
            Logger.debug("BCM: request_consumable_removal sent")
        else:
            raise NoBluetoothConnection
            self.data_status_icon = ICON_STATUS_OFFLINE
            Logger.exception("BCM: No connection present")

        if dt is None:  # else:
            return self.bluetooth_listen_event

# ------------------------------ OTHER FUNCTIONS ----------------------------- #

    def change_bluetooth_icon(self, status):
        """Function responsible for changing the Bluetooth icon basing on its
        current state.

        Args:
            status (string): Current bluetooth status (disabled / enabled / connecting / connected)
        """
        def _change_bluetooth_icon(path, *args):
            """Changes currently shown Bluetooth icon to the one passed as path parameter.

            Args:
                path (string): Path to icon that has to be set
                dt (float): Time between calling schedule_once and calling this function
            """
            self.bluetooth_icon_source = path

        def _bluetooth_icon_connecting_switch(*args):
            """Changes currently shown Bluetooth icon during connecting state.

            Args:
                dt (float): Time between frame changes (passed by Clock.schedule_interval)
            """
            if self.bluetooth_icon_source == ICON_BLUETOOTH_ENABLED:
                self.bluetooth_icon_source = ICON_BLUETOOTH_CONNECTING_1
            elif self.bluetooth_icon_source == ICON_BLUETOOTH_CONNECTING_1:
                self.bluetooth_icon_source = ICON_BLUETOOTH_CONNECTING_2
            elif self.bluetooth_icon_source == ICON_BLUETOOTH_CONNECTING_2:
                self.bluetooth_icon_source = ICON_BLUETOOTH_ENABLED

        path = ""
        self.bluetooth_status = status
        if status == "disabled":
            path = ICON_BLUETOOTH_DISABLED
        elif status == "enabled":
            path = ICON_BLUETOOTH_ENABLED
        elif status == "connected":
            path = ICON_BLUETOOTH_CONNECTED
        elif status == "fault":
            path = ICON_BLUETOOTH_FAULT
        elif status == "error":
            path = ICON_BLUETOOTH_FAULT
        elif status == "warning":
            path = ICON_BLUETOOTH_FAULT

        if status != "connecting":
            if self.bluetooth_connecting_icon_animation is not None:
                Clock.unschedule(self.bluetooth_connecting_icon_animation)
            Clock.schedule_once(partial(_change_bluetooth_icon, path))
        else:
            self.bluetooth_connecting_icon_animation = Clock.schedule_interval(_bluetooth_icon_connecting_switch, 0.4)

    def on_quit(self):
        """Bluetooth connection cleanup called when the application quits.
        """
        Logger.debug("BCM: Cleanup in progress")

        if self.create_sockets_thread is not None:
            if self.server_socket is not None:
                self.server_socket.settimeout(0.1)
            self.accept_connections = False
            self.create_sockets_thread.join()

        if self.bluetooth_listen_thread is not None:
            self.waitForHandshake = False
            self.waitForKeyExchange = False
            self.waitForConfirmation = False
            self.waitForNewcomingData = False
            self.bluetooth_listen_thread.join()

        self.btctl.sendline("exit")
        self.close_connection()
