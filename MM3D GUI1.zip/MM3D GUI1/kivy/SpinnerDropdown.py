from kivy.lang import Builder
from kivy.uix.dropdown import DropDown

Builder.load_file("SpinnerDropdown.kv")


class SpinnerDropdown(DropDown):
    """Custom DropDown implementation for applying own style defined
    in the file loaded with Builder.
    """
    pass
