from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.logger import Logger
from kivy.uix.modalview import ModalView
from kivy.properties import ObjectProperty, ListProperty, NumericProperty, BooleanProperty, StringProperty

from BluetoothTab import BluetoothTab
from ConfirmationTab import ConfirmationTab
from InfoTab import InfoTab
from StatusTab import StatusTab
# from VideoFeedTab import VideoFeedTab

from Buttons import (
    calculate_button_inner_layout,
    calculate_two_button_layout_tab,
    unbind_all_callbacks,
)
from Faults import BLUETOOTH_CONNECTION_LOST
from Images import (
    BUTTON_ICON_TURN_VIDEOFEED_OFF,
    BUTTON_ICON_TURN_VIDEOFEED_ON,
)
from Strings import TAB_NAMES, TAB_TITLES

Builder.load_file("./TabbedPopupManager.kv")

class TabbedPopupManager(ModalView):
    """An implementation which brings a popup with multiple tabs to life.
    """
    title = ObjectProperty(None)
    camera_feed_icon = ObjectProperty(None)
    camera_feed_button = ObjectProperty(None)
    minimize_button_icon = ObjectProperty(None)
    minimize_button = ObjectProperty(None)
    close_button_icon = ObjectProperty(None)
    close_button = ObjectProperty(None)
    tabbed_panel = ObjectProperty(None)
    button_layout_1 = ObjectProperty(None)
    button_layout_2 = ObjectProperty(None)
    button_1_left_end = ObjectProperty(None)
    button_1_middle = ObjectProperty(None)
    button_1_right_end = ObjectProperty(None)
    button_1_icon = ObjectProperty(None)
    button_1_label = ObjectProperty(None)
    button_1_area = ObjectProperty(None)
    button_2_left_end = ObjectProperty(None)
    button_2_middle = ObjectProperty(None)
    button_2_right_end = ObjectProperty(None)
    button_2_icon = ObjectProperty(None)
    button_2_label = ObjectProperty(None)
    button_2_area = ObjectProperty(None)
    moving_accent = ObjectProperty(None)
    underbar = ObjectProperty(None)
    COLOR_BACKGROUND = ListProperty([])
    COLOR_ICON = ListProperty([])
    COLOR_UNDERBAR = ListProperty([])
    COLOR_MOVING_ACCENT = ListProperty([])
    moving_accent_pos = NumericProperty(0)
    dismiss_locked = BooleanProperty(False)
    minimize_locked = BooleanProperty(False)
    video_tab_locked = BooleanProperty(False)
    bluetooth_title = StringProperty("Bluetooth")

    def __init__(self, manager, **kwargs):
        super(TabbedPopupManager, self).__init__(**kwargs)
        self.manager = manager
        self.manager.bind(COLOR_BACKGROUND=self.on_theme_change)
        self.manager.bind(lang=self.on_lang_change)
        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_ICON = self.manager.COLOR_ICON
        self.COLOR_UNDERBAR = self.manager.COLOR_UNDERBAR
        self.COLOR_MOVING_ACCENT = self.manager.COLOR_MOVING_ACCENT

        self.button_1 = [
            self.button_1_left_end,
            self.button_1_middle,
            self.button_1_right_end,
            self.button_1_icon,
            self.button_1_label,
            self.button_1_area,
        ]

        self.button_2 = [
            self.button_2_left_end,
            self.button_2_middle,
            self.button_2_right_end,
            self.button_2_icon,
            self.button_2_label,
            self.button_2_area,
        ]

        self.bluetooth_tab = BluetoothTab(manager)
        self.info_tab = InfoTab(manager)
        self.confirmation_tab = ConfirmationTab(manager)
        self.status_tab = StatusTab(manager)
        # self.video_tab = VideoFeedTab(manager)

        self.tabbed_panel.bind(current_tab=self.on_current_tab)
        self.calculate_tab_widths()
        self.on_current_tab()

    def on_lang_change(self, *args):
        """Called on language change to reload the tabs' titles and names.
        """
        if self.tabbed_panel.current_tab is self.bluetooth_tab:
            self.title.text = TAB_TITLES["bluetooth"][self.manager.lang]
        elif self.tabbed_panel.current_tab is self.confirmation_tab:
            self.title.text = TAB_TITLES["confirmation"][self.manager.lang]
        elif self.tabbed_panel.current_tab is self.info_tab:
            self.title.text = TAB_TITLES["info"][self.manager.lang]
        # elif self.tabbed_panel.current_tab is self.video_tab:
        #     self.title.text = TAB_TITLES["video"][self.manager.lang]
        elif self.tabbed_panel.current_tab is self.status_tab:
            self.title.text = TAB_TITLES["status"][self.manager.lang]

        self.bluetooth_tab.text = TAB_NAMES["bluetooth"][self.manager.lang]
        self.info_tab.text = TAB_NAMES["info"][self.manager.lang]
        self.confirmation_tab.text = TAB_NAMES["confirmation"][self.manager.lang]
        # self.video_tab.text = TAB_NAMES["video"][self.manager.lang]
        self.status_tab.text = TAB_NAMES["status"][self.manager.lang]

    def on_theme_change(self, *args):
        """Called on theme change to change its color scheme too.
        """
        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_ICON = self.manager.COLOR_ICON
        self.COLOR_UNDERBAR = self.manager.COLOR_UNDERBAR
        self.COLOR_MOVING_ACCENT = self.manager.COLOR_MOVING_ACCENT

    def calculate_tab_widths(self):
        """Calculates the new widths for the tabs and updates the moving accent.
        """
        if len(self.tabbed_panel.tab_list) == 0:
            pass

        elif len(self.tabbed_panel.tab_list) == 1:
            self.tabbed_panel.tab_list[0].opacity = 0
            self.moving_accent.opacity = 0
            self.tabbed_panel.tab_height = 0
            self.tabbed_panel.tab_width = self.tabbed_panel.tab_width + (
                self.width - len(self.tabbed_panel.tab_list) * self.tabbed_panel.tab_width
            ) / len(self.tabbed_panel.tab_list)

        else:
            for tab in self.tabbed_panel.tab_list:
                tab.opacity = 1
            self.moving_accent.opacity = 1
            self.tabbed_panel.tab_height = 64
            self.tabbed_panel.tab_width = self.tabbed_panel.tab_width + (
                self.width - len(self.tabbed_panel.tab_list) * self.tabbed_panel.tab_width
            ) / len(self.tabbed_panel.tab_list)

        if len(self.tabbed_panel.tab_list) != 0:
            if self.tabbed_panel.current_tab.pos[0] == 0:
                self.moving_accent_pos = self.width * (
                    (len(self.tabbed_panel.tab_list) - 1) / len(self.tabbed_panel.tab_list)
                )
            else:
                self.moving_accent_pos = (
                    self.width
                    * (
                        len(self.tabbed_panel.tab_list)
                        - self.tabbed_panel.tab_list.index(self.tabbed_panel.current_tab)
                        - 1
                    )
                    / len(self.tabbed_panel.tab_list)
                )

    def update_dismiss_locked(self, *args):
        """Updates the dismiss lock accordingly to what tabs are present.
        """
        if (
            self.tabbed_panel.current_tab is self.status_tab
            and (self.manager.fm.error_detected or self.manager.fm.warning_detected)
        ) or self.tabbed_panel.current_tab is self.confirmation_tab:
            self.dismiss_locked = True
        else:
            self.dismiss_locked = False

    def update_minimize_locked(self, *args):
        """Updates the minimize lock accordingly to what tabs are present.
        """
        if self.confirmation_tab in self.tabbed_panel.tab_list:
            self.minimize_locked = True
        else:
            self.minimize_locked = False

    def on_dismiss_locked(self, *args):
        """Manages the opacity and clickability of the popup's close button
        depending on the state of dismiss_locked property.
        """
        if args[1] is True:
            self.close_button_icon.opacity = 0.25
            self.close_button.opacity = 0
            self.close_button.size = (0, 0)
        else:
            self.close_button_icon.opacity = 1
            self.close_button.opacity = 1
            self.close_button.size = (80, 80)

    def on_minimize_locked(self, *args):
        """Manages the opacity and clickability of the popup's minimize button
        depending on the state of minimize_locked property.
        """
        if args[1] is True:
            self.minimize_button_icon.opacity = 0.25
            self.minimize_button.opacity = 0
            self.minimize_button.size = (0, 0)
        else:
            self.minimize_button_icon.opacity = 1
            self.minimize_button.opacity = 1
            self.minimize_button.size = (80, 80)

    def on_current_tab(self, *args):
        """Callback called on current_tab property change.
        """
        if self.tabbed_panel.current_tab is self.bluetooth_tab:
            self.title.text = TAB_TITLES["bluetooth"][self.manager.lang]
            self.bluetooth_tab.on_enter()

        elif self.tabbed_panel.current_tab is self.info_tab:
            self.title.text = TAB_TITLES["info"][self.manager.lang]
            self.info_tab.on_enter()

        elif self.tabbed_panel.current_tab is self.confirmation_tab:
            self.title.text = TAB_TITLES["confirmation"][self.manager.lang]
            self.confirmation_tab.on_enter()

        # elif self.tabbed_panel.current_tab is self.video_tab:
        #     self.title.text = TAB_TITLES["video"][self.manager.lang]
        #     self.button_1_area.hidden = True
        #     self.button_2_area.hidden = True

        elif self.tabbed_panel.current_tab is self.status_tab:
            self.title.text = TAB_TITLES["status"][self.manager.lang]
            self.button_1_area.hidden = True
            self.button_2_area.hidden = True

        # Note about update manager:
        # > The app has to have a possibility to be updated, along
        # > with Raspberry's OS components (sudo apt-get update, upgrade).
        # > This will require an Internet connection that will have to be
        # > tethered through Bluetooth. User will have to be notified
        # > about the size of update (either app's update or os components').
        # > There is a predefined information slot in Bluetooth handshake,
        # > that is meant to indicate a critical update of the app,
        # > which will block the apps' usability until it is updated.
        # elif self.tabbed_panel.current_tab is self.update_tab:
        #     self.title.text = "Update manager"

        # If tabbed popup is brought back to front and it has been minimized with a
        # video streaming on then this prevents the video feed to appear over
        # a tab which is not the video_tab.
        # if self.video_tab.streaming:
        #     self.video_tab.feed_visibility_callback()

        # self.update_dismiss_locked()
        # self.update_minimize_locked()
        # self.moving_accent_pos = self.tabbed_panel.current_tab.pos[0]

    def on_video_tab_locked(self, *args):
        """Disable camera feed button if the QR reading screen
        is open. It eliminates a problem with double access
        to the camera.
        """
        if self.video_tab_locked:
            pass
            #self.camera_feed_button.disabled = True
        else:
            pass
            #self.camera_feed_button.disabled = False

    def add_tab(self, tab_name, fault_code=None, *args):
        """Manages adding tabs to the tabbed popup view.

        Args:
            tab_name (string): Descriptive name of the tab that has to be added
            fault_code (int, optional): Code number the InfoTab has to be opened
            with, showing information about the current fault. Defaults to None.
        """
        # Hides the camera feed, which would otherwise cover the ModalView
        # in case we're on QR reading screen.
        # self.minimize_button.disabled =False
        # if self.manager.get_screen("main").current_screen == "qr":
        #     self.manager.get_screen("main").pause_qr_screen_preview()

        # Assign the tab's object by descriptor and do some
        # tab-exclusive operations if needed.
        if tab_name == "bluetooth":
            tab = self.bluetooth_tab
            self.bluetooth_tab.on_enter()
        elif tab_name == "status":
            tab = self.status_tab
        elif tab_name == "info":
            # If there is a fault code provided,
            # open a view with information about it.
            # Otherwise open default view (MM3D guide)
            if fault_code is not None:
                self.info_tab.open_by_fault_code(fault_code)
            else:
                self.info_tab.open_default_view()
            tab = self.info_tab
        # elif tab_name == "video":
        #     self.minimize_button.disabled =True
        #     tab = self.video_tab
            
        elif tab_name == "confirmation":
            tab = self.confirmation_tab
            # Depending on the current situation there are different
            # variants of this tab that are being shown.
            # If user is on the "main" screen and this app is being added
            # it means that he's on one of the consumable list views.
            if self.manager.current == "main":
                if self.manager.get_screen("main").current_screen == "change_cruicible":
                    self.confirmation_tab.change_hardware_view()
                elif self.manager.get_screen("main").current_screen == "change_nozzles":
                    self.confirmation_tab.change_hardware_view()
                elif self.manager.get_screen("main").current_screen == "change_skimmer":
                    self.confirmation_tab.change_hardware_view()
                else:
                    self.confirmation_tab.remove_consumable_view()
            # If Bluetooth connection is required and the Bluetooth connection
            # has been lost, user is being notified that the process is being
            # stopped because of that.
            elif (
                self.manager.bcm.bluetooth_connection_required
                and self.manager.fm.fault_states[self.manager.fm.fault_codes.index(BLUETOOTH_CONNECTION_LOST["code"])]
                is True
            ):
                self.confirmation_tab.process_stopped_view()
            elif self.manager.current == "preprocess":
                if self.manager.get_screen("preprocess").current_screen == "delete_profile":
                    self.confirmation_tab.delete_profile_view()
                elif self.manager.get_screen("preprocess").current_screen == "edit_profile":
                    self.confirmation_tab.edit_profile_view()
                elif self.manager.get_screen("preprocess").current_screen == "save_changes":
                    self.confirmation_tab.save_changes_view()
                else:
                    pass
            # In every other case a process cancelation view is being shown.
            else:
                self.confirmation_tab.cancel_process_view()

        # Check if tab that has to be added isn't already there
        has_instance = False
        for instance in self.tabbed_panel.tab_list:
            if isinstance(instance, type(tab)):
                has_instance = True
        # If not then add it to the layout:
        if not has_instance:
            def _switch(*args):
                self.tabbed_panel.add_widget(tab)
                self.tabbed_panel.switch_to(tab)
                self.calculate_tab_widths()

            # This scheduled call seems to help with problems with visual bugs
            # eg. no background under ModalView
            Clock.schedule_once(_switch)

        # Added for the sake of switching tab after each press of the info button
        # in the fault lists
        else:

            def _switch(*args):
                self.tabbed_panel.switch_to(tab)

            # This call seems to help with problems with visual bugs
            # eg. no background under ModalView
            Clock.schedule_once(_switch)

        # If the ModalView is not open then open it
        if not isinstance(App.get_running_app().root_window.children[0], type(self)):

            def _open(*args):
                # Additional prevention against trying to open ModalView twice,
                # since it happens that add_tab is called twice (somehow) when
                # app opens up with fault present
                if not isinstance(App.get_running_app().root_window.children[0], type(self)):
                    self.open()
                # self.open(animation=False)

            # This call seems to help with problems with visual bugs
            # eg. no background under ModalView
            Clock.schedule_once(_open)

    def remove_tab(self, tab, *args):
        """Removes the provided tab from the tabbed popup view or closes it
        completely if the provided tab was the only one present.

        Args:
            tab (TabbedPanelItem): Tab to be removed from the view
        """
        if tab is self.confirmation_tab:
            self.dismiss()
            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)

        # elif tab is self.video_tab:
        #     # self.camera_feed_icon.source = BUTTON_ICON_TURN_VIDEOFEED_ON
        #     pass
        # self.tabbed_panel.remove_widget(tab)

        if len(self.tabbed_panel.tab_list) > 0:
            self.tabbed_panel.switch_to(self.tabbed_panel.tab_list[0])
        else:
            
            self.dismiss()

        self.calculate_tab_widths()

    # def camera_feed(self, *args):
    #     """Manages starting of the camera feed tab depending on the state
    #     of camera (if it's already streaming or not).
    #     """
    #     if not self.video_tab.streaming:
    #         self.add_tab("video")
    #         self.video_tab.start_livefeed()
    #         #self.camera_feed_icon.source = BUTTON_ICON_TURN_VIDEOFEED_OFF
    #     else:
    #         #self.camera_feed_icon.source = BUTTON_ICON_TURN_VIDEOFEED_ON
    #         self.video_tab.stop_livefeed()

    # def on_open(self):
    #     """Prevent the buttons to be visible and unpause preview
    #     on restore of modal view after it was minimized on camera tab.
    #     """
    #     if self.tabbed_panel.current_tab is self.video_tab:
    #         self.video_tab.unpause_livefeed()
    #         self.button_1_area.hidden = True
    #         self.button_2_area.hidden = True

    # def on_dismiss(self):
    #     """Pause video feed when modal view is dismissed (minimized)
    #     or unpause the QR screen reading process.
    #     """
    #     if self.video_tab.streaming:
    #         self.video_tab.pause_livefeed()

    #     if self.manager.get_screen("main").current_screen == "qr":
    #         self.manager.get_screen("main").unpause_qr_screen_preview()

    def recalculate_buttons(self):
        """Recalculate button layouts and positions basing on their current contents.
        """

        def _recalculate(*args):
            """Wrapped to be called with Clock to make sure the main thread
            runs it and thus we avoid problems with displaying this stuff.
            """
            calculate_button_inner_layout(self.button_1)
            calculate_button_inner_layout(self.button_2)
            calculate_two_button_layout_tab(self.button_1, self.button_2, self)

        Clock.schedule_once(_recalculate)
