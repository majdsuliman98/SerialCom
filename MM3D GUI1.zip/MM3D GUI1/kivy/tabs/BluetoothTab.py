from kivy.metrics import dp
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.uix.tabbedpanel import TabbedPanelItem
from kivy.properties import ObjectProperty, ListProperty

from TouchRippleButton import TouchRippleButton

from Buttons import bind_callback, unbind_all_callbacks
from Images import (
    GIF_LOADING,
    ICON_BUTTON_SCAN,
    ICON_SPINNER_SUCCESS,
    ICON_SPINNER_FAILED,
    ICON_SPINNER_CANCELED,
    ICON_BUTTON_EXIT,
    ICON_BUTTON_UNPAIR,
    ICON_BUTTON_CANCEL,
    ICON_BUTTON_DISCONNECT,
)
from Strings import BLUETOOTH_TAB, TAB_NAMES

Builder.load_file("tabs/BluetoothTab.kv")


class BluetoothTab(TabbedPanelItem, TouchRippleButton):
    """Implementation of a tab used to display and manage Bluetooth connection.
    """
    COLOR_ICON = ListProperty([])
    COLOR_BACKGROUND = ListProperty([])
    COLOR_BACKGROUND_SPINNER = ListProperty([])
    main_layout = ObjectProperty(None)
    screen_text = ObjectProperty(None)
    info_text = ObjectProperty(None)
    spinner = ObjectProperty(None)
    spinnerMessage = ObjectProperty(None)
    rv = ObjectProperty(None)
    rv_label = ObjectProperty(None)

    def __init__(self, manager, **kwargs):
        super(BluetoothTab, self).__init__(**kwargs)
        self.manager = manager
        self.manager.bind(COLOR_BACKGROUND=self.on_theme_change)
        self.COLOR_ICON = self.manager.COLOR_ICON
        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_BACKGROUND_SPINNER = self.manager.COLOR_BACKGROUND_SPINNER
        self.text = TAB_NAMES["bluetooth"][self.manager.lang]
        self.content = self.main_layout

        self.view = "default"
        self.pairing_timeout = self.manager.bcm.pairing_timeout
        self.rv_label.text = BLUETOOTH_TAB["available_devices"][self.manager.lang]
        self.screen_text.text = BLUETOOTH_TAB["bluetooth_status_current"][self.manager.lang]
        self.info_text.text = BLUETOOTH_TAB["not_connected_description"][self.manager.lang]

        self.manager.bcm.bind(bluetooth_status=self.bluetooth_status_callback)
        self.manager.bcm.bind(bluetooth_scan_state=self.bluetooth_scan_stopped)
        self.manager.bcm.bind(bluetooth_device_list=self.bluetooth_device_list_callback)
        self.bluetooth_status_callback(self.manager.bcm.bluetooth_status)

    def on_theme_change(self, *args):
        """Updates tab's color scheme.
        """
        self.COLOR_ICON = self.manager.COLOR_ICON
        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_BACKGROUND_SPINNER = self.manager.COLOR_BACKGROUND_SPINNER

    def on_enter(self):
        """Defines the behavior when the tab is entered.
        It is being called manually in TabbedPopupManager in contrast to
        on_enter() methods of screens, which are being called automatically
        on "on_enter" event calls.
        """
        # Sometimes status text wasn't shown in the tab view after startup.
        # It's fixed by calling the callback below.
        self.bluetooth_status_callback()
        self._open_or_maximize_window()

    def default_view(self, *args):
        """Default view which shows user information about connection status
        along with message about app and auto Bluetooth connection.
        """
        self.view = "default"
        self.spinner.opacity = 0
        self.spinner.anim_delay = -1
        self.spinner.source = GIF_LOADING
        self.spinnerMessage.opacity = 0
        self.screen_text.opacity = 1
        self.info_text.opacity = 1
        self.info_text.text = BLUETOOTH_TAB["not_connected_description"][self.manager.lang]
        if self.manager.tpm.tabbed_panel.current_tab is self:
            self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["scan"][self.manager.lang]
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_SCAN
            self.manager.tpm.button_1_area.hidden = True
            self.manager.tpm.button_2_area.disabled = False
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_2, self.begin_bluetooth_scan)
            self.manager.tpm.recalculate_buttons()

    def _open_or_maximize_window(self, *args):
        """Manages the content of the window depending on the current view.
        Called when tab is brought to foreground.

        In each case there is a repetition of button setup from corresponding
        view function. The thing is that setting up buttons in TPM was easier
        to do, but ended up being a bit messy to manage later. I ended up
        staying with this approach since it ended up being sufficient for its
        use cases.
        """
        if self.view == "default":
            self.manager.tpm.button_1_area.hidden = True
            self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["scan"][self.manager.lang]
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_SCAN
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_2, self.begin_bluetooth_scan)
            self.manager.tpm.recalculate_buttons()

        elif self.view == "scanning" or self.view == "scanning_list":
            self.manager.tpm.button_1_area.hidden = True
            self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["stop_scan"][self.manager.lang]
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_CANCEL
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_2, self.stop_bluetooth_scan)
            self.manager.tpm.recalculate_buttons()

        elif self.view == "scanning_stopped":
            self.manager.tpm.button_1_area.disabled = False
            self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_1_label.text = BLUETOOTH_TAB["exit"][self.manager.lang]
            self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["rescan"][self.manager.lang]
            self.manager.tpm.button_1_icon.source = ICON_BUTTON_EXIT
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_SCAN
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_1, self.close_scan_view)
            bind_callback(self.manager.tpm.button_2, self.begin_bluetooth_scan)
            self.manager.tpm.recalculate_buttons()

        elif self.view == "already_paired":
            self.info_text.text = BLUETOOTH_TAB["already_paired_description"][self.manager.lang]
            self.manager.tpm.button_1_area.disabled = False
            self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_1_label.text = BLUETOOTH_TAB["exit"][self.manager.lang]
            self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["unpair"][self.manager.lang]
            self.manager.tpm.button_1_icon.source = ICON_BUTTON_EXIT
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_UNPAIR
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_1, self.default_view)
            bind_callback(self.manager.tpm.button_2, self.manager.bcm.unpair_device)
            self.manager.tpm.recalculate_buttons()

        elif self.view == "success":
            self.manager.tpm.button_1_area.hidden = True
            self.manager.tpm.button_2_area.hidden = True

        elif self.view == "pairing_canceled":
            self.manager.tpm.button_1_area.hidden = True
            self.manager.tpm.button_2_area.hidden = True

        elif self.view == "connected":
            if self.manager.bcm.bluetooth_connection_required:
                self.manager.tpm.button_2_area.disabled = True
            else:
                self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_1_area.hidden = True
            self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["disconnect"][self.manager.lang]
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_DISCONNECT
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_2, self.manager.bcm.disconnect)
            self.manager.tpm.recalculate_buttons()

        elif self.view == "disconnecting":
            self.manager.tpm.button_1_area.hidden = True
            self.manager.tpm.button_2_area.hidden = True

        else:
            pass

    def bluetooth_status_callback(self, *args):
        """Updates screen text according to Bluetooth status.
        """
        if self.manager.bcm.bluetooth_status == "enabled":
            self.screen_text.text = BLUETOOTH_TAB["bluetooth_status_waiting"][self.manager.lang]
        elif self.manager.bcm.bluetooth_status == "connected":
            # If MM3D app reaches out and connects with machine then stop scan
            # and proceed with setting up the connected view and etc.
            self.stop_bluetooth_scan()

            # Fix for the non updating device name after connection
            def update_label(*args):
                self.screen_text.text = (
                    BLUETOOTH_TAB["bluetooth_status_connected_to"][self.manager.lang]
                    + self.manager.bcm.selected_device_name
                )

            # Check if the device name has been loaded
            # If not at all then wait a moment and then try to get it
            if self.manager.bcm.selected_device_name == "":
                Clock.schedule_once(update_label, 0.25)
            else:
                update_label()

            self.close_scan_view()
            self.connected_view()
        else:
            self.screen_text.text = (
                BLUETOOTH_TAB["bluetooth_status_current"][self.manager.lang] + self.manager.bcm.bluetooth_status
            )

    def begin_bluetooth_scan(self, *args):
        """Called after pressing the "SCAN" button on main Bluetooth tab's
        screen.
        """
        self.view = "scanning"
        self.manager.bcm.selected_device_name = ""
        self.manager.bcm.selected_device_address = ""
        self.screen_text.opacity = 0
        self.info_text.opacity = 0
        self.spinner.source = GIF_LOADING
        self.spinner.opacity = 1
        self.spinnerMessage.opacity = 1
        self.spinner.anim_delay = 0
        self.hide_rv()
        self.spinnerMessage.text = BLUETOOTH_TAB["scanning"][self.manager.lang]
        if self.manager.tpm.tabbed_panel.current_tab is self:
            self.manager.tpm.button_1_area.hidden = True
            self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["stop_scan"][self.manager.lang]
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_CANCEL
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_2, self.stop_bluetooth_scan)
            self.manager.tpm.recalculate_buttons()
        self.manager.bcm.scan_for_bluetooth_devices()

    def bluetooth_device_list_callback(self, *args):
        """Called every time a change in device list is detected
        so it can update RecycleView.
        """
        # The problem with
        #   "Original exception was:
        #   Error in sys.excepthook: "
        # was mentioned here:
        # https://github.com/kivy/kivy/issues/5986
        # And fixed here:
        # https://github.com/kivy/kivy/commit/bae610177f8159e853f5201d7c758dfa9186989d
        # In short: if the recycle view's data was modified, and the length of
        # it is different than the first set of data's, the exception is going
        # to be thrown. I have noticed, that it also happens to the same set
        # of data (which was reloaded), but clearing the data, before reloading
        # the same set, prevents it. Doesn't work on a different set of data.
        # Since this Kivy installation is based on a 1.11.1 precompiled wheel,
        # and the 2.0.0 version of Kivy is not out yet, and I don't want to
        # play around and install the nightly version, this is going to need
        # a review after the Kivy gets an update.
        self.rv_label.text = BLUETOOTH_TAB["available_devices"][self.manager.lang]

        if args[1] != []:  # Prevents data reload when an empty dataset is passed.
            self.rv.opacity = 1
            self.rv.data = [
                {
                    "text": args[1][0][iterator],
                    "background_color": self.COLOR_BACKGROUND if iterator % 2 else self.COLOR_BACKGROUND_SPINNER,
                    "ripple_color": self.COLOR_BACKGROUND_SPINNER if iterator % 2 else self.COLOR_BACKGROUND,
                    "text_size[0]": dp(20),
                    # not really sure why but this line above made it possible for the label to be properly aligned
                    "padding": (dp(32), 0),
                }
                for iterator in range(len(args[1][0]))
            ]

        if self.rv.data != []:
            self.spinner.opacity = 0
            self.spinner.anim_delay = -1
            self.spinnerMessage.opacity = 0
            self.view = "scanning_list"

    def stop_bluetooth_scan(self, *args):
        """Stops scanning for Bluetooth devices and shows devices
        found (if any).
        """
        unbind_all_callbacks(self.manager.tpm.button_2)
        self.manager.bcm.scan_off()
        self.spinner.opacity = 0
        self.spinner.anim_delay = -1
        self.spinnerMessage.opacity = 0

        if self.rv.data == []:
            self.default_view()
        elif self.manager.tpm.tabbed_panel.current_tab is self:
            self.manager.tpm.button_1_label.text = BLUETOOTH_TAB["exit"][self.manager.lang]
            self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["rescan"][self.manager.lang]
            self.manager.tpm.button_1_icon.source = ICON_BUTTON_EXIT
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_SCAN
            self.manager.tpm.button_1_area.disabled = False
            self.manager.tpm.recalculate_buttons()

    def bluetooth_scan_stopped(self, *args):
        """Called every time self.manager.bcm.bluetooth_scan_state changes.
        Sets up view changes after scan actually stops (due to user interaction
        or due to timeout).
        """
        if args[1] is False and self.rv.data != []:
            self.view = "scanning_stopped"
            if self.manager.tpm.tabbed_panel.current_tab is self:
                self.manager.tpm.button_1_label.text = BLUETOOTH_TAB["exit"][self.manager.lang]
                self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["rescan"][self.manager.lang]
                self.manager.tpm.button_1_icon.source = ICON_BUTTON_EXIT
                self.manager.tpm.button_2_icon.source = ICON_BUTTON_SCAN
                unbind_all_callbacks(self.manager.tpm.button_1)
                unbind_all_callbacks(self.manager.tpm.button_2)
                bind_callback(self.manager.tpm.button_1, self.close_scan_view)
                bind_callback(self.manager.tpm.button_2, self.begin_bluetooth_scan)
                self.manager.tpm.recalculate_buttons()

    def close_scan_view(self, *args):
        """Called after pressing "Exit" button after scan is stopped.
        """
        self.view = "default"
        self.hide_rv()
        self.info_text.opacity = 1
        self.screen_text.opacity = 1
        if self.manager.tpm.tabbed_panel.current_tab is self:
            self.manager.tpm.button_1_area.hidden = True
            self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["scan"][self.manager.lang]
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_SCAN
            unbind_all_callbacks(self.manager.tpm.button_1)
            bind_callback(self.manager.tpm.button_1, self.begin_bluetooth_scan)
            self.manager.tpm.recalculate_buttons()

    def pair_device_view(self, *args):
        """A view which is shown after user presses a recycle view list item
        to pair a device.
        """
        self.hide_rv()

        self.spinner.opacity = 1
        self.spinner.anim_delay = 0
        self.spinnerMessage.opacity = 1
        self.spinnerMessage.text = BLUETOOTH_TAB["pairing"][self.manager.lang]
        self.pairing_timeout = self.manager.bcm.pairing_timeout

        if self.manager.tpm.tabbed_panel.current_tab is self:
            self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["cancel"][self.manager.lang]
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_CANCEL
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_2, self.manager.bcm.cancel_pairing)
            self.manager.tpm.recalculate_buttons()

    def disconnecting_device_view(self, *args):
        """A view which is shown after user presses a disconnect button.
        """
        self.view = "disconnecting"
        self.screen_text.opacity = 0
        self.info_text.opacity = 0
        self.spinner.opacity = 1
        self.spinner.anim_delay = 0
        self.spinnerMessage.opacity = 1
        self.spinnerMessage.text = BLUETOOTH_TAB["disconnecting"][self.manager.lang]
        if self.manager.tpm.tabbed_panel.current_tab is self:
            self.manager.tpm.button_2_area.hidden = True
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)

    def pair_device_countdown_view(self, *args):
        """A view which is shown when the machine waits for the user to confirm
        pairing on the mobile phone. After self.pairing_timeout reaches 0 the
        pairing process is canceled.
        """
        if self.pairing_timeout > 15:
            self.spinnerMessage.text = (
                BLUETOOTH_TAB["pairing"][self.manager.lang] + " (" + str(self.pairing_timeout) + ")"
            )
            self.pairing_timeout -= 1
        elif self.pairing_timeout == 15:
            self.spinnerMessage.text = (
                BLUETOOTH_TAB["pairing"][self.manager.lang]
                + " ("
                + str(self.pairing_timeout)
                + ")"
                + BLUETOOTH_TAB["pairing_info"][self.manager.lang]
            )
            self.pairing_timeout -= 1
            self.spinner.parent.parent.padding[1] -= 88
            self.spinner.parent.parent._trigger_layout()

        elif self.pairing_timeout > 0:
            self.spinnerMessage.text = (
                BLUETOOTH_TAB["pairing"][self.manager.lang]
                + " ("
                + str(self.pairing_timeout)
                + ")"
                + BLUETOOTH_TAB["pairing_info"][self.manager.lang]
            )
            self.pairing_timeout -= 1
        else:
            self.spinner.parent.parent.padding[1] += 88
            self.spinner.parent.parent._trigger_layout()
            self.spinner.anim_delay = -1
            self.spinner.source = ICON_SPINNER_FAILED
            self.spinnerMessage.text = BLUETOOTH_TAB["timed_out"][self.manager.lang]
            Clock.unschedule(self.manager.bcm.pairing_countdown)
            if self.manager.tpm.tabbed_panel.current_tab is self:
                self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["accept"][self.manager.lang]
                self.manager.tpm.button_2_icon.source = ICON_SPINNER_SUCCESS
                unbind_all_callbacks(self.manager.tpm.button_2)
                bind_callback(self.manager.tpm.button_2, self.default_view)
                self.manager.tpm.recalculate_buttons()

    def pairing_canceled_view(self, *args):
        """Informs user that pairing operation has been canceled.
        """
        self.view = "pairing_canceled"
        self.spinner.anim_delay = -1
        self.spinner.source = ICON_SPINNER_CANCELED
        self.spinnerMessage.text = BLUETOOTH_TAB["canceled"][self.manager.lang]
        Clock.schedule_once(self.default_view, 2)  # change to main screen
        if self.manager.tpm.tabbed_panel.current_tab is self:
            unbind_all_callbacks(self.manager.tpm.button_2_area)
            self.manager.tpm.button_layout_2.opacity = 0

    def already_paired_view(self, *args):
        """Displays information that a selected device has been
        previously paired and that the machine is waiting
        for mobile app reaching out to it. It also enables
        user to unpair selected device.
        """
        self.view = "already_paired"
        self.spinner.opacity = 0
        self.spinner.anim_delay = -1
        self.spinnerMessage.opacity = 0
        self.screen_text.opacity = 1
        self.info_text.opacity = 1
        self.info_text.text = BLUETOOTH_TAB["already_paired_description"][self.manager.lang]
        if self.manager.tpm.tabbed_panel.current_tab is self:
            self.manager.tpm.button_1_label.text = BLUETOOTH_TAB["exit"][self.manager.lang]
            self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["unpair"][self.manager.lang]
            self.manager.tpm.button_1_icon.source = ICON_BUTTON_EXIT
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_UNPAIR
            self.manager.tpm.button_1_area.disabled = False
            self.manager.tpm.button_2_area.disabled = False
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_1, self.default_view)
            bind_callback(self.manager.tpm.button_2, self.manager.bcm.unpair_device)
            self.manager.tpm.recalculate_buttons()

    def success_view(self, *args):
        """Displays a "success" message after successful
        pairing, unpairing and disconnecting.
        """
        self.view = "success"
        self.screen_text.opacity = 0
        self.info_text.opacity = 0
        self.spinner.opacity = 1
        self.spinner.anim_delay = -1
        self.spinner.source = ICON_SPINNER_SUCCESS
        self.spinnerMessage.opacity = 1
        self.spinnerMessage.text = BLUETOOTH_TAB["success"][self.manager.lang]
        Clock.schedule_once(self.default_view, 1)
        if self.manager.tpm.tabbed_panel.current_tab is self:
            self.manager.tpm.button_1_area.hidden = True
            self.manager.tpm.button_2_area.hidden = True
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)

    def hide_rv(self, *args):
        """Cleans up the RecycleView's data and hides it.
        """
        self.rv.data = []
        self.rv.opacity = 0

    def connected_view(self, *args):
        """A view which is shown when a mobile phone is successfully connected.
        """
        self.view = "connected"
        self.info_text.text = BLUETOOTH_TAB["connected_description"][self.manager.lang]
        if self.manager.tpm.tabbed_panel.current_tab is self:
            self.manager.tpm.button_2_label.text = BLUETOOTH_TAB["disconnect"][self.manager.lang]
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_DISCONNECT
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_2, self.manager.bcm.disconnect)
            self.manager.tpm.recalculate_buttons()

    def close(self):
        """A call to close (remove) self from TabbedPopupManager.
        """
        self.manager.tpm.remove_tab(self)
