from kivy.clock import Clock
from kivy.lang import Builder
from kivy.logger import Logger
from kivy.uix.tabbedpanel import TabbedPanelItem
from kivy.properties import ObjectProperty, ListProperty

from FaultRow import FaultRow
from TouchRippleButton import TouchRippleButton

from Constants import DOOR_NAMES
from Faults import (
    ERROR_CRUCIBLE_SENSOR_1, 
    ERROR_DIE_RIGHT_SENSOR, 
    ERROR_OPEN_DOORS, 
    WARNING_OPEN_DOORS
    )
    
from Strings import (
    DEG_C, 
    FAULTS, 
    STATUS_TAB,
    TAB_NAMES
    )

Builder.load_file("tabs/StatusTab.kv")


class StatusTab(TabbedPanelItem, TouchRippleButton):
    """This tab is responsible for showing user the current
    machine's state (detected warnings, errors, sensor readings,
    etc.). It can be opened by clicking on the "MM3D Foundry"
    logo on top panel. It opens up automatically in case a fault
    is detected. In case of such detection it cannot be closed
    fully, but it can be minimized (so user is reminded that
    there is a fault present if he dismisses the ModalView and
    then brings it back). Orange and red LEDs are also indicators
    of faults being present.
    """

    COLOR_ICON = ListProperty([])
    COLOR_BACKGROUND = ListProperty([])
    main_layout = ObjectProperty(None)

    status_text = ObjectProperty(None)
    status_text_spacing = ObjectProperty(None)
    screen_text = ObjectProperty(None)
    screen_text_spacing = ObjectProperty(None)
    warning_title = ObjectProperty(None)
    dynamic_warning_list_layout = ObjectProperty(None)
    warning_spacing = ObjectProperty(None)
    error_title = ObjectProperty(None)
    dynamic_error_list_layout = ObjectProperty(None)
    error_list = ObjectProperty(None)
    error_spacing = ObjectProperty(None)

    device_monitor_title = ObjectProperty(None)
    temperatures_crucible_label = ObjectProperty(None)
    temperatures_dies_label = ObjectProperty(None)
    ambient_conditions_label = ObjectProperty(None)
    temperatures_cjc_crucible_label = ObjectProperty(None)
    temperatures_cjc_dies_label = ObjectProperty(None)
    weight_label = ObjectProperty(None)
    pressure_label = ObjectProperty(None)
    valve_main_vacuum_label = ObjectProperty(None)
    valve_vacuum_split_label = ObjectProperty(None)
    valve_argon_main_label = ObjectProperty(None)
    valve_argon_control_label = ObjectProperty(None)
    crucible_temperatures_value = ObjectProperty(None)
    dies_temperatures_value = ObjectProperty(None)
    ambient_conditions_value = ObjectProperty(None)
    temperatures_cjc_crucible_value = ObjectProperty(None)
    temperatures_cjc_dies_value = ObjectProperty(None)
    vacuum_main_valve_state = ObjectProperty(None)
    vacuum_split_valve_state = ObjectProperty(None)
    argon_main_valve_state = ObjectProperty(None)
    argon_control_valve_state = ObjectProperty(None)

    def __init__(self, manager, **kwargs):
        super(StatusTab, self).__init__(**kwargs)
        self.manager = manager
        self.manager.bind(COLOR_BACKGROUND=self.on_theme_change)
        self.manager.bind(lang=self.on_lang_change)
        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_ICON = self.manager.COLOR_ICON
        self.text = TAB_NAMES["status"][self.manager.lang]
        self.content = self.main_layout
        self.manager.fm.bind(fault_states=self.on_fault_callback)
        self.manager.fm.bind(state=self.on_state_callback)
        self.manager.fm.bind(error_detected=self.on_error_detected)
        self.manager.fm.bind(warning_detected=self.on_warning_detected)
        # Maybe schedule it to refresh every second or so instead of every time the data is read?
        self.manager.ccm.bind(DATA_REFRESHED_ARDUINO_CONTROL=self.on_data_refreshed_callback)

        self.status_text.text = STATUS_TAB["device_status"][self.manager.lang] + "[b]" + self.manager.fm.state + "[/b]"
        self.device_monitor_title.text = STATUS_TAB["device_monitor_title"][self.manager.lang]
        self.screen_text.text = STATUS_TAB["fault_message"][self.manager.lang]
        self.warning_title.text = STATUS_TAB["warning_list_title"][self.manager.lang]
        self.error_title.text = STATUS_TAB["error_list_title"][self.manager.lang]

        # Fix for layout bug (when tab is opened after startup there is
        # an empty space between status text and the device monitor)
        self.screen_text.size_hint_y = 0
        self.screen_text_spacing.size_hint_y = 0
        self.warning_title.size_hint_y = 0
        self.warning_spacing.size_hint_y = 0
        self.error_title.size_hint_y = 0
        self.error_spacing.size_hint_y = 0

        self.temperatures_crucible_label.text = STATUS_TAB["crucible_temp_title"][self.manager.lang]

        self.ambient_conditions_label.text = STATUS_TAB["ambient_cond_title"][self.manager.lang]
        self.temperatures_cjc_crucible_label.text = STATUS_TAB["crucible_cjc_title"][self.manager.lang]

        self.weight_label.text = STATUS_TAB["weight_title"][self.manager.lang]
        self.pressure_label.text = STATUS_TAB["pressure_title"][self.manager.lang]
        # self.valve_main_vacuum_label.text = STATUS_TAB["valve_main_vacuum_title"][self.manager.lang]
        # self.valve_vacuum_split_label.text = STATUS_TAB["valve_vacuum_split_title"][self.manager.lang]
        self.valve_argon_main_label.text = STATUS_TAB["valve_argon_main_title"][self.manager.lang]
        self.valve_argon_control_label.text = STATUS_TAB["valve_argon_control_title"][self.manager.lang]

    def on_lang_change(self, *args):
        """Reload tab strings on language change.
        """
        self.status_text.text = STATUS_TAB["device_status"][self.manager.lang] + "[b]" + self.manager.fm.state + "[/b]"
        self.device_monitor_title.text = STATUS_TAB["device_monitor_title"][self.manager.lang]
        self.screen_text.text = STATUS_TAB["fault_message"][self.manager.lang]
        self.warning_title.text = STATUS_TAB["warning_list_title"][self.manager.lang]
        self.error_title.text = STATUS_TAB["error_list_title"][self.manager.lang]
        self.temperatures_crucible_label.text = STATUS_TAB["crucible_temp_title"][self.manager.lang]
        self.ambient_conditions_label.text = STATUS_TAB["ambient_cond_title"][self.manager.lang]
        self.temperatures_cjc_crucible_label.text = STATUS_TAB["crucible_cjc_title"][self.manager.lang]
        self.weight_label.text = STATUS_TAB["weight_title"][self.manager.lang]
        self.pressure_label.text = STATUS_TAB["pressure_title"][self.manager.lang]

        self.valve_argon_main_label.text = STATUS_TAB["valve_argon_main_title"][self.manager.lang]
        self.valve_argon_control_label.text = STATUS_TAB["valve_argon_control_title"][self.manager.lang]
        self.on_fault_callback()

    def on_theme_change(self, *args):
        """Reload colors on theme change.
        """
        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_ICON = self.manager.COLOR_ICON

    def late_init(self):
        """Called inside of FaultManager. It prevents calling the callbacks
        with uninitialized data.
        """
        self.on_error_detected(None, self.manager.fm.error_detected)
        self.on_warning_detected(None, self.manager.fm.warning_detected)

    def on_state_callback(self, *args):
        """Called on machine's state change. Sets the status text accordingly.
        """
        self.status_text.text = STATUS_TAB["device_status"][self.manager.lang] + "[b]" + self.manager.fm.state + "[/b]"

    def on_data_refreshed_callback(self, *args):
        """Called when new batch of data from control Arduino arrives.
        Parses this data and displays it in "Device monitor" section.
        """
        self.crucible_temperatures_value.text = (
            str(round(self.manager.ccm.TEMP_TC[0], 1))
            + DEG_C
            + ", "
            + str(round(self.manager.ccm.TEMP_TC[1], 1))
            + DEG_C
            + ", "
            + str(round((self.manager.ccm.TEMP_TC[0] + self.manager.ccm.TEMP_TC[1]) * 0.5, 1))
            + DEG_C
        )

        self.ambient_conditions_value.text = (
            str(self.manager.ccm.AMBIENT_TEMP) + " " + chr(176) + "C, " + str(self.manager.ccm.AMBIENT_HUMIDITY) + " %"
        )
        self.temperatures_cjc_crucible_value.text = (
            str(round(self.manager.ccm.TEMP_CJC[0], 1))
            + DEG_C
            + ", "
            + str(round(self.manager.ccm.TEMP_CJC[1], 1))
            + DEG_C
        )

        self.weight_values.text = (
            str(round(self.manager.ccm.WEIGHT[0], 1))
            + " g, "
            + str(round(self.manager.ccm.WEIGHT[1], 1))
            + " g, "
            + str(round((self.manager.ccm.WEIGHT[0] + self.manager.ccm.WEIGHT[1]) * 0.5, 1))
            + " g"
        )

        self.pressure_values.text = (
            str(round(self.manager.ccm.PRESSURE[0], 1))
            + " kPa, "
        )

        # RB valve - Argon main (on/off) valve (RB_OPEN - 0, RB_CLOSE - 1):
        if self.manager.ccm.VALVE_ENDSTOPS[0] is False and self.manager.ccm.VALVE_ENDSTOPS[1] is False:
            self.argon_main_valve_state.text = STATUS_TAB["partially_open"][self.manager.lang]
        elif self.manager.ccm.VALVE_ENDSTOPS[0] is False and self.manager.ccm.VALVE_ENDSTOPS[1] is True:
            self.argon_main_valve_state.text = STATUS_TAB["closed"][self.manager.lang]
        elif self.manager.ccm.VALVE_ENDSTOPS[0] is True and self.manager.ccm.VALVE_ENDSTOPS[1] is False:
            self.argon_main_valve_state.text = STATUS_TAB["open"][self.manager.lang]
        else:
            self.argon_main_valve_state.text = STATUS_TAB["error"][self.manager.lang]

        # RT valve - Vacuum split valve (RT_CLOSED - 2, RT_OPEN - 4):
        # if self.manager.ccm.VALVE_ENDSTOPS[2] is False and self.manager.ccm.VALVE_ENDSTOPS[4] is False:
        #     self.vacuum_split_valve_state.text = STATUS_TAB["partially_open"][self.manager.lang]
        # elif self.manager.ccm.VALVE_ENDSTOPS[2] is False and self.manager.ccm.VALVE_ENDSTOPS[4] is True:
        #     self.vacuum_split_valve_state.text = STATUS_TAB["open"][self.manager.lang]
        # elif self.manager.ccm.VALVE_ENDSTOPS[2] is True and self.manager.ccm.VALVE_ENDSTOPS[4] is False:
        #     self.vacuum_split_valve_state.text = STATUS_TAB["closed"][self.manager.lang]
        # else:
        #     self.vacuum_split_valve_state.text = STATUS_TAB["error"][self.manager.lang]
        # self.vacuum_split_valve_state.text = STATUS_TAB["error"][self.manager.lang]

        # # LT valve - Vacuum main (on/off) (LT_OPEN - 3, LT_CLOSED - 5):
        # if self.manager.ccm.VALVE_ENDSTOPS[3] is False and self.manager.ccm.VALVE_ENDSTOPS[5] is False:
        #     self.vacuum_main_valve_state.text = STATUS_TAB["partially_open"][self.manager.lang]
        # elif self.manager.ccm.VALVE_ENDSTOPS[3] is False and self.manager.ccm.VALVE_ENDSTOPS[5] is True:
        #     self.vacuum_main_valve_state.text = STATUS_TAB["closed"][self.manager.lang]
        # elif self.manager.ccm.VALVE_ENDSTOPS[3] is True and self.manager.ccm.VALVE_ENDSTOPS[5] is False:
        #     self.vacuum_main_valve_state.text = STATUS_TAB["open"][self.manager.lang]
        # else:
        #     self.vacuum_main_valve_state.text = STATUS_TAB["error"][self.manager.lang]
        # self.vacuum_main_valve_state.text = STATUS_TAB["error"][self.manager.lang]
        self.argon_control_valve_state.text = str(self.manager.ccm.PROP_VALVE_CV) + " %"

    def on_fault_callback(self, *args):
        """Called when any of the fault states change. Takes care of
        managing the displayed fault rows in its (StatusTab's) contents.
        """
        # Fix for layout bug (when tab is opened after startup there
        # is an empty space between status text and device monitor)
        self.screen_text.size_hint_y = None
        self.screen_text_spacing.size_hint_y = None
        self.warning_title.size_hint_y = None
        self.warning_spacing.size_hint_y = None
        self.error_title.size_hint_y = None
        self.error_spacing.size_hint_y = None

        if self.manager.fm.error_detected is True:
            def _wrap(*args):
                appendix = ""
                faults_listed = 0

                faults = []
                clearability = []
                fault_codes = []

                for index, (fault_state, fault_code, fault_clearability) in enumerate(
                    zip(self.manager.fm.fault_states, self.manager.fm.fault_codes, self.manager.fm.fault_clearabilities)
                ):
                    if (
                        fault_code in range(ERROR_CRUCIBLE_SENSOR_1["code"], ERROR_DIE_RIGHT_SENSOR["code"] + 1)
                        and fault_state
                    ):
                        appendix = " (" + self.parse_max31856_fault_code(fault_state) + ")"
                    elif fault_code == ERROR_OPEN_DOORS["code"] and fault_state:
                        appendix = self.parse_open_door_names()

                    if fault_code >= 100:
                        break
                    else:
                        if fault_state:
                            faults_listed += 1
                            faults.append(FAULTS[fault_code][self.manager.lang] + appendix)
                            clearability.append(fault_clearability)
                            fault_codes.append(fault_code)

                # Get the amount of new widgets to add (or to remove)
                new_widget_amount = faults_listed - len(self.dynamic_error_list_layout.children)
                # If there are new faults to be listed:
                if new_widget_amount > 0:
                    for index, child in enumerate(self.dynamic_error_list_layout.children):
                        child.fault = faults[index]
                        child.clearable = clearability[index]
                        child.fault_code = fault_codes[index]

                    starting_index = len(faults) - new_widget_amount
                    for index in range(0, new_widget_amount):
                        self.dynamic_error_list_layout.add_widget(
                            FaultRow(
                                fault=faults[starting_index + index],
                                clearable=clearability[starting_index + index],
                                fault_code=fault_codes[starting_index + index]
                            )
                        )
                # If the amount if widgets didn't change
                elif new_widget_amount == 0:
                    for index, child in enumerate(self.dynamic_error_list_layout.children):
                        child.fault = faults[index]
                        child.clearable = clearability[index]
                        child.fault_code = fault_codes[index]
                # Finally, if we have less faults now
                elif new_widget_amount < 0:
                    for index, (child, _) in enumerate(zip(self.dynamic_error_list_layout.children, faults)):
                        child.fault = faults[index]
                        child.clearable = clearability[index]
                        child.fault_code = fault_codes[index]

                    for index in range(new_widget_amount, 0):
                        self.dynamic_error_list_layout.remove_widget(self.dynamic_error_list_layout.children[index])

                if new_widget_amount != 0:
                    height = 0
                    for child in self.dynamic_error_list_layout.children:
                        height += child.height
                    self.dynamic_error_list_layout.height = height
                    self.dynamic_error_list_layout.do_layout()

            Clock.schedule_once(_wrap)

        if self.manager.fm.warning_detected is True:
            def _wrap(*args):
                appendix = ""
                faults_listed = 0

                faults = []
                clearability = []
                fault_codes = []

                for index, (fault_state, fault_code, fault_clearability) in enumerate(
                    zip(self.manager.fm.fault_states, self.manager.fm.fault_codes, self.manager.fm.fault_clearabilities)
                ):
                    if fault_code == WARNING_OPEN_DOORS["code"] and fault_state:
                        appendix = self.parse_open_door_names()
                    else:
                        appendix = ""
                    if fault_code < 100:
                        pass
                    else:
                        if fault_state:
                            faults_listed += 1
                            faults.append(FAULTS[fault_code][self.manager.lang] + appendix)
                            clearability.append(fault_clearability)
                            fault_codes.append(fault_code)
                # Get the amount of new widgets to add (or to remove)
                new_widget_amount = faults_listed - len(self.dynamic_warning_list_layout.children)
                # If there are new faults to be listed:
                if new_widget_amount > 0:
                    for index, child in enumerate(self.dynamic_warning_list_layout.children):
                        child.fault = faults[index]
                        child.clearable = clearability[index]
                        child.fault_code = fault_codes[index]

                    starting_index = len(faults) - new_widget_amount
                    for index in range(0, new_widget_amount):
                        self.dynamic_warning_list_layout.add_widget(
                            FaultRow(
                                fault=faults[starting_index + index],
                                clearable=clearability[starting_index + index],
                                fault_code=fault_codes[starting_index + index]
                            )
                        )
                # If the amount if widgets didn't change
                elif new_widget_amount == 0:
                    for index, child in enumerate(self.dynamic_warning_list_layout.children):
                        child.fault = faults[index]
                        child.clearable = clearability[index]
                        child.fault_code = fault_codes[index]
                # Finally, if we have less faults now
                elif new_widget_amount < 0:
                    for index, (child, _) in enumerate(zip(self.dynamic_warning_list_layout.children, faults)):
                        child.fault = faults[index]
                        child.clearable = clearability[index]
                        child.fault_code = fault_codes[index]

                    for index in range(new_widget_amount, 0):
                        self.dynamic_warning_list_layout.remove_widget(self.dynamic_warning_list_layout.children[index])

                if new_widget_amount != 0:
                    height = 0
                    for child in self.dynamic_warning_list_layout.children:
                        height += child.height
                    self.dynamic_warning_list_layout.height = height
                    self.dynamic_warning_list_layout.do_layout()

            Clock.schedule_once(_wrap)

        else:
            # In case there are no warnings, clear the dynamic_warning_list_layout
            # (remove all children) and hide it by setting its height to 0.
            for child in self.dynamic_warning_list_layout.children:
                self.dynamic_warning_list_layout.remove_widget(child)
            self.dynamic_warning_list_layout.height = 0

        if self.manager.fm.error_detected is True or self.manager.fm.warning_detected is True:
            self.manager.tpm.add_tab("status")

    def parse_max31856_fault_code(self, fault_code):
        """Creates a string with the fault codes returned by MAX31856.

        Args:
            fault_code (int): MAX31856 fault code

        Returns:
            string: Message containing present fault codes in hex format
        """
        fault_codes = ["", "", "", "", "", "", ""]
        output = ""
        count = 0
        comma_count = 0

        if fault_code & 0x01:
            fault_codes[0] = 0x01
            count += 1
        if fault_code & 0x02:
            fault_codes[1] = 0x02
            count += 1
        if fault_code & 0x04:
            fault_codes[2] = 0x04
            count += 1
        if fault_code & 0x08:
            fault_codes[3] = 0x08
            count += 1
        if fault_code & 0x20:
            fault_codes[4] = 0x20
            count += 1
        if fault_code & 0x40:
            fault_codes[5] = 0x40
            count += 1
        if fault_code & 0x80:
            fault_codes[6] = 0x80
            count += 1

        for fault_code in fault_codes:
            if fault_code != "":
                output += str("0x{:02x}".format(fault_code))
                comma_count += 1
            if count > 1 and comma_count < count and fault_code != fault_codes[-1]:
                output += ", "
        return output

    def parse_open_door_names(self):
        """Creates a string with the names of doors that are opened.

        Returns:
            string: String with a message about open doors
        """
        if sum(self.manager.ccm.DOORS_OPENED) == 0:
            return ""

        elif sum(self.manager.ccm.DOORS_OPENED) == 1:
            for index, door in enumerate(self.manager.ccm.DOORS_OPENED):
                if door:
                    return " (" + DOOR_NAMES[index] + ")"

        elif sum(self.manager.ccm.DOORS_OPENED) > 1:
            door_names = []
            for index, door in enumerate(self.manager.ccm.DOORS_OPENED):
                if door:
                    door_names.append(DOOR_NAMES[index])

            return " ({} and {})".format(", ".join(door_names[:-1]), door_names[-1])

    def on_warning_detected(self, *args):
        """Called if a warning is detected.
        """
        if args[1]:
            self.screen_text.size_hint_y = None
            self.screen_text.opacity = 1
            self.warning_title.opacity = 1
            self.screen_text.height = self.screen_text.texture_size[1]
            self.warning_title.height = self.warning_title.texture_size[1]
            self.screen_text_spacing.height = self.status_text_spacing.height
            self.warning_spacing.height = self.status_text_spacing.height
        else:
            if self.manager.fm.error_detected is False:
                self.screen_text.opacity = 0
                self.screen_text.height = 0
                self.screen_text_spacing.height = 0
            self.warning_title.opacity = 0
            self.warning_title.height = 0
            self.warning_spacing.height = 0
        self.manager.tpm.update_dismiss_locked()

    def on_error_detected(self, *args):
        """Called if an error is detected.
        """
        if args[1]:
            self.screen_text.size_hint_y = None
            self.screen_text.opacity = 1
            self.error_title.opacity = 1
            self.screen_text.height = self.screen_text.texture_size[1]
            self.error_title.height = self.error_title.texture_size[1]
            self.screen_text_spacing.height = self.status_text_spacing.height
            self.error_spacing.height = self.status_text_spacing.height
        else:
            if self.manager.fm.warning_detected is False:
                self.screen_text.opacity = 0
                self.screen_text.height = 0
                self.screen_text_spacing.height = 0
            self.error_title.opacity = 0
            self.error_title.height = 0
            self.error_spacing.height = 0
        self.manager.tpm.update_dismiss_locked()

    def close(self):
        """Closes itself (removes itself from TabbedPopupManager).
        """
        
        self.manager.tpm.remove_tab(self)
