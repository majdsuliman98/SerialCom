import json
from picamera import PiCamera
from picamera.array import PiRGBArray
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.logger import Logger
from kivy.uix.tabbedpanel import TabbedPanelItem
from kivy.properties import ListProperty, NumericProperty, ObjectProperty

from TouchRippleButton import TouchRippleButton

from Constants import SETTINGS_FILE, OPACITY_FULL
from Faults import (
    WARNING_PICAMERA_GENERAL,
    WARNING_PICAMERA_DEPRECATED,
    WARNING_PICAMERA_FALLBACK,
    WARNING_PICAMERA_RESIZER_ENCODING,
    WARNING_PICAMERA_ALPHA_STRIPPING,
    ERROR_PICAMERA_GENERAL,
    ERROR_PICAMERA_VALUE_ERROR,
    ERROR_PICAMERA_RUNTIME_ERROR,
    ERROR_PICAMERA_CLOSED,
    ERROR_PICAMERA_NOT_RECORDING,
    ERROR_PICAMERA_ALREADY_RECORDING,
    ERROR_PICAMERA_MMAL,
    UNKNOWN_FAULT
)
from Strings import TAB_NAMES, VIDEO_TAB

Builder.load_file("tabs/VideoFeedTab.kv")


# ! EXCEPTION HANDLER (DECORATOR) IS NOT TESTED AT ALL
def picamera_exception_handler(function):
    """Definition of exception handler decorator function for Pi Camera

    Args:
        function (callable): Function that is being decorated with this decorator
    """
    def inner_function(*args, **kwargs):
        """Exception handling.
        """
        try:
            self = args[0]
            function(*args, **kwargs)
            fault_states = self.manager.fm.fault_states
            fault_codes = self.manager.fm.fault_codes

        # Exception list:
        # https://picamera.readthedocs.io/en/release-1.12/api_exc.html

        except PiCamera.PiCameraWarning:
            fault_states[fault_codes.index(WARNING_PICAMERA_GENERAL["code"])] = True
            Logger.exception("VideoFeedTab: WARNING_PICAMERA_GENERAL")
            self.error_message_layout.opacity = OPACITY_FULL
        except PiCamera.PiCameraDeprecated:
            fault_states[fault_codes.index(WARNING_PICAMERA_DEPRECATED["code"])] = True
            Logger.exception("VideoFeedTab: WARNING_PICAMERA_DEPRECATED")
            self.error_message_layout.opacity = OPACITY_FULL

        except PiCamera.PiCameraFallback:
            fault_states[fault_codes.index(WARNING_PICAMERA_FALLBACK["code"])] = True
            Logger.exception("VideoFeedTab: WARNING_PICAMERA_FALLBACK")
            self.error_message_layout.opacity = OPACITY_FULL

        except PiCamera.PiCameraResizerEncoding:
            fault_states[fault_codes.index(WARNING_PICAMERA_RESIZER_ENCODING["code"])] = True
            Logger.exception("VideoFeedTab: WARNING_PICAMERA_RESIZER_ENCODING")
            self.error_message_layout.opacity = OPACITY_FULL

        except PiCamera.PiCameraAlphaStripping:
            fault_states[fault_codes.index(WARNING_PICAMERA_ALPHA_STRIPPING["code"])] = True
            Logger.exception("VideoFeedTab: WARNING_PICAMERA_ALPHA_STRIPPING")
            self.error_message_layout.opacity = OPACITY_FULL

        except PiCamera.PiCameraError:
            fault_states[fault_codes.index(ERROR_PICAMERA_GENERAL["code"])] = True
            Logger.exception("VideoFeedTab: ERROR_PICAMERA_GENERAL")
            self.error_message_layout.opacity = OPACITY_FULL

        except PiCamera.PiCameraValueError:
            fault_states[fault_codes.index(ERROR_PICAMERA_VALUE_ERROR["code"])] = True
            Logger.exception("VideoFeedTab: ERROR_PICAMERA_VALUE_ERROR")
            self.error_message_layout.opacity = OPACITY_FULL

        except PiCamera.PiCameraRuntimeError:
            fault_states[fault_codes.index(ERROR_PICAMERA_RUNTIME_ERROR["code"])] = True
            Logger.exception("VideoFeedTab: ERROR_PICAMERA_RUNTIME_ERROR")
            self.error_message_layout.opacity = OPACITY_FULL

        except PiCamera.PiCameraClosed:
            fault_states[fault_codes.index(ERROR_PICAMERA_CLOSED["code"])] = True
            Logger.exception("VideoFeedTab: ERROR_PICAMERA_CLOSED")
            self.error_message_layout.opacity = OPACITY_FULL

        except PiCamera.PiCameraNotRecording:
            fault_states[fault_codes.index(ERROR_PICAMERA_NOT_RECORDING["code"])] = True
            Logger.exception("VideoFeedTab: ERROR_PICAMERA_NOT_RECORDING")
            self.error_message_layout.opacity = OPACITY_FULL

        except PiCamera.PiCameraAlreadyRecording:
            fault_states[fault_codes.index(ERROR_PICAMERA_ALREADY_RECORDING["code"])] = True
            Logger.exception("VideoFeedTab: ERROR_PICAMERA_ALREADY_RECORDING")
            self.error_message_layout.opacity = OPACITY_FULL

        except PiCamera.PiCameraMMALError:
            fault_states[fault_codes.index(ERROR_PICAMERA_MMAL["code"])] = True
            Logger.exception("VideoFeedTab: ERROR_PICAMERA_MMAL")
            self.error_message_layout.opacity = OPACITY_FULL

        except Exception as exception:
            fault_states[fault_codes.index(UNKNOWN_FAULT["code"])] = True
            Logger.exception("VideoFeedTab: " + str(exception))
            self.error_message_layout.opacity = OPACITY_FULL

    return inner_function


class VideoFeedTab(TabbedPanelItem, TouchRippleButton):
    """Implementation of a tab used for visual monitoring of the insides
    of the machine and, by that, the processes.
    """
    COLOR_ICON = ListProperty([])
    COLOR_BACKGROUND = ListProperty([])

    brightness = NumericProperty(50)
    contrast = NumericProperty(0)
    exposure_compensation = NumericProperty(0)
    sharpness = NumericProperty(0)
    zoom = ListProperty([0, 0, 1, 1, 1])

    main_layout = ObjectProperty(None)
    error_message_layout = ObjectProperty(None)
    error_message_label = ObjectProperty(None)
    control_layout = ObjectProperty(None)

    brightness_label = ObjectProperty(None)
    contrast_label = ObjectProperty(None)
    exposure_label = ObjectProperty(None)
    sharpness_label = ObjectProperty(None)
    zoom_label = ObjectProperty(None)
    lighting_label = ObjectProperty(None)

    lighting_button_label = ObjectProperty(None)
    lighting_button = ObjectProperty(None)

    def __init__(self, manager, **kwargs):
        super(VideoFeedTab, self).__init__(**kwargs)
        self.manager = manager
        self.manager.bind(COLOR_BACKGROUND=self.on_theme_change)
        self.manager.bind(lang=self.on_lang_change)
        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_ICON = self.manager.COLOR_ICON
        self.text = TAB_NAMES["video"][self.manager.lang]
        self.feed_window = (76, 214, 420, 315)  # Preview's pos_x, pos_y, size_x, size_y
        self.control_layout.height = 336
        self.content = self.main_layout
        self.streaming = False
        self.lighting_button.fbind('on_release', self.manager.ccm.toggle_led_panel)
        self.lighting_button.fbind('on_release', self.lighting_button_update)
        self.save_schedule = None
        self.error_message_label.text = VIDEO_TAB["exception_camera"][self.manager.lang]
        self.brightness_label.text = VIDEO_TAB["brightness"][self.manager.lang]
        self.contrast_label.text = VIDEO_TAB["contrast"][self.manager.lang]
        self.exposure_label.text = VIDEO_TAB["exposure"][self.manager.lang]
        self.sharpness_label.text = VIDEO_TAB["sharpness"][self.manager.lang]
        self.zoom_label.text = VIDEO_TAB["zoom"][self.manager.lang]
        self.lighting_label.text = VIDEO_TAB["toggle_lighting"][self.manager.lang]
        self.lighting_button_label.text = VIDEO_TAB["turn_off"][self.manager.lang]

    def on_lang_change(self, *args):
        """Reload tab strings on language change.
        """
        self.error_message_label.text = VIDEO_TAB["exception_camera"][self.manager.lang]
        self.brightness_label.text = VIDEO_TAB["brightness"][self.manager.lang]
        self.contrast_label.text = VIDEO_TAB["contrast"][self.manager.lang]
        self.exposure_label.text = VIDEO_TAB["exposure"][self.manager.lang]
        self.sharpness_label.text = VIDEO_TAB["sharpness"][self.manager.lang]
        self.zoom_label.text = VIDEO_TAB["zoom"][self.manager.lang]
        self.lighting_label.text = VIDEO_TAB["toggle_lighting"][self.manager.lang]
        self.lighting_button_label.text = VIDEO_TAB["turn_off"][self.manager.lang]

    def on_theme_change(self, *args):
        """Updates tab's color scheme.
        """
        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_ICON = self.manager.COLOR_ICON

    def lighting_button_update(self, *args):
        """Changes the current lighting button text.
        """
        if self.lighting_button_label.text == VIDEO_TAB["turn_off"][self.manager.lang]:
            self.lighting_button_label.text = VIDEO_TAB["turn_on"][self.manager.lang]
        else:
            self.lighting_button_label.text = VIDEO_TAB["turn_off"][self.manager.lang]

    @picamera_exception_handler
    def start_livefeed(self):
        """Starts camera feed or unpauses it if self.streaming is set to True.
        """
        if self.streaming:
            self.unpause_livefeed()
        else:
            self.camera = PiCamera()
            self.camera.vflip = False
            self.camera.resolution = (640, 480)
            self.read_settings()
            self.adjust_layout()
            self.rawCapture = PiRGBArray(self.camera, size=self.camera.resolution)
            self.camera.start_preview(fullscreen=False, window=self.feed_window)
            self.manager.ccm.toggle_led_panel(state=True)
            self.streaming = True

    @picamera_exception_handler
    def pause_livefeed(self):
        """Pause livefeed preview by stopping the camera preview and turning
        off the LED panel.
        """
        self.camera.stop_preview()
        self.manager.ccm.toggle_led_panel(state=False)

    @picamera_exception_handler
    def unpause_livefeed(self):
        """Unpause camera feed after bringing back the video tab to
        the foreground. Adjusts the layout and turns of the LED panel.
        """
        self.adjust_layout()
        self.camera.start_preview(fullscreen=False, window=self.feed_window)
        self.manager.ccm.toggle_led_panel(state=True)
        self.lighting_button_label.text = VIDEO_TAB["turn_off"][self.manager.lang]

    @picamera_exception_handler
    def stop_livefeed(self):
        """Stops the live feed and closes and cleans up the camera object.
        """
        self.manager.ccm.toggle_led_panel(state=False)
        self.lighting_button_label.text = VIDEO_TAB["turn_on"][self.manager.lang]
        self.camera.stop_preview()
        self.camera.close()
        self.streaming = False
        self.close()

    @picamera_exception_handler
    def adjust_camera_settings(self, setting, change):
        """Takes care of adjusting the camera settings and saves them to
        JSON file every 2 seconds.

        Args:
            setting (string): Name of the setting that has to be adjusted
            change (int): Value that will be added to current setting value
        """

        def save_settings(*args):
            """Saves current camera settings to JSON file.
            """
            try:
                with open(SETTINGS_FILE, "r+") as file:
                    loaded = json.load(file)

                loaded["brightness"] = self.brightness
                loaded["contrast"] = self.contrast
                loaded["exposure_compensation"] = self.exposure_compensation
                loaded["sharpness"] = self.sharpness
                loaded["zoom"] = self.zoom

            except IOError:
                # TODO: Settings file read error - add fault report
                Logger.exception(VIDEO_TAB["exception_file_read"][self.manager.lang])

            # If any of the keys haven't been found in settings file
            except KeyError:
                loaded["brightness"] = self.brightness
                loaded["contrast"] = self.contrast
                loaded["exposure_compensation"] = self.exposure_compensation
                loaded["sharpness"] = self.sharpness

                try:
                    with open(SETTINGS_FILE, "w+") as file:
                        json.dump(loaded, file)

                except IOError:
                    # TODO: Settings file write error - add fault report
                    Logger.exception(VIDEO_TAB["exception_file_write"][self.manager.lang])

            else:
                try:
                    with open(SETTINGS_FILE, "w+") as file:
                        json.dump(loaded, file)

                except IOError:
                    # TODO: Settings file write error - add fault report
                    Logger.exception(VIDEO_TAB["exception_file_write"][self.manager.lang])

        if setting == "brightness":
            if 0 <= self.camera.brightness <= 100:
                self.camera.brightness += change
                self.brightness = self.camera.brightness
            else:
                pass
        elif setting == "contrast":
            if -100 <= self.camera.contrast <= 100:
                self.camera.contrast += change
                self.contrast = self.camera.contrast
            else:
                pass
        elif setting == "exposure":
            if -25 <= self.camera.exposure_compensation <= 25:
                self.camera.exposure_compensation += change
                self.exposure_compensation = self.camera.exposure_compensation
            else:
                pass
        elif setting == "sharpness":
            if -100 <= self.camera.sharpness <= 100:
                self.camera.sharpness += change
                self.sharpness = self.camera.sharpness
            else:
                pass
        elif setting == "zoom":
            if change > 0:
                if self.zoom[4] == 1:
                    self.zoom = (0.125, 0.125, 0.75, 0.75, 2)
                elif self.zoom[4] == 2:
                    self.zoom = (0.25, 0.25, 0.5, 0.5, 4)
                elif self.zoom[4] == 4:
                    self.zoom = (0.375, 0.375, 0.25, 0.25, 8)
                elif self.zoom[4] == 8:
                    pass
            elif change < 0:
                if self.zoom[4] == 1:
                    pass
                elif self.zoom[4] == 2:
                    self.zoom = (0, 0, 1, 1, 1)
                elif self.zoom[4] == 4:
                    self.zoom = (0.125, 0.125, 0.75, 0.75, 2)
                elif self.zoom[4] == 8:
                    self.zoom = (0.25, 0.25, 0.5, 0.5, 4)
            else:
                pass
            self.camera.zoom = self.zoom[0:4]
        else:
            return

        if self.save_schedule is not None:
            self.save_schedule.cancel()

        self.save_schedule = Clock.schedule_once(save_settings, 2)

    @picamera_exception_handler
    def read_settings(self, *args):
        """Reads camera settings from JSON file.
        """
        try:
            with open(SETTINGS_FILE, "r+") as file:
                loaded = json.load(file)

            self.brightness = loaded["brightness"]
            self.contrast = loaded["contrast"]
            self.exposure_compensation = loaded["exposure_compensation"]
            self.sharpness = loaded["sharpness"]

        except IOError:
            # TODO: Settings file read error - add fault report
            self.brightness = self.camera.brightness
            self.contrast = self.camera.contrast
            self.exposure_compensation = self.camera.exposure_compensation
            self.sharpness = self.camera.sharpness
            Logger.exception(VIDEO_TAB["exception_file_read"][self.manager.lang])

        # If any of the keys haven't been found in settings file
        except KeyError as exception:
            self.brightness = self.camera.brightness
            self.contrast = self.camera.contrast
            self.exposure_compensation = self.camera.exposure_compensation
            self.sharpness = self.camera.sharpness
            Logger.exception("VideoFeedTab: " + str(exception))

        else:
            self.camera.brightness = self.brightness
            self.camera.contrast = self.contrast
            self.camera.exposure_compensation = self.exposure_compensation
            self.camera.sharpness = self.sharpness

    def adjust_layout(self):
        """Adjust the control layout paddings and camera feed
        preview window size to align properly with the available
        space on the tab (depending on the number of tabs that are open).
        """
        number_of_tabs = len(self.manager.tpm.tabbed_panel.tab_list)
        if number_of_tabs == 1:
            self.feed_window = (76, 190, 420, 315)
            self.control_layout.padding[1] = -8
            self.control_layout.padding[3] = 40
            self.control_layout.do_layout()
        elif number_of_tabs > 1:
            self.feed_window = (76, 214, 420, 315)
            self.control_layout.padding[1] = 16
            self.control_layout.padding[3] = 16
            self.control_layout.do_layout()

    def feed_visibility_callback(self):
        """Pauses and unpauses the video stream depending on the
        if the video tab is the currently displayed one or not.
        """
        tpm = self.manager.tpm
        if tpm.tabbed_panel.current_tab is not tpm.video_tab:
            self.pause_livefeed()
        else:
            self.unpause_livefeed()

    def close(self):
        """Closes itself (removes itself from TabbedPopupManager) and stops
        the livefeed.
        """
        if self.streaming:
            self.stop_livefeed()
        self.manager.tpm.remove_tab(self)
