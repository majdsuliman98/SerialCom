from kivy.lang import Builder
from kivy.properties import ObjectProperty, ListProperty
from kivy.uix.tabbedpanel import TabbedPanelItem

from TouchRippleButton import TouchRippleButton

from Buttons import bind_callback, unbind_all_callbacks
from Images import ICON_BUTTON_CANCEL, ICON_BUTTON_ACCEPT, ICON_STATUS_DOWNLOADING
from Strings import CONFIRMATION_TAB, PROCESS_COMMON, TAB_NAMES
from Constants import (
    TYPE_ID_NOZZLE,
    TYPE_ID_SKIMMERS,
    TYPE_ID_CRUCIBLE
)
Builder.load_file("tabs/ConfirmationTab.kv")


class ConfirmationTab(TabbedPanelItem, TouchRippleButton):
    """Implementation of a tab used for confirming actions like
    process stopping, removing consumable or accepting some communicates
    that might be shown to the user.
    """
    COLOR_ICON = ListProperty([])
    COLOR_BACKGROUND = ListProperty([])
    screen_text = ObjectProperty(None)
    main_layout = ObjectProperty(None)

    def __init__(self, manager, **kwargs):
        super(ConfirmationTab, self).__init__(**kwargs)
        self.manager = manager
        self.manager.bind(COLOR_BACKGROUND=self.on_theme_change)
        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_ICON = self.manager.COLOR_ICON
        self.text = TAB_NAMES["confirmation"][self.manager.lang]
        self.content = self.main_layout
        self.consumable_to_remove = ""
        
        self.view = "cancel_process"

    def on_theme_change(self, *args):
        """Updates tab's color scheme.
        """
        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_ICON = self.manager.COLOR_ICON

    def on_enter(self):
        """Sets up the layout after opening the tab.
        """
        self.manager.tpm.video_tab_locked = True

        if self.view == "cancel_process":
            self.screen_text.text = CONFIRMATION_TAB["cancel_process_message"][self.manager.lang]
            self.manager.tpm.button_1_area.disabled = False
            self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_1_label.text = PROCESS_COMMON["no"][self.manager.lang]
            self.manager.tpm.button_2_label.text = PROCESS_COMMON["yes"][self.manager.lang]
            self.manager.tpm.button_1_icon.source = ICON_BUTTON_CANCEL
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_ACCEPT
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_1, self.close)
            bind_callback(self.manager.tpm.button_2, self.cancel_process)
            self.manager.tpm.recalculate_buttons()

        elif self.view == "remove_consumable":
            self.screen_text.text = CONFIRMATION_TAB["remove_consumable_message"][self.manager.lang]
            self.manager.tpm.button_1_area.disabled = False
            self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_1_label.text = PROCESS_COMMON["no"][self.manager.lang]
            self.manager.tpm.button_2_label.text = PROCESS_COMMON["yes"][self.manager.lang]
            self.manager.tpm.button_1_icon.source = ICON_BUTTON_CANCEL
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_ACCEPT
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_1, self.close)
            bind_callback(self.manager.tpm.button_2, self.remove_consumable)
            self.manager.tpm.recalculate_buttons()

        elif self.view == "process_stopped":
            self.screen_text.text = CONFIRMATION_TAB["process_stopped_message"][self.manager.lang]
            self.manager.tpm.button_1_area.hidden = True
            self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_2_label.text = PROCESS_COMMON["accept"][self.manager.lang]
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_ACCEPT
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_1, self.close)
            bind_callback(self.manager.tpm.button_2, self.cancel_process)
            self.manager.tpm.recalculate_buttons()

        elif self.view == "change_cruicible":
            self.screen_text.text = CONFIRMATION_TAB["change_cruicible_message"][self.manager.lang]
            self.manager.tpm.button_1_area.disabled = False
            self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_1_label.text = PROCESS_COMMON["no"][self.manager.lang]
            self.manager.tpm.button_2_label.text = PROCESS_COMMON["yes"][self.manager.lang]
            self.manager.tpm.button_1_icon.source = ICON_BUTTON_CANCEL
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_ACCEPT
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_1, self.close)
            # bind_callback(self.manager.tpm.button_2, self.change_cruicible)
            self.manager.tpm.recalculate_buttons()
        
        elif self.view == "change_nozzle":
            self.screen_text.text = CONFIRMATION_TAB["change_nozzle_message"][self.manager.lang]
            self.manager.tpm.button_1_area.disabled = False
            self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_1_label.text = PROCESS_COMMON["no"][self.manager.lang]
            self.manager.tpm.button_2_label.text = PROCESS_COMMON["yes"][self.manager.lang]
            self.manager.tpm.button_1_icon.source = ICON_BUTTON_CANCEL
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_ACCEPT
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_1, self.close)
            bind_callback(self.manager.tpm.button_2, self.change_nozzle)
            self.manager.tpm.recalculate_buttons()
        
        elif self.view == "change_skimmer":
            self.screen_text.text = CONFIRMATION_TAB["change_skimmer_message"][self.manager.lang]
            self.manager.tpm.button_1_area.disabled = False
            self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_1_label.text = PROCESS_COMMON["no"][self.manager.lang]
            self.manager.tpm.button_2_label.text = PROCESS_COMMON["yes"][self.manager.lang]
            self.manager.tpm.button_1_icon.source = ICON_BUTTON_CANCEL
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_ACCEPT
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_1, self.close)
            bind_callback(self.manager.tpm.button_2, self.change_skimmer)
            self.manager.tpm.recalculate_buttons()
        elif self.view == "delete_profile":
            self.screen_text.text = "Are you sure you want to delete "+self.manager.get_screen("preprocess").profile_choice_spinner.text+" profile?"
            self.manager.tpm.button_1_area.disabled = False
            self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_1_label.text = PROCESS_COMMON["no"][self.manager.lang]
            self.manager.tpm.button_2_label.text = PROCESS_COMMON["yes"][self.manager.lang]
            self.manager.tpm.button_1_icon.source = ICON_BUTTON_CANCEL
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_ACCEPT
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_1, self.close)
            bind_callback(self.manager.tpm.button_2, self.delete_profile)
            
            self.manager.tpm.recalculate_buttons()

        elif self.view == "edit_profile":
            self.screen_text.text = "Are you sure you want to edit "+self.manager.get_screen("preprocess").profile_choice_spinner.text+" profile?"
            self.manager.tpm.button_1_area.disabled = False
            self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_1_label.text = PROCESS_COMMON["no"][self.manager.lang]
            self.manager.tpm.button_2_label.text = PROCESS_COMMON["yes"][self.manager.lang]
            self.manager.tpm.button_1_icon.source = ICON_BUTTON_CANCEL
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_ACCEPT
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_1, self.close)
            bind_callback(self.manager.tpm.button_2, self.edit_profile)
            
            self.manager.tpm.recalculate_buttons()

        elif self.view == "save_changes":
            self.screen_text.text = "Are you sure you want to save changes?"
            self.manager.tpm.button_1_area.disabled = False
            self.manager.tpm.button_2_area.disabled = False
            self.manager.tpm.button_1_label.text = PROCESS_COMMON["no"][self.manager.lang]
            self.manager.tpm.button_2_label.text = PROCESS_COMMON["yes"][self.manager.lang]
            self.manager.tpm.button_1_icon.source = ICON_BUTTON_CANCEL
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_ACCEPT
            unbind_all_callbacks(self.manager.tpm.button_1)
            unbind_all_callbacks(self.manager.tpm.button_2)
            bind_callback(self.manager.tpm.button_1, self.close)
            bind_callback(self.manager.tpm.button_2, self.save_changes)
            self.manager.tpm.recalculate_buttons()


    def change_hardware_view(self):
        """Opens up the ConfirmationTab with change hardware confirmation.
        """
        if self.manager.get_screen("main").current_screen == "change_cruicible":
            self.view = "change_cruicible"
        elif self.manager.get_screen("main").current_screen == "change_nozzles":
            self.view = "change_nozzle"
        elif self.manager.get_screen("main").current_screen == "change_skimmer":
            self.view = "change_skimmer"
        self.on_enter()

    def delete_profile_view(self):
        self.view = "delete_profile"
        self.on_enter()

    def edit_profile_view(self):
        self.view = "edit_profile"
        self.on_enter()

    def save_changes_view(self):
        self.view = "save_changes"
        self.on_enter()

    def cancel_process_view(self):
        """Opens up the ConfirmationTab with process cancelation message.
        """
        self.view = "cancel_process"
        self.on_enter()

    def remove_consumable_view(self):
        """Opens up the ConfirmationTab with consumable removal message.
        """
        self.view = "remove_consumable"
        self.on_enter()

    def process_stopped_view(self):
        """Opens up the ConfirmationTab with consumable removal message.
        """
        self.view = "process_stopped"
        self.on_enter()

    def cancel_process(self, *args):
        """Cancels current process.
        """
        self.manager.ccm.PROCESS_IN_PROGRESS=False

        # self.manager.get_screen("MetalCastingProcess").cancel_cont_temp()
        self.manager.ccm.TEMP_CONTROL_ON = False
        self.manager.current = 'main'
        self.close()

    def remove_consumable(self, *args):
        """Sends message through phone to API to remove selected consumable
        by its serial_id.
        """
        self.manager.bcm.request_consumable_removal(self.consumable_to_remove)
        self.manager.bcm.consumables_up_to_date = False
        # self.manager.get_screen("main").begin_consumable_data_reading_thread(self.type_id)
        # self.manager.dm.update_data()
        self.manager.bcm.data_status_icon = ICON_STATUS_DOWNLOADING

        if  self.manager.get_screen("main").current_screen == "crucibles":
            self.manager.get_screen("main").crucibles_screen()
        elif self.manager.get_screen("main").current_screen == "nozzles":
            self.manager.get_screen("main").nozzles_screen()
        elif self.manager.get_screen("main").current_screen == "skimmers":
            self.manager.get_screen("main").skimmer_screen()
        elif self.manager.get_screen("main").current_screen == "materials":
            self.manager.get_screen("main").casting_materials_screen()
        else: pass

        # self.manager.get_screen("main").begin_consumable_data_reading_thread(self.type_id)
        # self.manager.dm.update_data()
        
        self.close()

    def delete_profile(self,*args):
        self.manager.get_screen("preprocess").delete_profile()
        self.close()
    
    def edit_profile(self,*args):
        self.manager.get_screen("preprocess").edit_profile()
        self.close()

    def save_changes(self,*args):
        if self.manager.get_screen("preprocess").custom == True:
            self.manager.get_screen("preprocess").edit_profile_custom()
        else:
            self.manager.get_screen("preprocess").edit_profile_stl()
        self.close()

    def close(self, *args):
        """Closes itself (removes itself from TabbedPopupManager).
        """
        if self.manager.get_screen("main").current_screen == "change_cruicible":
            self.manager.get_screen("main").current_screen = "crucibles"
        elif self.manager.get_screen("main").current_screen == "change_nozzles":
            self.manager.get_screen("main").current_screen = "nozzles"
        elif self.manager.get_screen("main").current_screen == "change_skimmer":
            self.manager.get_screen("main").current_screen = "skimmers"
        self.manager.tpm.video_tab_locked = False
        self.manager.tpm.remove_tab(self)

    def change_cruicible(self, *args):
        self.manager.get_screen("MetalCastingProcess").reset_material()
        self.manager.get_screen("main").current_screen = "crucibles"
        self.manager.tpm.video_tab_locked = False
        self.manager.tpm.remove_tab(self)

    def change_nozzle(self, *args):
        self.manager.dm.update_new_hardware(TYPE_ID_NOZZLE)
        self.manager.get_screen("main").nozzles_screen()
        self.manager.tpm.video_tab_locked = False
        self.manager.tpm.remove_tab(self)

    def change_skimmer(self, *args):
        self.manager.dm.update_new_hardware(TYPE_ID_SKIMMERS)
        self.manager.get_screen("main").skimmer_screen()
        self.manager.tpm.video_tab_locked = False
        self.manager.tpm.remove_tab(self)