from kivy.lang import Builder
from kivy.uix.tabbedpanel import TabbedPanelItem
from kivy.properties import ObjectProperty, ListProperty
from kivy.logger import Logger
from TouchRippleButton import TouchRippleButton

from Buttons import bind_callback, unbind_all_callbacks
from Images import ICON_BUTTON_BACK
from Strings import INFO_TAB, FAULT_TITLES, FAULT_DESCRIPTIONS, TAB_NAMES

Builder.load_file('tabs/InfoTab.kv')


class InfoTab(TabbedPanelItem, TouchRippleButton):
    """Implementation of a tab used to display user guide and information about
    faults that are present.
    """
    manager = ObjectProperty(None)
    COLOR_ICON = ListProperty([])
    COLOR_BACKGROUND = ListProperty([])
    screen_text = ObjectProperty(None)
    main_layout = ObjectProperty(None)

    fault_description_title = ObjectProperty(None)
    fault_description_content = ObjectProperty(None)
    table_of_contents_layout = ObjectProperty(None)
    description_layout = ObjectProperty(None)

    def __init__(self, manager, **kwargs):
        super(InfoTab, self).__init__(**kwargs)
        self.manager = manager
        self.manager.bind(COLOR_BACKGROUND=self.on_theme_change)
        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_ICON = self.manager.COLOR_ICON
        self.text = TAB_NAMES["info"][self.manager.lang]
        self.content = self.main_layout
        self.fault_code = -1

    def on_theme_change(self, *args):
        """Updates tab's color scheme.
        """
        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_ICON = self.manager.COLOR_ICON

    def on_enter(self):
        """Sets up the layout after opening the tab.
        """
        if self.view == "default":
            self.table_of_contents_layout.height = self.table_of_contents_layout.minimum_height
            self.table_of_contents_layout.opacity = 1
            self.description_layout.height = 0
            self.description_layout.opacity = 0
            self.manager.tpm.button_1_area.hidden = True
            self.manager.tpm.button_2_area.hidden = True

        else:
            def _change_to_default_view(*args):
                unbind_all_callbacks(self.manager.tpm.button_2)
                self.manager.tpm.button_2_area.hidden = True
                self.open_default_view()

            self.fault_description_title.text = FAULT_TITLES[self.fault_code][self.manager.lang]
            self.fault_description_content.text = FAULT_DESCRIPTIONS[self.fault_code][self.manager.lang]
            self.table_of_contents_layout.height = 0
            self.table_of_contents_layout.opacity = 0
            self.table_of_contents_layout.do_layout()
            self.description_layout.height = self.description_layout.minimum_height
            self.description_layout.opacity = 1

            self.manager.tpm.button_2_label.text = INFO_TAB["back_to_main"][self.manager.lang]
            self.manager.tpm.button_2_icon.source = ICON_BUTTON_BACK
            self.manager.tpm.recalculate_buttons()
            self.manager.tpm.button_1_area.hidden = True
            self.manager.tpm.button_2_area.disabled = False
            bind_callback(self.manager.tpm.button_2, _change_to_default_view)

        self.manager.tpm.button_1_area.hidden = True

    def open_default_view(self):
        """Opens up the default view (main page of the guide).
        """
        self.view = "default"
        self.on_enter()

    def open_by_fault_code(self, fault_code):
        """Opens up the InfoTab with fault information shown.

        Args:
            fault_code (int): Fault code which info has to be shown.
        """
        self.view = "fault_code"
        self.fault_code = fault_code
        self.on_enter()

    def close(self):
        """Closes itself (removes itself from TabbedPopupManager).
        """

        self.manager.tpm.remove_tab(self)
