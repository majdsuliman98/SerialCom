"""Fault (warning and error) codes definitions
"""

# ! Error codes:
ERROR_ARDUINO_USB0_INIT_CONNECTION = {"code": 0, "clearable": False, "block_process": True}
ERROR_ARDUINO_USB1_INIT_CONNECTION = {"code": 1, "clearable": False, "block_process": True}
ERROR_MCP23017_INIT_CONNECTION = {"code": 2, "clearable": False, "block_process": True}
ERROR_SOFTWARE_ID_MISMATCH = {"code": 3, "clearable": False, "block_process": True}
ERROR_MACHINE_ID_MISMATCH = {"code": 4, "clearable": False, "block_process": True}
ERROR_CRUCIBLE_SENSOR_1 = {"code": 5, "clearable": False, "block_process": True}
ERROR_CRUCIBLE_SENSOR_2 = {"code": 6, "clearable": False, "block_process": True}
ERROR_DIE_LEFT_SENSOR = {"code": 7, "clearable": False, "block_process": True}
ERROR_DIE_RIGHT_SENSOR = {"code": 8, "clearable": False, "block_process": True}
ERROR_OPEN_DOORS = {"code": 9, "clearable": False, "block_process": True}
ERROR_ARDUINO_CONTROL_RESPONSE_FAILSAFE_TRIGGER = {"code": 10, "clearable": True, "block_process": True}
ERROR_ARDUINO_STEPPER_RESPONSE_FAILSAFE_TRIGGER = {"code": 11, "clearable": False, "block_process": True}
ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE = {"code": 12, "clearable": False, "block_process": True}
ERROR_TEMPERATURE_TOO_HIGH_DIES = {"code": 13, "clearable": False, "block_process": True}
ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_1 = {"code": 14, "clearable": False, "block_process": True}
ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_2 = {"code": 15, "clearable": False, "block_process": True}
ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_LEFT = {"code": 16, "clearable": False, "block_process": True}
ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_RIGHT = {"code": 17, "clearable": False, "block_process": True}
ERROR_TEMPERATURE_TOO_HIGH_AMBIENT = {"code": 18, "clearable": False, "block_process": True}
ERROR_HUMIDITY_TOO_HIGH_AMBIENT = {"code": 19, "clearable": False, "block_process": True}
ERROR_ARDUINO_CONTROL_READ = {"code": 20, "clearable": False, "block_process": True}
ERROR_ARDUINO_STEPPER_READ = {"code": 21, "clearable": False, "block_process": True}
ERROR_MPU9250_INIT_CONNECTION = {"code": 22, "clearable": False, "block_process": True}
ERROR_NANO_INIT_CONNECTION = {"code": 23, "clearable": False, "block_process": True}
ERROR_CRUCIBLE_DISCONNECTED = {"code": 24, "clearable": True, "block_process": True}
ERROR_MICROCHIP_READING ={"code": 25, "clearable": True, "block_process": True}
ERROR_CRUCIBLE_INCOMPATIBLE = {"code": 26, "clearable": True, "block_process": True}
# ^ Warning codes:
WARNING_OPEN_DOORS = {"code": 101, "clearable": True, "block_process": True}
WARNING_RESIDUAL_HEAT_CRUCIBLE = {"code": 102, "clearable": False, "block_process": True}
WARNING_RESIDUAL_HEAT_DIES = {"code": 103, "clearable": False, "block_process": True}

WARNING_TEMPERATURE_HIGH_CRUCIBLE_1 = {"code": 104, "clearable": False, "block_process": True}
WARNING_TEMPERATURE_HIGH_CRUCIBLE_2 = {"code": 105, "clearable": False, "block_process": True}
WARNING_TEMPERATURE_HIGH_DIE_LEFT = {"code": 106, "clearable": False, "block_process": True}
WARNING_TEMPERATURE_HIGH_DIE_RIGHT = {"code": 107, "clearable": False, "block_process": True}
WARNING_TEMPERATURE_HIGH_AMBIENT = {"code": 108, "clearable": False, "block_process": True}
WARNING_HUMIDITY_HIGH_AMBIENT = {"code": 109, "clearable": False, "block_process": True}

WARNING_TEMPERATURE_LOW_CRUCIBLE_1 = {"code": 114, "clearable": False, "block_process": True}
WARNING_TEMPERATURE_LOW_CRUCIBLE_2 = {"code": 115, "clearable": False, "block_process": True}
WARNING_TEMPERATURE_LOW_DIE_LEFT = {"code": 116, "clearable": False, "block_process": True}
WARNING_TEMPERATURE_LOW_DIE_RIGHT = {"code": 117, "clearable": False, "block_process": True}
WARNING_TEMPERATURE_LOW_AMBIENT = {"code": 118, "clearable": False, "block_process": True}
WARNING_HUMIDITY_LOW_AMBIENT = {"code": 119, "clearable": False, "block_process": True}
WARNING_LOADCELLS_READINGS_DIFFERENCE = {"code": 120, "clearable": False, "block_process": True}
WARNING_EMERGENCY_BUTTON = {"code": 121, "clearable": False, "block_process": True}

# % Warning hardware lifespan codes:
WARNING_LIFESPAN_CRUCIBLE = {"code": 250, "clearable": True, "block_process": False}
WARNING_LIFESPAN_SKIMMER = {"code": 251, "clearable": True, "block_process": False}
WARNING_LIFESPAN_NOZZLE = {"code": 252, "clearable": True, "block_process": False}

# > Bluetooth codes:
BLUETOOTH_EOF = {"code": 300, "clearable": False, "block_process": True}
BLUETOOTH_TIMEOUT = {"code": 301, "clearable": False, "block_process": True}
BLUETOOTH_AGENT_NOT_REGISTERED = {"code": 302, "clearable": False, "block_process": True}
BLUETOOTH_AGENT_NOT_UNREGISTERED = {"code": 303, "clearable": False, "block_process": True}
BLUETOOTH_DISCOVERABLE_OFF_FAILED = {"code": 304, "clearable": False, "block_process": True}
BLUETOOTH_UNABLE_TO_START_DISCOVERY = {"code": 305, "clearable": False, "block_process": True}
BLUETOOTH_DISCOVERY_IN_PROGRESS = {"code": 306, "clearable": False, "block_process": True}
BLUETOOTH_UNABLE_TO_STOP_DISCOVERY = {"code": 307, "clearable": False, "block_process": True}
BLUETOOTH_UNABLE_TO_GET_DEVICE_LIST = {"code": 308, "clearable": False, "block_process": True}
BLUETOOTH_PAIRING_ERROR = {"code": 309, "clearable": False, "block_process": True}
BLUETOOTH_UNABLE_TO_UNPAIR = {"code": 310, "clearable": False, "block_process": True}
BLUETOOTH_UNABLE_TO_CANCEL_PAIRING = {"code": 311, "clearable": False, "block_process": True}
BLUETOOTH_CANNOT_POWER_ON = {"code": 312, "clearable": False, "block_process": True}
BLUETOOTH_CONNECTION_LOST = {"code": 313, "clearable": True, "block_process": True}
BLUETOOTH_UNABLE_TO_DISCONNECT = {"code": 314, "clearable": False, "block_process": True}
BLUETOOTH_NOT_IMPLEMENTED_ERROR = {"code": 397, "clearable": False, "block_process": True}
BLUETOOTH_UNKNOWN_ERROR = {"code": 398, "clearable": False, "block_process": True}
BLUETOOTH_OTHER_ERROR = {"code": 399, "clearable": False, "block_process": True}


# * Other codes:
UNKNOWN_FAULT = {"code": 418, "clearable": False, "block_process": True}
UNEXPECTED_FAULT = {"code": 420, "clearable": False, "block_process": True}


# $ MAX31856 fault codes:
MAX31856_FAULT_CJRANGE = {"code": 0x80, "clearable": False, "block_process": True}
MAX31856_FAULT_TCRANGE = {"code": 0x40, "clearable": False, "block_process": True}
MAX31856_FAULT_CJHIGH = {"code": 0x20, "clearable": False, "block_process": True}
MAX31856_FAULT_CJLOW = {"code": 0x10, "clearable": False, "block_process": True}
MAX31856_FAULT_TCHIGH = {"code": 0x08, "clearable": False, "block_process": True}
MAX31856_FAULT_TCLOW = {"code": 0x04, "clearable": False, "block_process": True}
MAX31856_FAULT_OVUV = {"code": 0x02, "clearable": False, "block_process": True}
MAX31856_FAULT_OPEN = {"code": 0x01, "clearable": False, "block_process": True}

# & PiCamera faults:
WARNING_PICAMERA_GENERAL = {"code": 50, "clearable": False, "block_process": True}
WARNING_PICAMERA_DEPRECATED = {"code": 51, "clearable": False, "block_process": True}
WARNING_PICAMERA_FALLBACK = {"code": 52, "clearable": False, "block_process": True}
WARNING_PICAMERA_RESIZER_ENCODING = {"code": 53, "clearable": False, "block_process": True}
WARNING_PICAMERA_ALPHA_STRIPPING = {"code": 54, "clearable": False, "block_process": True}

ERROR_PICAMERA_GENERAL = {"code": 150, "clearable": False, "block_process": True}
ERROR_PICAMERA_VALUE_ERROR = {"code": 151, "clearable": False, "block_process": True}
ERROR_PICAMERA_RUNTIME_ERROR = {"code": 152, "clearable": False, "block_process": True}
ERROR_PICAMERA_CLOSED = {"code": 153, "clearable": False, "block_process": True}
ERROR_PICAMERA_NOT_RECORDING = {"code": 154, "clearable": False, "block_process": True}
ERROR_PICAMERA_ALREADY_RECORDING = {"code": 155, "clearable": False, "block_process": True}
ERROR_PICAMERA_MMAL = {"code": 156, "clearable": False, "block_process": True}
