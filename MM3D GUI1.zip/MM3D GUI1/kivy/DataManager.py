import json
from collections import defaultdict
from kivy.logger import Logger
from kivy.event import EventDispatcher
from kivy.properties import (
    ListProperty, 
    NumericProperty,
    StringProperty
    )
from Constants import (
    TYPE_ID_CRUCIBLE,
    TYPE_ID_NOZZLE,
    TYPE_ID_DIES,
    TYPE_ID_MATERIAL_CASTING,
    TYPE_ID_MATERIAL_MOLD,
    TYPE_ID_MATERIAL_SAND,
    TYPE_ID_SKIMMERS,
    CONSUMABES_FILE,
    CONSUMABLES_HARDWARE_FILE,
    SKIMMER_NEW,
    NOZZLE_NEW,
    CRUCIBLE_NEW,
    MIN_LIFESPAN_SKIMMER,
    MIN_LIFESPAN_CRUCIBLE,
    MIN_LIFESPAN_NOZZLE
)
from Images import (
    ICON_STATUS_UP_TO_DATE
)
from Faults import (
    WARNING_LIFESPAN_CRUCIBLE,
    WARNING_LIFESPAN_SKIMMER,
    WARNING_LIFESPAN_NOZZLE
)

from Strings import OTHER_STRINGS

class DataManager(EventDispatcher):
    DATA_HARDWARE_CRUCIBLES = ListProperty()
    DATA_HARDWARE_NOZZLES = ListProperty()
    DATA_HARDWARE_DIES = ListProperty()
    DATA_HARDWARE_SKIMMERS = ListProperty()

    DATA_HARDWARE_CRUCIBLE_SELECTED = ListProperty(["", "", "", "", ""])
    DATA_HARDWARE_NOZZLE_SELECTED = ListProperty(["", "", "", "", ""])
    DATA_HARDWARE_DIES_SELECTED = ListProperty(["", "", "", "", "", ""])
    DATA_HARDWARE_SKIMMER_SELECTEF = ListProperty(["", "", "", "", ""])

    DATA_MATERIAL_CASTING = ListProperty()
    DATA_MATERIAL_MOLD = ListProperty()
    DATA_MATERIAL_SAND = ListProperty()
    DATA_MATERIAL_CASTING_SELECTED = ListProperty(["", "", "", "", "", "", ""])
    DATA_MATERIAL_MOLD_SELECTED = ListProperty(["", "", "", "", ""])
    DATA_MATERIAL_SAND_SELECTED = ListProperty(["", "", "", "", ""])
    DATA_MATERIAL_CASTING_MERGED = ListProperty()
    DATA_MATERIAL_MOLD_MERGED = ListProperty()
    DATA_MATERIAL_SAND_MERGED = ListProperty()

    SKIMMER_LIFESPAN = NumericProperty(0)
    NOZZLE_LIFESPAN = NumericProperty(0)
    CRUCIBLE_ASSIGNED_MATERIAL = StringProperty("")

    def __init__(self, manager, **kwargs):
        super(DataManager, self).__init__(**kwargs)
        self.manager = manager
        self._crucible_volume = 0
        self._crucible_assigned_material = ""
        self._crucible_lifespan = 0
        # self._get_crucible_data()        

        # self.monitor_hardware_lifespan(TYPE_ID_CRUCIBLE, MIN_LIFESPAN_CRUCIBLE)
        #self.check_up_consumable_hardware(TYPE_ID_NOZZLE, MIN_LIFESPAN_NOZZLE)
        # self.check_up_hardware(TYPE_ID_SKIMMERS, MIN_LIFESPAN_SKIMMER)
        # self.update_hardware_data(TYPE_ID_SKIMMERS, 20)
        #self.load_hardware_data()
        #self.update_new_hardware("skimmer")
    def printable(self):
        print("somethinf here")

    def load_hardware_data(self):
        """Loads hardware data from the consumable hardware file at startup.
        """
        loaded = []
        loaded.append(CRUCIBLE_NEW)
        loaded.append(SKIMMER_NEW)
        loaded.append(NOZZLE_NEW)
        try:
            with open(CONSUMABLES_HARDWARE_FILE, "w+") as file:
                json.dump(loaded, file, indent=4)
        except Exception as exception:
            Logger.exception("DataManager: " + str(exception))


    def monitor_hardware_lifespan(self, consumable_hardware_type, min_lifespan):
        
        def _raise_warning():
            if consumable_hardware_type == TYPE_ID_CRUCIBLE:
                self.manager.fm.fault_states[
                    self.manager.fm.fault_codes.index(WARNING_LIFESPAN_CRUCIBLE["code"])
                                ] = True
            elif consumable_hardware_type == TYPE_ID_SKIMMERS:
                self.manager.fm.fault_states[
                    self.manager.fm.fault_codes.index(WARNING_LIFESPAN_SKIMMER["code"])
                                ] = True
            elif consumable_hardware_type == TYPE_ID_NOZZLE:
                self.manager.fm.fault_states[
                    self.manager.fm.fault_codes.index(WARNING_LIFESPAN_NOZZLE["code"])
                                ] = True
        try:
            with open(CONSUMABLES_HARDWARE_FILE, "r+") as file:
                loaded = json.loads(file.read())
            for index in range(0,len(loaded)):
                if loaded[index]["TYPE"]== consumable_hardware_type:
                    if consumable_hardware_type == TYPE_ID_SKIMMERS:
                        if loaded[index]["LIFESPAN_LEFT"] <= min_lifespan:
                            _raise_warning()
                    elif consumable_hardware_type == TYPE_ID_CRUCIBLE:
                        if loaded[index]["LIFESPAN_LEFT"] <= min_lifespan:
                            _raise_warning()
                    elif consumable_hardware_type == TYPE_ID_NOZZLE:
                        if loaded[index]["LIFESPAN_LEFT"] <= min_lifespan:
                            _raise_warning()

        except Exception as exception:
            Logger.exception("DataManager: " + str(exception))
            #TODO: NO FILE CREATED EXCEPTION

    def check_up_hardware(self, consumable_hardware_type):
        try:
            with open(CONSUMABLES_HARDWARE_FILE, "r+") as file:
                loaded = json.loads(file.read())
            for index in range(0,len(loaded)):
                if loaded[index]["TYPE"] == consumable_hardware_type:
                    if consumable_hardware_type == TYPE_ID_SKIMMERS:
                        if loaded[index]["LIFESPAN_LEFT"] <= MIN_LIFESPAN_SKIMMER:
                            Logger.info("DataManager: Check Up denied.")
                            return False
                    elif consumable_hardware_type == TYPE_ID_CRUCIBLE:
                        if loaded[index]["LIFESPAN_LEFT"] <= MIN_LIFESPAN_CRUCIBLE:
                            Logger.info("DataManager: Check Up denied.")
                            return False
                    elif consumable_hardware_type == TYPE_ID_NOZZLE:
                        if loaded[index]["LIFESPAN_LEFT"] <= MIN_LIFESPAN_NOZZLE:
                            Logger.info("DataManager: Check Up denied.")
                            return False

        except Exception as exception:
            Logger.exception("DataManager: " + str(exception))
            #TODO: NO FILE CREATED EXCEPTION
        else:
            Logger.info("DataManager: Check Up aproved." )
            return True

    def update_new_hardware(self, consumable_hardware_type):
        """Updates the data when adding a new hardware.
        """
        try:
            with open(CONSUMABLES_HARDWARE_FILE, "r+") as file:
                loaded = json.loads(file.read())
            for index in range(0,len(loaded)):

                if loaded[index]["TYPE"]== consumable_hardware_type:
                    if consumable_hardware_type == TYPE_ID_SKIMMERS:
                        loaded[index] = SKIMMER_NEW
                    elif consumable_hardware_type == TYPE_ID_CRUCIBLE:
                        loaded[index] = CRUCIBLE_NEW
                    elif consumable_hardware_type == TYPE_ID_NOZZLE:
                        loaded[index] = NOZZLE_NEW
        except Exception as exception:
            Logger.exception("DataManager: " + str(exception))
            #TODO: NO FILE CREATED EXCEPTION
        try:
            with open(CONSUMABLES_HARDWARE_FILE, "w+") as file:
                json.dump(loaded, file, indent=4)
        except Exception as exception:
            Logger.exception("DataManager: " + str(exception))




    def update_hardware_lifespan(self, consumable_hardware_type, time):
        try:
            with open(CONSUMABLES_HARDWARE_FILE, "r+") as file:
                loaded = json.loads(file.read())
            for index in range(0, len(loaded)):
                if loaded[index]["TYPE"] == consumable_hardware_type:
                    loaded[index]["LIFESPAN_LEFT"] = loaded[index]["LIFESPAN_LEFT"] - time
        except Exception as exception:
            Logger.exception("DataManager: " + str(exception))
        try:
            with open(CONSUMABLES_HARDWARE_FILE, "w+") as file:
                json.dump(loaded, file, indent=4)
        except Exception as exception:
            Logger.exception("DataManager: " + str(exception))



    


    def clear_properties(self):
        """Clears the ListProperties that hold the consumables' data.
        """
        self.DATA_HARDWARE_CRUCIBLES = []
        self.DATA_HARDWARE_NOZZLES = []
        self.DATA_HARDWARE_DIES = []
        self.DATA_HARDWARE_SKIMMERS = []
        
        self.DATA_MATERIAL_CASTING = []
        self.DATA_MATERIAL_MOLD = []
        self.DATA_MATERIAL_SAND = []

    def update_data(self):
        """Reads the consumables' data from file and calls the parser
        to populate the properties.
        """
        try:
            with open(CONSUMABES_FILE, "r+") as file:
                loaded = json.loads(file.read())
        except Exception as exception:
            Logger.exception("DataManager: " + str(exception))
        else:
            self.clear_properties()
            self.parse_loaded_data(loaded, saved=True)

    def parse_loaded_data(self, loaded, saved=False):
  
        # TODO: empty file exception
        """Parses the loaded data (either from database or from file)

        Args:
            loaded (JSON): Consumables' data in JSON format
        """
        DATA_HARDWARE_CRUCIBLES = []
        DATA_HARDWARE_NOZZLES = []
        DATA_HARDWARE_DIES = []
        DATA_HARDWARE_SKIMMERS = []
        DATA_MATERIAL_CASTING = []
        DATA_MATERIAL_MOLD = []
        DATA_MATERIAL_SAND = []

        if loaded != []:
            try:
                for element in loaded:  # <- access the object with consumable data (to test)
                    if element["TYPE"] == TYPE_ID_CRUCIBLE:
                        DATA_HARDWARE_CRUCIBLES.append(
                            (
                                element["NAME"],
                                "None"
                                if element["ASSIGNED_MATERIAL"] is None
                                else element["ASSIGNED_MATERIAL"],
                                str(element["LIFESPAN_LEFT"]),
                                str(element["LIFESPAN"]),
                                element["ID_SERIAL"],
                            )
                        )
                        self.DATA_HARDWARE_CRUCIBLES = DATA_HARDWARE_CRUCIBLES
                        self.DATA_HARDWARE_CRUCIBLE_SELECTED = DATA_HARDWARE_CRUCIBLES[0]

                    elif element["TYPE"] == TYPE_ID_NOZZLE:
                        DATA_HARDWARE_NOZZLES.append(
                            (
                                element["NAME"],
                                str(element["LIFESPAN_LEFT"]),
                                str(element["LIFESPAN"]),
                                element["ID_SERIAL"],
                            )
                        )
                        self.DATA_HARDWARE_NOZZLES = DATA_HARDWARE_NOZZLES
                        self.DATA_HARDWARE_NOZZLE_SELECTED = DATA_HARDWARE_NOZZLES[0]

                    elif element["TYPE"] == TYPE_ID_DIES:
                        DATA_HARDWARE_DIES.append(
                            (
                                element["NAME"],
                                "None"
                                if element["ASSIGNED_MODEL"] is None
                                else element["ASSIGNED_MODEL"],
                                str(element["LIFESPAN_LEFT"]),
                                str(element["LIFESPAN"]),
                                element["ID_SERIAL"],
                            )
                        )
                        self.DATA_HARDWARE_DIES = DATA_HARDWARE_DIES
                        self.DATA_HARDWARE_DIES_SELECTED = DATA_HARDWARE_DIES[0]
                    elif element["TYPE"] == TYPE_ID_MATERIAL_CASTING:
                        DATA_MATERIAL_CASTING.append(
                            (
                                element["NAME"],
                                str(element["DENSITY"]),
                                str(element["LIFESPAN_LEFT"]),
                                str(element["LIFESPAN"]),
                                str(element["TEMP_CRUCIBLE"]),
                                str(element["TEMP_DIES"]),
                                element["ID_SERIAL"],
                            )
                        )
                        self.DATA_MATERIAL_CASTING = DATA_MATERIAL_CASTING
                        self.DATA_MATERIAL_CASTING_SELECTED = DATA_MATERIAL_CASTING[0]

                    elif element["TYPE"] == TYPE_ID_MATERIAL_MOLD:
                        DATA_MATERIAL_MOLD.append(
                            (
                                element["NAME"],
                                str(element["DENSITY"]),
                                str(element["LIFESPAN_LEFT"]),
                                str(element["LIFESPAN"]),
                                element["ID_SERIAL"],
                            )
                        )
                        self.DATA_MATERIAL_MOLD = DATA_MATERIAL_MOLD
                        self.DATA_MATERIAL_MOLD_SELECTED = DATA_MATERIAL_MOLD[0]

                    elif element["TYPE"] == TYPE_ID_MATERIAL_SAND:
                        DATA_MATERIAL_SAND.append(
                            (
                                element["NAME"],
                                str(element["DENSITY"]),
                                str(element["LIFESPAN_LEFT"]),
                                str(element["LIFESPAN"]),
                                element["ID_SERIAL"],
                            )
                        )
                        self.DATA_MATERIAL_SAND = DATA_MATERIAL_SAND
                        self.DATA_MATERIAL_SAND_SELECTED = DATA_MATERIAL_SAND[0]

                    elif element["TYPE"] == TYPE_ID_SKIMMERS:
                        DATA_HARDWARE_SKIMMERS.append(
                            (
                                element["NAME"],
                                str(element["LIFESPAN_LEFT"]),
                                str(element["LIFESPAN"]),
                                element["ID_SERIAL"],
                            )
                        )
                        self.DATA_HARDWARE_SKIMMERS = DATA_HARDWARE_SKIMMERS
                        self.DATA_HARDWARE_SKIMMER_SELECTED = DATA_HARDWARE_SKIMMERS[0]

            except Exception as exception:
                Logger.exception("DataManager: " + str(exception))

            if not saved:
                try:
                    with open(CONSUMABES_FILE, "w+") as file:
                        json.dump(loaded, file, indent=4)
                except Exception as exception:
                    Logger.exception("DataManager: " + str(exception))
            # self.merge_materials()
        else:
            print("Empty loaded file")
        if  self.manager.get_screen("main").current_screen == "crucibles":
            self.manager.get_screen("main").continue_reading_thread(TYPE_ID_CRUCIBLE)
        elif self.manager.get_screen("main").current_screen == "nozzles":
            self.manager.get_screen("main").continue_reading_thread(TYPE_ID_NOZZLE)
        elif self.manager.get_screen("main").current_screen == "skimmers":
            self.manager.get_screen("main").continue_reading_thread(TYPE_ID_SKIMMERS)
        elif self.manager.get_screen("main").current_screen == "materials":
            self.manager.get_screen("main").continue_reading_thread(TYPE_ID_MATERIAL_CASTING)
        else: pass

    def merge_materials(self):
        """Merges multiple materials of the same kind into one item
        on the list of available materials for casting and etc.
        """
        def list_duplicates(seq):
            """Returns a list of duplicate items (names and indexes of repetitions)
            Args:
                seq (list): List of materials

            Returns:
                list: Duplicates and their positions
            """
            names_list = list([col[0] for col in seq])
            names = defaultdict(list)
            for index, item in enumerate(names_list):
                names[item].append(index)
            return ((key, locs) for key, locs in names.items() if len(locs) > 1)
        if len(self.DATA_MATERIAL_CASTING) > 1:
            self.DATA_MATERIAL_CASTING_MERGED = []
            print("merging casting mats")
            duplicates = list(list_duplicates(self.DATA_MATERIAL_CASTING))
            duplicate_indexes = []
            print(duplicates)
            for material in duplicates:
                # Get duplicated indexes so they can be omitted when adding
                # the rest of the materials on the merged list
                for index in material[1]:
                    duplicate_indexes.append(index)
                first = material[1][0]  # index of first appearace of material with duplicates
                self.DATA_MATERIAL_CASTING_MERGED.append(
                    [
                        self.DATA_MATERIAL_CASTING[first][0],  # name
                        float(self.DATA_MATERIAL_CASTING[first][1]),  # density
                        sum(int(self.DATA_MATERIAL_CASTING[index][2]) for index in material[1]),  # amount
                        int(self.DATA_MATERIAL_CASTING[first][3]),  # default amount
                        int(self.DATA_MATERIAL_CASTING[first][4]),  # temp. crucible
                        int(self.DATA_MATERIAL_CASTING[first][5]),  # temp. dies
                        self.DATA_MATERIAL_CASTING[first][6],  # uid
                    ]
                )
            # Append the rest of the materials to the merged list
            for index, material in enumerate(self.DATA_MATERIAL_CASTING):
                if index in duplicate_indexes:
                    pass
                else:
                    self.DATA_MATERIAL_CASTING_MERGED.append(
                        [
                            self.DATA_MATERIAL_CASTING[index][0],  # name
                            float(self.DATA_MATERIAL_CASTING[index][1]),  # density
                            float(self.DATA_MATERIAL_CASTING[index][2]),  # amount
                            int(self.DATA_MATERIAL_CASTING[index][3]),  # default amount
                            int(self.DATA_MATERIAL_CASTING[index][4]),  # temp. crucible
                            int(self.DATA_MATERIAL_CASTING[index][5]),  # temp. dies
                            self.DATA_MATERIAL_CASTING[index][6],  # uid
                        ]
                    )
            print(self.DATA_MATERIAL_CASTING_MERGED)
        if len(self.DATA_MATERIAL_MOLD) > 1:
            self.DATA_MATERIAL_MOLD_MERGED = []
            print("merging mold mats")
            duplicates = list(list_duplicates(self.DATA_MATERIAL_MOLD))
            duplicate_indexes = []
            for material in duplicates:
                # Get duplicated indexes so they can be omitted when adding
                # the rest of the materials on the merged list
                for index in material[1]:
                    duplicate_indexes.append(index)

                first = material[1][0]  # first appearace index of material with duplicates
                self.DATA_MATERIAL_MOLD_MERGED.append(
                    [
                        self.DATA_MATERIAL_MOLD[first][0],  # name
                        float(self.DATA_MATERIAL_MOLD[first][1]),  # density
                        sum(int(self.DATA_MATERIAL_MOLD[index][2]) for index in material[1]),  # amount
                        int(self.DATA_MATERIAL_MOLD[first][3]),  # default amount
                        self.DATA_MATERIAL_MOLD[first][4],  # uid
                    ]
                )
            # Append the rest of the materials to the merged list
            for index, material in enumerate(self.DATA_MATERIAL_MOLD):
                if index in duplicate_indexes:
                    pass
                else:
                    self.DATA_MATERIAL_MOLD_MERGED.append(
                        [
                            self.DATA_MATERIAL_MOLD[index][0],  # name
                            float(self.DATA_MATERIAL_MOLD[index][1]),  # density
                            int(self.DATA_MATERIAL_MOLD[index][2]),  # amount
                            int(self.DATA_MATERIAL_MOLD[index][3]),  # default amount
                            self.DATA_MATERIAL_MOLD[index][4],  # uid
                        ]
                    )
            # print(self.DATA_MATERIAL_MOLD_MERGED)
        if len(self.DATA_MATERIAL_SAND) > 1:
            self.DATA_MATERIAL_SAND_MERGED = []
            print("merging sand mats")
            duplicates = list(list_duplicates(self.DATA_MATERIAL_SAND))
            duplicate_indexes = []
            for material in duplicates:
                # Get duplicated indexes so they can be omitted when adding
                # the rest of the materials on the merged list
                for index in material[1]:
                    duplicate_indexes.append(index)
                first = material[1][0]  # first appearace index of material with duplicates
                self.DATA_MATERIAL_SAND_MERGED.append(
                    [
                        self.DATA_MATERIAL_SAND[first][0],  # name
                        float(self.DATA_MATERIAL_SAND[first][1]),  # density
                        sum(int(self.DATA_MATERIAL_SAND[index][2]) for index in material[1]),  # amount
                        int(self.DATA_MATERIAL_SAND[first][3]),  # default amount
                        self.DATA_MATERIAL_SAND[first][4],  # uid
                    ]
                )
            # Append the rest of the materials to the merged list
            for index, material in enumerate(self.DATA_MATERIAL_SAND):
                if index in duplicate_indexes:
                    pass
                else:
                    self.DATA_MATERIAL_SAND_MERGED.append(
                        [
                            self.DATA_MATERIAL_SAND[index][0],  # name
                            float(self.DATA_MATERIAL_SAND[index][1]),  # density
                            int(self.DATA_MATERIAL_SAND[index][2]),  # amount
                            int(self.DATA_MATERIAL_SAND[index][3]),  # default amount
                            self.DATA_MATERIAL_SAND[index][4],  # uid
                        ]
                    )
        if  self.manager.get_screen("main").current_screen == "crucibles":
            self.manager.get_screen("main").continue_reading_thread(TYPE_ID_CRUCIBLE)
        elif self.manager.get_screen("main").current_screen == "nozzles":
            self.manager.get_screen("main").continue_reading_thread(TYPE_ID_NOZZLE)
        elif self.manager.get_screen("main").current_screen == "skimmers":
            self.manager.get_screen("main").continue_reading_thread(TYPE_ID_SKIMMERS)
        elif self.manager.get_screen("main").current_screen == "materials":
            self.manager.get_screen("main").continue_reading_thread(TYPE_ID_MATERIAL_CASTING)
        else: pass
            # print(self.DATA_MATERIAL_SAND_MERGED)


    def get_piid(self):
        """Reads the Pi's CPU ID number which (most probably)
        is unique and thus usable as a mean of identification.
        Returns:
            string: RPi UID
        """
        piid = "0000000000000000"
        try:
            file = open("/proc/cpuinfo", "r")
            for line in file:
                if line[0:6] == "Serial":
                    piid = line[10:26]
            file.close()

        except Exception as exception:  # OSError:
            Logger.exception("EDM.read_data(): " + str(exception))
            return ""
        else:
            return piid


    # def _get_crucible_data(self):
    #     with open(CONSUMABLES_HARDWARE_FILE, "r+") as file:
    #         loaded = json.loads(file.read())
    #         for index in range(0, len(loaded)):
    #             if loaded[index]["TYPE"] == TYPE_ID_CRUCIBLE:
    #                 self._crucible_assigned_material = loaded[index]["ASSIGNED_MATERIAL"]
    #                 self._crucible_volume = loaded[index]["VOLUME"]
    #                 self._crucible_lifespan = loaded[index]["LIFESPAN_LEFT"]

    def get_crucible_assigned_material(self):
        return self._crucible_assigned_material

    def get_crucible_volume(self):
        return self._crucible_volume

    def get_crucible_lifespan(self):
        return self._crucible_lifespan




    def update_crucible_local_data(self, volume, material, lifespan):
        try:
            with open(CONSUMABLES_HARDWARE_FILE, "r+") as file:
                loaded = json.loads(file.read())
                for index in range(0, len(loaded)):
                    if loaded[index]["TYPE"] == TYPE_ID_CRUCIBLE:
                        loaded[index]["VOLUME"] = volume
                        loaded[index]["LIFESPAN_LEFT"] = lifespan
                        loaded[index]["ASSIGNED_MATERIAL"] = material

                        self._crucible_volume = volume
                        self._crucible_assigned_material = material
                        self._crucible_lifespan = lifespan
            try:
                with open(CONSUMABLES_HARDWARE_FILE, "w+") as file:
                        json.dump(loaded, file, indent=4)
                        Logger.info("DataManager: Crucible volume data has been updated" )
            except Exception as exception:
                Logger.exception("DataManager: " + str(exception))
        except Exception as exception:
            Logger.exception("DataManager: " + str(exception))




    # def update_crucible_volume(self, volume_used, add=True):
    #     try:
    #         with open(CONSUMABLES_HARDWARE_FILE, "r+") as file:
    #             loaded = json.loads(file.read())
    #             for index in range(0, len(loaded)):
    #                 if add:
    #                     if loaded[index]["TYPE"] == TYPE_ID_CRUCIBLE:
    #                         loaded[index]["VOLUME"] -= volume_used
    #                         self._crucible_volume -= volume_used
    #                 else:
    #                     if loaded[index]["TYPE"] == TYPE_ID_CRUCIBLE:
    #                         loaded[index]["VOLUME"] -= volume_used
    #                         self._crucible_volume -= volume_used
    #         #Todo: handle exceptions
    #         try:
    #             with open(CONSUMABLES_HARDWARE_FILE, "w+") as file:
    #                 json.dump(loaded, file, indent=4)
    #         except Exception as exception:
    #             Logger.exception("DataManager: " + str(exception))

    #     except Exception as exception:
    #         Logger.exception("DataManager: " + str(exception))
    #     else:
    #         self.manager.ccm.load_material()