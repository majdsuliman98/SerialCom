from Images import (
    ICON_BOTTOM_PANEL_AL, 
    ICON_BOTTOM_PANEL_CRUCIBLE, 
    ICON_BOTTOM_PANEL_CRUCIBLE_DISCONNECTED, 
    ICON_BOTTOM_PANEL_CRUCIBLE_T,
    ICON_BOTTOM_PANEL_NO_TEMP, 
    ICON_BOTTOM_PANEL_NULL, 
    ICON_BOTTOM_PANEL_ZA,
    ICON_THERMO,
    ICON_THERMO_CONTROL
    )
from kivy.clock import Clock

def icon_material_manager(self, icon_material):

    def _icon_material_manager(*args):
        if self.manager.ccm.MATERIAL == 'al':
            icon_material.source = ICON_BOTTOM_PANEL_AL
        elif self.manager.ccm.MATERIAL == 'za':
            icon_material.source = ICON_BOTTOM_PANEL_ZA
        else:
            icon_material.source = ICON_BOTTOM_PANEL_NULL

    Clock.schedule_once(_icon_material_manager)


def icon_crucible_manager(self, icon_crucible):

    def _icon_crucible_manager(*args):
        if self.manager.ccm.CRUCIBLE_MICROCHIP_EN is not True:
            icon_crucible.source = ICON_BOTTOM_PANEL_CRUCIBLE_DISCONNECTED
        else:
            if self.manager.ccm.CRUCIBLE_TILTED is not True:
                icon_crucible.source = ICON_BOTTOM_PANEL_CRUCIBLE
            else:
                icon_crucible.source = ICON_BOTTOM_PANEL_CRUCIBLE_T

    Clock.schedule_once(_icon_crucible_manager)


def icon_temperature_manager(self, icon_termperature):

    def _icon_temperature_manager(*args):
        if self.manager.ccm.CRUCIBLE_MICROCHIP_EN is not True:
                icon_termperature.source = ICON_BOTTOM_PANEL_NO_TEMP
        else:
            if self.manager.ccm.TEMP_CONTROL is not True:
                icon_termperature.source = ICON_THERMO
            else:
                icon_termperature.source = ICON_THERMO_CONTROL

    Clock.schedule_once(_icon_temperature_manager)
