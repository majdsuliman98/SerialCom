from kivy.lang import Builder
from kivy.uix.screenmanager import Screen
import time 
from kivy.clock import Clock

from kivy.logger import Logger
Builder.load_file('debug/DebugScreen2.kv')



class DebugScreen2(Screen):
    """This class was used to implement a screen where all of the sensors'
    readings and stuff could be monitored. It has not been deleted just in case
    it somehow becomes useful one day.
    """

        
    def manual_ssr_control(self, channel):
        self.manager.ccm.arduino_control.write(bytes("S" + str(channel), "UTF-8"))

    def proportional_valve_control(self, value=0):
        # Logger.info((value)
        self.manager.ccm.arduino_control.write(bytes("p;" + str(int(value)), "UTF-8"))

    # def proportional_valve_on_off(self):
    #     self.manager.ccm.arduino_control.write(bytes("P", "UTF-8"))

    def back_main_screen(self, *args):
        self.manager.get_screen("main").current_screen = "home"
        self.manager.current = "main"

    def resumeStepper(self):
        print('Resume Stepper')
        codigo='$!\n'
        self.manager.ccm.nucleo_gcode.flushInput() 
        self.manager.ccm.nucleo_gcode.flushOutput()
        self.manager.ccm.nucleo_gcode.write(codigo.encode())


    def writeStepperData(self, stepper,pos,speed):
        if stepper == "CR_1":
            stepperID = 'X'
        if stepper == "CR_2":
            stepperID = 'Y'
        if stepper == "Z_1":
            stepperID = 'Z'
        if stepper == "Z_2":
            stepperID = 'A'
        if stepper == "TURRET":
            stepperID = 'B'
        if stepper == "SKIMMER":
            stepperID = 'C'
        codigo = '$J=G21G91 '+stepperID+str(pos)+' F'+str(speed)+'\r\n'
        #codigo = '$J=G21G91 '+'b100 c100'+'F'+str(speed)+'\n'
        try:
            
            # self.manager.hcm.semaphore.acquire()
            self.manager.ccm.nucleo_gcode.flushInput() 
            self.manager.ccm.nucleo_gcode.flushOutput()
            # self.manager.ccm.nucleo_gcode.write(codigo.encode())
            # time.sleep(1)
            try:
                # self.manager.ccm.nucleo_gcode.flush()
                grbl_out = self.manager.ccm.nucleo_gcode.readline().decode()
                print(grbl_out)
                # self.manager.hcm.semaphore.release()
                
            except Exception as ex:
                print(ex)
        except Exception as ex:
            # hello = self.manager.ccm.nucleo_gcode.readline()
            # priny(hello)
            print(ex)


    def UnblockStepper(self):
        codigo='$X\n'
        print(codigo)
        try:
            self.manager.ccm.nucleo_gcode.flushInput() 
            self.manager.ccm.nucleo_gcode.flushOutput()
            self.manager.ccm.nucleo_gcode.write(codigo.encode())
        except:
            print("Comunication with ESP32 failed")

    def stopStepper(self):
        codigo='$!\n'
        print(codigo)
        try:
            self.manager.ccm.nucleo_gcode.flushInput() 
            self.manager.ccm.nucleo_gcode.flushOutput()
            self.manager.ccm.nucleo_gcode.write(codigo.encode())
        except:
            print("Comunication with ESP32 failed")



    def open_dc_motor_2(self):
    #Turn on the motor and set timer or turn off in case the endstop is trigged

        def _open_dc_motor():
            self.manager.ccm.toggle_dc(self, dev="DC_2_R", state = True)

        def _stop_motor(*args):
            self.manager.ccm.toggle_dc(self, dev="DC_2_R", state = False)

        _open_dc_motor()
        Clock.schedule_once(_stop_motor,1)
        
    def close_dc_motor_2(self):
    #Turn on the motor and set timer or turn off in case the endstop is trigged

        def _close_dc_motor():
            self.manager.ccm.toggle_dc(self, dev="DC_2_L", state = True)

        def _stop_motor(*args):
            self.manager.ccm.toggle_dc(self, dev="DC_2_L", state = False)

        _close_dc_motor()
        Clock.schedule_once(_stop_motor,1)


    # def move(self,stepper,pos,speed):
    #     codigo = '$J=G21G91'+stepper+pos+'F'+speed+'\r\n'
    #     self.manager.ccm.nucleo_gcode.flushInput() 
    #     self.manager.ccm.nucleo_gcode.flushOutput()
    #     self.manager.ccm.nucleo_gcode.write(codigo.encode())


    def cover(self):
        self.manager.hcm.routines(name="cover")
    def uncover(self):
        self.manager.hcm.routines(name="uncover")
    def degassing(self):
        self.manager.hcm.routines(name="degassing")
    def material(self):
        self.manager.hcm.routines(name="add_material")

    def home_crucible(self):
        self.manager.hcm.routines(name="home_crucible")


    def tilt_crucible(self):
        u = 2
        if self.manager.hcm.SET_ZERO_MACHINE and round(self.manager.hcm.z_current_pos_2) == 0 and round(self.manager.hcm.turret_current_pos) == 0:
            if round((self.manager.hcm.crucible_current_pos_2 + u)) <= 93:
                self.manager.hcm.crucible_down_f(dist=u)
            else:
                Logger.info("Debug: Crucible max dist")
        else:
            Logger.error("Debug: Imposible to tilt in this condition.")

    def untilt_crucible(self):
        u = 2
        if self.manager.hcm.SET_ZERO_MACHINE and round(self.manager.hcm.z_current_pos_2) == 0 and round(self.manager.hcm.turret_current_pos) == 0:
            if round((self.manager.hcm.crucible_current_pos_2 - u)) >= 0:
                self.manager.hcm.crucible_up_f(dist=u)
            else:
                Logger.info("Debug: Crucible min dist")
        else:
            Logger.error("Debug: Imposible to tilt in this condition.")
