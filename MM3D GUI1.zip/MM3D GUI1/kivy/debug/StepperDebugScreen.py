import serial
import threading
from MCP23017 import *
from MAX31856 import *
from kivy.clock import Clock
from kivy.uix.screenmanager import Screen
from kivy.properties import ListProperty, NumericProperty

from kivy.lang import Builder
Builder.load_file('debug/StepperDebugScreen.kv')


class StepperDebugScreen(Screen):
    # FLAG = ListProperty([0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    ACCELERATION_DEFAULT = NumericProperty(1000)
    POSITION_DEFAULT = NumericProperty(0)
    SPEED_DEFAULT = NumericProperty(1000)


#>>HERE WILL BE THE NEW COMMUNICATION WITH ARDUINO STEPPERS IN GCODE

        # print(answer.decode())

    def writeStepperData(self, stepper,speed,data, command):
        if stepper == "NEMA23_0":
            stepperID = 'X'
        if stepper == "NEMA23_1":
            stepperID = 'Y'
        if stepper == "NEMA23_2":
            stepperID = 'Z'
        if stepper == "NEMA17":
            stepperID = 3
        if stepper == "NEMA17_double":
            stepperID = 4



        codigo = '$J=G21G91 '+stepperID+str(data)+' F'+str(speed)+'\n'
        self.manager.ccm.nucleo_gcode.flushInput() 

        self.manager.ccm.nucleo_gcode.flushOutput()
        self.manager.ccm.nucleo_gcode.write(codigo.encode())

        # print(codigo)

    def stopStepper(self):
        codigo='$!\n'
        print(codigo)
        self.manager.ccm.nucleo_gcode.flushInput() 
        self.manager.ccm.nucleo_gcode.flushOutput()
        self.manager.ccm.nucleo_gcode.write(codigo.encode())


        #>THIS IS THE OLD CODE OF COMMUNICATION WITH STEPPER ARDUINO 
    # def writeStepperData(self, stepper, data, command):
    #     if stepper == "NEMA23_0":
    #         stepperID = 0
    #     if stepper == "NEMA23_1":
    #         stepperID = 1
    #     if stepper == "NEMA23_2":
    #         stepperID = 2
    #     if stepper == "NEMA17":
    #         stepperID = 3
    #     if stepper == "NEMA17_double":
    #         stepperID = 4

    #     command = str(stepperID) + ';' + str(data) + ';' + str(command)
    #     print(command)
    #     #self.arduino.write(bytes(command, 'UTF-8'))
    #     self.manager.ccm.arduino_steppers.write(bytes(command, 'UTF-8'))
        
    #             # self.arduino.flushOutput()