# from picamera import PiCamera
from kivy.uix.screenmanager import Screen

from kivy.lang import Builder
Builder.load_file('debug/CameraDebugScreen.kv')

class CameraDebugScreen(Screen):
    def __init__(self, **kwargs):
        super(CameraDebugScreen, self).__init__(**kwargs)

    def on_pre_enter(self):
        self.camera.framerate = 5 # no effect
        self.camera.play = True

    def on_pre_leave(self):
        self.camera.play = False
        self.camera.stop()
