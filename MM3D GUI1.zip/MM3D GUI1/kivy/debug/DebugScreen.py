from kivy.lang import Builder
from kivy.uix.screenmanager import Screen

Builder.load_file('debug/DebugScreen.kv')


class DebugScreen(Screen):
    """This class was used to implement a screen where all of the sensors'
    readings and stuff could be monitored. It has not been deleted just in case
    it somehow becomes useful one day.
    """
    def __init__(self, manager, **kwargs):
        super(DebugScreen, self).__init__(**kwargs)

    def manual_ssr_control(self, channel):
        self.manager.ccm.arduino_control.write(bytes("S" + str(channel), "UTF-8"))

    def proportional_valve_control(self, value=0):
        # print(value)
        self.manager.ccm.arduino_control.write(bytes("p;" + str(int(value)), "UTF-8"))

    def proportional_valve_on_off(self):
        self.manager.ccm.arduino_control.write(bytes("P", "UTF-8"))

    def resumeStepper(self):
        print('Resume Stepper')
        codigo='$X\n'
        self.manager.ccm.nucleo_gcode.flushInput() 
        self.manager.ccm.nucleo_gcode.flushOutput()
        self.manager.ccm.nucleo_gcode.write(codigo.encode())
