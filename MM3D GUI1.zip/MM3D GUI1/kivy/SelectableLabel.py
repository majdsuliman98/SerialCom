from kivy.app import App
from kivy.uix.behaviors.touchripple import TouchRippleBehavior
from kivy.lang import Builder
from kivy.properties import BooleanProperty
from kivy.uix.label import Label
from kivy.uix.recyclegridlayout import RecycleGridLayout
from kivy.uix.recycleview.views import RecycleDataViewBehavior
from kivy.uix.recycleview.layout import LayoutSelectionBehavior

Builder.load_file("SelectableLabel.kv")


class SelectableRecycleGridLayout(LayoutSelectionBehavior, RecycleGridLayout):
    pass


class SelectableLabel(RecycleDataViewBehavior, TouchRippleBehavior, Label):
    """Implements a selectable label class used in RecycleView which shows
    Bluetooth devices that have been found during scan. Pressing an item causes
    the BluetoothManager to try to pair with that device.
    """
    index = None
    selected = BooleanProperty(False)
    selectable = BooleanProperty(True)

    def __init__(self, **kwargs):
        super(SelectableLabel, self).__init__(**kwargs)
        self.ripple_color = App.get_running_app().root.COLOR_BACKGROUND_SPINNER
        self.ripple_duration_in = 0.15
        self.ripple_duration_out = 0.05
        self.ripple_scale = 2

    def refresh_view_attrs(self, rv, index, data):
        """Called by the RecycleAdapter when the view is initially
        populated with the values from the data dictionary for this item.

        Args:
            rv (RecycleView): RecycleView instance that called the update
            index (int): Element index in RecycleView
            data (dict): The data dict used to populate this view

        Returns:
            [type]: [description]
        """
        self.index = index
        return super(SelectableLabel, self).refresh_view_attrs(rv, index, data)

    def on_touch_down(self, touch):
        """Receive a touch down event.

        Args:
            touch (MotionEvent): MotionEvent class touch received.
            The touch is in parent coordinates.
        """
        if self.collide_point(touch.x, touch.y):
            self.ripple_show(touch)
            touch.grab(self)

    def on_touch_move(self, touch):
        """Receive a touch move event.

        Args:
            touch (MotionEvent): MotionEvent class touch received.
            The touch is in parent coordinates.
        """
        if touch.grab_current is self:
            if not self.collide_point(touch.x, touch.y):
                self.ripple_fade()
                touch.ungrab(self)

    def on_touch_up(self, touch):
        """Receive a touch up event.

        Args:
            touch (MotionEvent): MotionEvent class touch received.
            The touch is in parent coordinates.

        Returns:
            bool: If True, the dispatching of the touch event will stop.
        """
        if touch.grab_current is self:
            self.ripple_fade()
            touch.ungrab(self)
            if self.collide_point(touch.x, touch.y):
                return self.parent.select_with_touch(self.index, touch)

    def apply_selection(self, rv, index, is_selected):
        """ Respond to the selection of items in the view.

        Args:
            rv (RecycleView): RecycleView object
            index (int): Element index in RecycleView
            is_selected (bool): Selection state
        """
        self.selected = is_selected
        if is_selected:
            # print("selection: {0}, index: {1}".format(rv.data[index], index))
            App.get_running_app().root.bcm.connect_to_device_by_index(index)
            self.parent.clear_selection()  # Deselect item to prevent weird behavior
