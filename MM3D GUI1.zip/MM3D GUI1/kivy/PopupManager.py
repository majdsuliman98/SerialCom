from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.uix.popup import Popup
from kivy.properties import ObjectProperty, ListProperty, NumericProperty, BooleanProperty, StringProperty

from Strings import TAB_NAMES, TAB_TITLES

Builder.load_file("./PopupManager.kv")


class PopupManager(Popup):
    """An implementation which brings a popup with multiple tabs to life.

    """
    COLOR_BACKGROUND = ListProperty([])
    COLOR_ICON = ListProperty([])
    COLOR_UNDERBAR = ListProperty([])
    COLOR_MOVING_ACCENT = ListProperty([])
    messagelabel = ObjectProperty()

    def __init__(self, manager, **kwargs):
        super(PopupManager, self).__init__(**kwargs)
        self.manager = manager
        self.manager.bind(COLOR_BACKGROUND=self.on_theme_change)

        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_ICON = self.manager.COLOR_ICON
        self.COLOR_UNDERBAR = self.manager.COLOR_UNDERBAR
        self.COLOR_MOVING_ACCENT = self.manager.COLOR_MOVING_ACCENT



    def show_popup(self,i):

        if i==1:
            self.messagelabel.text="The profile exceed the\n capacity of the crucible"
        elif i==2:
            self.messagelabel.text="Name is empty."
        elif i==3:
            self.messagelabel.text="EVERYTHING IS WRONG"
        elif i==4:
            self.messagelabel.text="Invalid Volume"
        elif i==5:
            self.messagelabel.text="No information"
        elif i==6:
            self.messagelabel.text="Name already exist. \nPlease use diferent"
        self.open()



    def on_theme_change(self, *args):
        """Called on theme change to change its color scheme too.
        """
        self.COLOR_BACKGROUND = self.manager.COLOR_BACKGROUND
        self.COLOR_ICON = self.manager.COLOR_ICON
        self.COLOR_UNDERBAR = self.manager.COLOR_UNDERBAR
        self.COLOR_MOVING_ACCENT = self.manager.COLOR_MOVING_ACCENT






