

import threading
import time 
from threading import Thread, Event, Semaphore
from HardwareControlUtilities.HommingRoutines import routine_homming_1, set_zero_machine
from kivy.logger import Logger
import RPi.GPIO as GPIO
from kivy.event import EventDispatcher 
from kivy.clock import Clock
from kivy.properties import (
    BooleanProperty,
    ListProperty,
    NumericProperty
)
from Ports import (
    DOOR_ENSTOP_INPUT
)
from HommingRoutines import (
    check_machine_state,
    turret_homming,
    z_homming,
    crucible_homming,
    set_zero_machine
)

# from BasicMotionFunctions import (
#     z_up,
#     z_up_2,
#     z_up_1,
#     z_down,
#     z_up_f,
#     z_down_f,
#     crucible_down,
#     crucible_up,
#     crucible_down_f,
#     crucible_up_f,
#     crucible_up_1,
#     crucible_up_2,
#     turret_clockwise,
#     turret_clockwise_f,
#     turret_anticlockwise_f,
#     turret_anticlockwise,
#     stop_stepper,
# )

from Routines import(
    routines
)

class HardwareControlManager(EventDispatcher):
    SET_ZERO_Z = BooleanProperty(False)
    SET_ZERO_CRUCIBLE = BooleanProperty(False)
    SET_ZERO_TURRET = BooleanProperty(False)
    SET_ZERO_MACHINE = BooleanProperty(False)
    
    
    def __init__(self, manager, **kwargs):
        super(HardwareControlManager, self).__init__(**kwargs)
        self.manager = manager
        ##Positions and offsets
        self.z_current_pos_1 = 0
        self.z_offset_1 = 0

        self.z_current_pos_2 = 0
        self.z_offset_2 = 0

        self.crucible_current_pos_1 = 0
        self.crucible_offset_1 = 0

        self.crucible_current_pos_2 = 0
        self.crucible_offset_2 = 0

        self.turret_current_pos = 0
        self.turret_offset = 0

        self.machine_moving = False
        self.machine_moving_last = self.machine_moving

        self.z_min_range = 0
        self.z_max_range = -160

        self.z_touch = 249

        self.crucible_min_range = 0
        self.crucible_max_range = 90

        self.turret_min_range = 0
        self.turret_max_range = 360




   