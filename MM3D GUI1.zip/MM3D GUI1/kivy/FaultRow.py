from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import BooleanProperty, NumericProperty, ObjectProperty, StringProperty

Builder.load_file("FaultRow.kv")


class FaultRow(BoxLayout):
    """Implementation of a row layout used to display faults along with buttons
    to clear them or to get more info about a given fault.
    """
    fault = StringProperty("")
    fault_code = NumericProperty()
    label = ObjectProperty(None)
    clearable = BooleanProperty(False)
    button_info = ObjectProperty(None)
    button_clear = ObjectProperty(None)

    def info(self, fault_code):
        """Opens up the InfoTab with a fault_code passed so it will open
        with content with that fault code's information.

        Args:
            fault_code (int): Fault code
        """
        App.get_running_app().root.tpm.add_tab("info", fault_code=fault_code)

    def clear(self, fault_code):
        """Clears a selected fault code by removing its FaultRow instance from
        the warning or error container and then clearing its state in the
        FaultManager.

        Args:
            fault_code (int): Fault code
        """
        height = 0
        for child in self.parent.children:
            # If it is the last child (widget) then don't sum it's height
            if child == self.parent.children[-1]:
                pass
            else:
                height += child.height
        self.parent.height = height

        def remove_self(*args):
            # At this moment I'm not 100% sure why but suppressing
            # the exception below fixes fault clearing. It's like if
            # this function was somehow called twice when self has already
            # been garbage collected and is a None, so it doesn't have
            # a remove_widget method.
            try:
                self.parent.remove_widget(self)
            except AttributeError:
                pass

        # Schedule removal and layout refresh for safety
        Clock.schedule_once(remove_self)
        Clock.schedule_once(self.parent.do_layout)
        fm = App.get_running_app().root.fm
        fm.fault_states[fm.fault_codes.index(fault_code)] = False
