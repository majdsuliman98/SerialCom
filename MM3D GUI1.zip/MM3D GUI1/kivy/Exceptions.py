class RegExMismatchException(Exception):
    pass


class NoBluetoothConnection(Exception):
    pass


class DataRefreshTimeout(Exception):
    pass
