"""[summary]
"""

# ! Menu icons:
ICON_MENU_SHUTDOWN = "../images/shutdown_248px.png"
ICON_MENU_UTILITIES = "../images/settings_248px.png"
ICON_MENU_PROCESS = "../images/process_248px.png"

ICON_MENU_LANGUAGE = "../images/language_248px.png"
ICON_MENU_SETTINGS = "../images/Settings_296px.png"
ICON_LANGUAGE_SCREEN = "../images/language_296px.png"
ICON_MENU_INVERT_TO_LIGHT = "../images/invert_off_248px.png"
ICON_MENU_INVERT_TO_DARK = "../images/invert_on_248px.png"
ICON_MENU_CONSUMABLES = "../images/consumables_248px.png"

ICON_MENU_HARDWARE = "../images/hardware_248px.png"
ICON_MENU_MATERIALS = "../images/materials_248px.png"
ICON_MENU_ADD_MATERIAL = "../images/qr_248px.png"

ICON_MENU_CRUCIBLE = "../images/crucible_248px.png"
ICON_MENU_NOZZLE = "../images/nozzle_248px.png"
ICON_MENU_DIES = "../images/die_casting_248px.png"
ICON_MENU_SKIMMER = "../images/skimmer.png"

ICON_MENU_CASTING_MATERIAL = "../images/materials_casting_248px.png"
ICON_MENU_INVESTMENT_POWDER = "../images/materials_investment_248px.png"
ICON_MENU_SAND = "../images/materials_sand_248px.png"

ICON_MENU_DIE_CASTING = "../images/die_casting_248px.png"
ICON_MENU_INVESTMENT_CASTING = "../images/investment_casting_248px.png"
ICON_MENU_SAND_CASTING = "../images/sand_casting_248px.png"

ICON_MENU_DIE_PREPARATION = "../images/die_preparation_248px.png"
ICON_MENU_DIE_METAL_CASTING = "../images/die_metal_casting_248px.png"

ICON_MENU_INVESTMENT_MOLD_PREPARATION = "../images/investment_mold_preparation_248px.png"
ICON_MENU_INVESTMENT_METAL_CASTING = "../images/investment_metal_casting_248px.png"

ICON_MENU_SAND_MOLD_PREPARATION = "../images/sand_mold_preparation_248px.png"
ICON_MENU_SAND_METAL_CASTING = "../images/sand_metal_casting_248px.png"

ICON_MENU_DATA = "../images/DATA.png"
ICON_MENU_CUSTOM = "../images/Custom.png"
ICON_MENU_CUSTOM_PROFILE = "../images/Custom_230px.png"
ICON_MENU_CUSTOM_PROFILE_PROCESS = "../images/Custom_190px.png"
ICON_MENU_CHANGE_HARDWARE = "../images/change_120px.png"
# $ Top panel:
LOGO_TOP_PANEL = "../images/MetalMakerLogo.png"
DEBUG_TOP_PANEL = "../images/shutdown_248px.png"
ICON_TOP_PANEL_INFO = "../images/info_56px.png"
BUTTON_TOP_PANEL_BACK = "../images/button_back_140px.png"
BUTTON_TOP_PANEL_NEXT = "../images/button_next_140px.png"
ICON_BLUETOOTH_ENABLED = "../images/bluetooth_enabled_56px.png"
ICON_BLUETOOTH_DISABLED = "../images/bluetooth_disabled_56px.png"
ICON_BLUETOOTH_CONNECTING_1 = "../images/bluetooth_connecting_1_56px.png"
ICON_BLUETOOTH_CONNECTING_2 = "../images/bluetooth_connecting_2_56px.png"
ICON_BLUETOOTH_CONNECTED = "../images/bluetooth_connected_56px.png"
ICON_BLUETOOTH_FAULT = "../images/bluetooth_fault_56px.png"
ICON_HOME = "../images/Home.png"
ICON_BACK_A = "../images/back_48px.png"


# $ Bottom panel
ICON_THERMO = "../images/THERMOMETER.png"
ICON_THERMO_CONTROL = "../images/temp_control.png"
ICON_BOTTOM_PANEL_NO_TEMP = "../images/no_temperature_56px.png"

# % Buttons:
ICON_BOTTOM_PANEL_LEFT_DIE = "../images/left_die_56px.png"
ICON_BOTTOM_PANEL_CRUCIBLE = "../images/crucible_56px.png"
ICON_BOTTOM_PANEL_CRUCIBLE_T = "../images/process_56px.png"
ICON_BOTTOM_PANEL_CRUCIBLE_DISCONNECTED = "../images/crucible_disconnected_56px.png"
ICON_BOTTOM_PANEL_RIGHT_DIE = "../images/right_die_56px.png"
ICON_BOTTOM_PANEL_TIME = "../images/time_56px.png"
ICON_BOTTOM_PANEL_SETPOINT_CRUCIBLE = "../images/setpoint_crucible_56px.png"
ICON_BOTTOM_PANEL_SETPOINT_DIES = "../images/setpoint_dies_56px.png"
ICON_BOTTOM_PANEL_PRESSURE = "../images/pressure_56px.png"
ICON_BOTTOM_PANEL_MATERIAL = "../images/AL.png"

ICON_BOTTOM_PANEL_AL = "../images/AL.png"
ICON_BOTTOM_PANEL_ZA = "../images/ZA.png"

ICON_BOTTOM_PANEL_NULL = "../images/NULL_56px.png"

ICON_BOTTOM_PANEL_AL_A356 =  "../images/AL_A356_56px.png"
ICON_BOTTOM_PANEL_AL_A380 =  "../images/AL_A380_56px.png"
ICON_BOTTOM_PANEL_AL_C355 =  "../images/AL_C355_56px.png"

ICON_BOTTOM_PANEL_ZA_ZA8 =  "../images/ZA_ZA8_56px.png"
ICON_BOTTOM_PANEL_ZA_ZA12 =  "../images/ZA_ZA12_56px.png"
ICON_BOTTOM_PANEL_ZA_ZA27 =  "../images/ZA_ZA27_56px.png"



ICON_BUTTON_HOME_LEFT_DIE = "../images/home_left_die_48px.png"
ICON_BUTTON_HOME_RIGHT_DIE = "../images/home_right_die_48px.png"
ICON_BUTTON_CLOSE_DIES = "../images/close_dies_48px.png"
ICON_BUTTON_OPEN_DIES = "../images/open_dies_48px.png"

ICON_BUTTON_ACCEPT = "../images/accept_48px.png"
ICON_BUTTON_BACK = "../images/back_48px.png"
ICON_BUTTON_CANCEL = "../images/close_48px.png"
ICON_BUTTON_CLOSE = "../images/close_48px.png"
ICON_BUTTON_EXIT = "../images/close_48px.png"
ICON_BUTTON_FINISH = "../images/accept_48px.png"
ICON_BUTTON_REPEAT = "../images/repeat_48px.png"

ICON_BUTTON_DISCONNECT = "../images/disconnect_48px.png"
ICON_BUTTON_SCAN = "../images/search_48px.png"
ICON_BUTTON_DRY = "../images/dry_48px.png"
ICON_BUTTON_NEW = "../images/new_48px.png"
ICON_BUTTON_REUSE = "../images/reuse_48px.png"
ICON_BUTTON_VACUUM_PUMP = "../images/vacuum_pump_48px.png"
ICON_BUTTON_EDIT = "../images/edit_48px.png"

ICON_BUTTON_START_CASTING_PROCESS = "../images/process_48px.png"
ICON_BUTTON_START_HEATING_CRUCIBLE = "../images/start_heating_crucible_48px.png"

ICON_BUTTON_UNPAIR = "../images/unpair_48px.png"

ICON_BUTTON_NO_IMAGE = "../images/no_image_48px.png"
ICON_NO_IMAGE = "../images/no_icon_248px.png"
ICON_TOGGLE_ON ="../images/Toggle_ON.png"
ICON_TOGGLE_OFF ="../images/Toggle_OFF.png"

ICON_START_BUTTON = "../images/StartButton.png"
ICON_STOP_BUTTON = "../images/StopButton.png"

ICON_MONITOR_BUTON = "../images/MonitorIcon.png"


ICON_BUTTON_DELETE = "../images/delete.png"

# ^ Standalone buttons:
BUTTON_INFO = "../images/button_info_64px.png"
BUTTON_CLEAR = "../images/button_clear_64px.png"
BUTTON_PLUS = "../images/button_plus_64px.png"
BUTTON_MINUS = "../images/button_minus_64px.png"
BUTTON_FULL = "../images/full_button_80px.png"
BUTTON_EDIT = "../images/edit_64px.png"

# & Adaptive button parts:
BUTTON_LEFT_END_34 = "../images/button_left_end_34px.png"
BUTTON_MIDDLE_PART_34 = "../images/button_body_34px.png"
BUTTON_RIGHT_END_34 = "../images/button_right_end_34px.png"
BUTTON_LEFT_END_48 = "../images/button_left_end_48px.png"
BUTTON_MIDDLE_PART_48 = "../images/button_body_48px.png"
BUTTON_RIGHT_END_48 = "../images/button_right_end_48px.png"
BUTTON_LEFT_END_64 = "../images/button_left_end_64px.png"
BUTTON_MIDDLE_PART_64 = "../images/button_body_64px.png"
BUTTON_RIGHT_END_64 = "../images/button_right_end_64px.png"

# * Loader image replacements:
LOADER_LOADING_IMAGE = "../images/loader_loading_32px.png"
LOADER_ERROR_IMAGE = "../images/no_image_48px.png"

# > GIFs and spinner icons:
GIF_LOADING = "../images/animation_loading_80px.gif"
ICON_SPINNER_CANCELED = "../images/close_80px.png"
ICON_SPINNER_SUCCESS = "../images/accept_80px.png"
ICON_SPINNER_FAILED = "../images/close_80px.png"

# < Tabbed popup icons and buttons:
BUTTON_ICON_TURN_VIDEOFEED_ON = "../images/video_feed_turn_on_48px.png"
BUTTON_ICON_TURN_VIDEOFEED_OFF = "../images/video_feed_turn_off_48px.png"
BUTTON_ICON_MINIMIZE = "../images/minimize_48px.png"
BUTTON_ICON_CLOSE = "../images/close_tab_48px.png"

# ! Others:
LOGO_PROFILE_PREVIEW = "../images/mm3d_preview_logo_296px.png"
LOGO_LOADING = '../images/mm3d_loading_logo_300px.png'
ICON_DROPDOWN = "../images/dropdown_24px.png"
ICON_PREPROCESS_MATERIAL = "../images/materials_64px.png"
ICON_PREPROCESS_CRUCIBLE = "../images/crucible_64px.png"
ICON_PREPROCESS_NOZZLE = "../images/nozzle_64px.png"
ICON_PREPROCESS_DIES = "../images/die_casting_64px.png"
IMAGE_WARNING_TRIANGLE = "../images/warning_triangle_384px.png"

# $ Consumable lists' data statuses
ICON_STATUS_OFFLINE = "../images/offline_32px.png"
ICON_STATUS_UPLOADING = "../images/uploading_32px.png"
ICON_STATUS_DOWNLOADING = "../images/downloading_32px.png"
ICON_STATUS_UP_TO_DATE = "../images/finished_32px.png"


ICON_SKIMMING_AND_DEGASSING = "../images/SkimmingAndDegassing.png"
ICON_SKIMMING = "../images/Skimming.png"
ICON_CONTINUE = "../images/Continue.png"
ICON_MATERIAL_AL ="../images/AL.png"
ICON_MATERIAL_ZA = "../images/ZA.png"
ICON_MELTING_MATERIAL= "../images/Melting_material.png"
GIF_LOADING = "../images/loading.gif"