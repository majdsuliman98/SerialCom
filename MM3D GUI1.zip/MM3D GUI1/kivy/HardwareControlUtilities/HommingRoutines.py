from threading import Thread
import time
from HardwareControlUtilities.Routines import routines 
from kivy.logger import Logger
from scenarios_machine import (
    ZERO_MACHINE,
    SCENARIO_1,
    SCENARIO_2
)

def check_machine_state(self, *args):
    #< The best of the scenarios
    if self.manager.ccm.STEPPER_ENDSTOPS == ZERO_MACHINE:
        self.SET_ZERO_MACHINE = True
        self.SET_ZERO_Z = True
        self.SET_ZERO_CRUCIBLE = True
        self.SET_ZERO_TURRET = True
        self.set_zero_machine()
        # self.out_position()
        # self.routines()
        Logger.debug("HOMMING: The machine is in point zero.")
        time.sleep(1)
        self.routines('cover')

    # elif self.manager.ccm.STEPPER_ENDSTOPS == SCENARIO_1:
    #     self.SET_ZERO_CRUCIBLE = True
    #     self.SET_ZERO_TURRET = True
    #     # self.z_up_homming()
    #     #Todo:create function
    #     Logger.debug("HOMMING: The machine has the z axis down.")

    elif self.manager.ccm.STEPPER_ENDSTOPS == SCENARIO_2:
        self.SET_ZERO_Z = True
        self.SET_ZERO_TURRET = True
        # self.crucible_up_homming()
        #todo: create function
        Logger.debug("HOMMING: The machine has the crucible tilted.")

    ##TODO: DECLARE SCENARIOS WHERE THE ENSTOPS ARE DAMAGE OR IMPOSIBLE POSITION
    else:
        Logger.debug("HOMMING: The machine is NOT in point zero.")
        self.routine_homming_1()

        

def set_zero_machine(self, *args):
    try:
        self.turret_offset = self.turret_current_pos
        self.SET_ZERO_TURRET = True
        Logger.debug("HOMMING: Offsets turret done.")

        self.z_offset_2 = self.z_current_pos_2
        self.z_offset_1 = self.z_current_pos_1 
        self.SET_ZERO_Z = True
        Logger.debug("HOMMING: Offsets z done.")

        self.crucible_offset_2 = self.crucible_current_pos_2
        self.crucible_offset_1 = self.crucible_current_pos_1 
        self.SET_ZERO_CRUCIBLE = True
        Logger.debug("HOMMING: Offsets crucible done.")
        self.SET_ZERO_MACHINE = True
        Logger.debug("HOMMING: Offsets machine done.")


    except Exception as e:
        Logger.debug("HOMMING: sOMETHING WENT WRONG SETTING THE OFFSETS FULL MACHINE")



def turret_homming(self, *args):
    self.turret_homming_thread_run = True

    def _zero_found():
        Logger.info("HOMMING: Found zero Turret")
        self.threadLock2.acquire()
        self.threadLock2.release()
        time.sleep(0.1)
        self.turret_offset = self.turret_current_pos
        self.SET_ZERO_TURRET = True

    # def _turret_homming():
    #     if not self.manager.ccm.STEPPER_ENDSTOPS[10]:
    #         self.threadLock2.acquire()
    #         self.threadLock2.release()
    #         self.turret_clockwise_homming()
    #         while self.turret_homming_thread_run:
    #             if self.manager.ccm.STEPPER_ENDSTOPS[10]:
    #                 self.turret_homming_thread_run = False
    #                 code = '!\n'
    #                 self.send_gcode(code=code)
    #                 _zero_found()
    #             else:
    #                 pass
    #             time.sleep(0.1)
    #     else:
    #         _zero_found()

    def _turret_homming():

        if not self.manager.ccm.STEPPER_ENDSTOPS[10]:
            step1 = True
            step2 = False
            control = True
            self.threadLock2.acquire()
            self.threadLock2.release()
            while self.turret_homming_thread_run:
                if step1:
                    # Logger.info("Homming: Homming turret starting...")
                    if control:
                        Logger.info("Homming: Homming turret starting...")
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        self.turret_clockwise(dist=20)
                        control = False
                        time.sleep(0.2)
                    elif self.manager.ccm.STEPPER_ENDSTOPS[11] or self.manager.ccm.STEPPER_ENDSTOPS[12] and not control:
                        Logger.info("Homming: found one endstop...")
                        self.stop_stepper()
                        step1 = False
                        step2 = True
                        control = True
                    elif self.manager.ccm.STEPPER_ENDSTOPS[10] and not control:
                        Logger.info("Homming: found home...")
                        self.stop_stepper()
                        step1 = False
                        self.turret_homming_thread_run = False
                        _zero_found()
                    elif not self.threadLock2.locked() and not control:
                        Logger.info("Homming: Next step...")

                        step1 = False
                        step2 = True
                        control = True
                elif step2:
                    if control:
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        self.turret_anticlockwise(dist=240)
                        control = False
                        Logger.info("Homming: Step2...")
                    elif self.manager.ccm.STEPPER_ENDSTOPS[10] and not control:
                        self.stop_stepper()
                        step2 = False
                        self.turret_homming_thread_run = False
                        _zero_found()
                        Logger.info("Homming: found home...")

        else:
            Logger.info("HOMMING: Turret is already in point zero.")
            _zero_found()

    if self.turret_homming_thread_run:
        self.turret_homming_thread = Thread(target=_turret_homming, name='turret homming')
        Logger.info("HOMMING: homming turret.")
        self.turret_homming_thread.start()



def z_homming(self,*args):
    self.z_homming_thread_run = True

    def _zero_found():
        Logger.info("HOMMING: Found zero Z")
        self.threadLock2.acquire()
        self.threadLock2.release()
        self.z_offset_2 = self.z_current_pos_2
        self.z_offset_1 = self.z_current_pos_1 
        self.SET_ZERO_Z = True
    def _z_homming():
        if  self.manager.ccm.STEPPER_ENDSTOPS[6] and self.manager.ccm.STEPPER_ENDSTOPS[8]:
            ##zero
            step1 = True
            step2 = False
            control = True
            while self.z_homming_thread_run:
                if step1:
                    if control and self.manager.ccm.STEPPER_ENDSTOPS[6] and self.manager.ccm.STEPPER_ENDSTOPS[8]:
                        control = False
                        Logger.info("HOMMING: Z is down ")
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        self.z_up_f(dist= self.z_touch)
                        time.sleep(0.5)
                    elif self.manager.ccm.STEPPER_ENDSTOPS[9] and self.manager.ccm.STEPPER_ENDSTOPS[7]:
                        step1= False
                        step2= True
                    elif not self.threadLock2.locked():
                        Logger.debug("Homming: Something went wrong, with homming z.")
                        Logger.debug("Homming:Z wrong Saludos")
                        self.z_homming_thread_run = False
                        step1= False
                        step2= False
                elif step2:
                    Logger.debug("Homming: Z in zero position")
                    _zero_found()
                    time.sleep(0.2)
                    step2 = False
                    self.z_homming_thread_run = False
        else:

            self.threadLock2.acquire()
            self.threadLock2.release()
            self.z_down(dist=5)
            step1 = True
            step2 = False
            step3 = False
            step4 = False
            step5 = False
            step6 = False
            time.sleep(0.4)
            while self.z_homming_thread_run:
                while step1 and self.z_homming_thread_run:

                    if self.manager.ccm.STEPPER_ENDSTOPS[6] or self.manager.ccm.STEPPER_ENDSTOPS[8]:
                        self.stop_stepper()
                        step1=False
                        step2=True

                    elif not self.threadLock2.locked():
                        step1=False
                        step2=True

                while step2 and self.z_homming_thread_run:
                    Logger.debug("Homming: step2")
                    self.threadLock2.acquire()
                    self.threadLock2.release()
                    self.z_up(dist=self.z_touch)
                    time.sleep(0.3)
                    step2=False
                    step3=True

                while step3 and self.z_homming_thread_run:

                    if self.manager.ccm.STEPPER_ENDSTOPS[9] and self.manager.ccm.STEPPER_ENDSTOPS[7]:
                        # print("both are done!")
                        step1= False
                        step2= False
                        step3= False
                        step4 = False
                        self.z_homming_thread_run = False

                    elif self.manager.ccm.STEPPER_ENDSTOPS[7]:
                        # print("llego el 1")
                        self.stop_stepper()
                        step2=False
                        step3=False
                        step4= True
                        step6= True
                        #todo: set z1 zero 

                    elif self.manager.ccm.STEPPER_ENDSTOPS[9]:
                        # print("llego el 2")
                        self.stop_stepper()
                        step2= False
                        step3= False
                        step4= True
                        step5= True
                        #todo: set z2 zero
                    

                    elif not self.machine_moving:
                        Logger.debug("Homming: Something went wrong, with homming z.")
                        self.z_homming_thread_run = False
                        step1= False
                        step2= False
                        step3= False

                while step4 and self.z_homming_thread_run:
                    # print("step4")
                    self.threadLock2.acquire()
                    self.threadLock2.release()
                    step4 = False
                    if step5:
                        # print("1 up ")
                        self.z_up_1(dist=20)
                    elif step6:
                        # print("2 up ")
                        self.z_up_2(dist=20)
                    time.sleep(0.1)

                while step5 and self.z_homming_thread_run:
                    # print("step5")
                    if self.manager.ccm.STEPPER_ENDSTOPS[7]:
                        # print("llego el 1")
                        self.stop_stepper()
                        self.z_homming_thread_run = False
                        step5 = False
                        _zero_found()

                while step6 and self.z_homming_thread_run:
                    # print("step6")
                    if self.manager.ccm.STEPPER_ENDSTOPS[9]:
                        # print("llego el 2")
                        self.stop_stepper()
                        self.z_homming_thread_run = False
                        step6 = False
                        _zero_found()

                time.sleep(0.1)
                    


    if self.z_homming_thread_run:
        self.z_homming_thread = Thread(target=_z_homming, name='z homming')
        Logger.info("HOMMING: homming z.")
        self.z_homming_thread.start()



def crucible_homming(self,*args):
    self.crucible_homming_thread_run = True
    def _zero_found():
        Logger.info("HOMMING: Found zero Crucible")
        self.threadLock2.acquire()
        self.threadLock2.release()
        self.crucible_offset_2 = self.crucible_current_pos_2
        self.crucible_offset_1 = self.crucible_current_pos_1 
        self.SET_ZERO_CRUCIBLE = True

    def _crucible_homming():
        if  True:
            self.threadLock2.acquire()
            self.threadLock2.release()
            self.crucible_down(dist=10)
            step1 = True
            step2 = False
            step3 = False
            step4 = False
            step5 = False
            step6 = False
            time.sleep(0.2)
            while self.crucible_homming_thread_run:
                while step1 and self.crucible_homming_thread_run:
                    # print("step1")
                    if self.manager.ccm.STEPPER_ENDSTOPS[1] or self.manager.ccm.STEPPER_ENDSTOPS[4]:
                        code = '!\n'
                        self.send_gcode(code=code)
                        step1=False
                        step2=True

                    elif not self.threadLock2.locked():
                        step1=False
                        step2=True

                while step2 and self.crucible_homming_thread_run:
                    # print("step2")
                    self.threadLock2.acquire()
                    self.threadLock2.release()
                    self.crucible_up(dist=90)
                    time.sleep(0.4)
                    step2=False
                    step3=True

                while step3 and self.crucible_homming_thread_run:
                    # print("step3")
                    step2 = False
                    if self.manager.ccm.STEPPER_ENDSTOPS[3] and self.manager.ccm.STEPPER_ENDSTOPS[0]:
                        # print("both are done!")
                        step3= False
                        step4 = False
                        self.crucible_homming_thread_run = False

                    elif self.manager.ccm.STEPPER_ENDSTOPS[0]:
                        # print("llego el 1")
                        code = '!\n'
                        self.send_gcode(code=code)
                        step3= False
                        step4= True
                        step6= True
                        #todo: set z1 zero 

                    elif self.manager.ccm.STEPPER_ENDSTOPS[3]:
                        # print("llego el 2")
                        code = '!\n'
                        self.send_gcode(code=code)
                        step3= False
                        step4= True
                        step5= True
                        #todo: set z2 zero

                    elif not self.threadLock2.locked():
                        Logger.debug("Homming: Something went wrong, with homming crucible.")
                        self.crucible_homming_thread_run = False
                        step3= False
                        
                while step4 and self.crucible_homming_thread_run:
                    # print("step4")
                    self.threadLock2.acquire()
                    self.threadLock2.release()
                    step4 = False
                    if step5:
                        # print("1 up ")
                        self.crucible_up_1(dist=10)
                    elif step6:
                        # print("2 up ")
                        self.crucible_up_2(dist=10)
                    time.sleep(0.1)

                while step5 and self.crucible_homming_thread_run:
                    # print("step5")
                    if self.manager.ccm.STEPPER_ENDSTOPS[0]:
                        # print("llego el 1")
                        code = '!\n'
                        self.send_gcode(code=code)
                        self.crucible_homming_thread_run = False
                        step5 = False
                        _zero_found()

                while step6 and self.crucible_homming_thread_run:
                    # print("step6")
                    if self.manager.ccm.STEPPER_ENDSTOPS[3]:
                        # print("llego el 2")
                        code = '!\n'
                        self.send_gcode(code=code)
                        self.crucible_homming_thread_run = False
                        step6 = False
                        _zero_found()
                        

                # time.sleep(0.1)
        else:
            ##zero
            _zero_found()

    if self.crucible_homming_thread_run:
        self.crucible_homming_thread = Thread(target=_crucible_homming, name='crucible homming')
        Logger.info("HOMMING: homming Crucible.")
        self.crucible_homming_thread.start()



def routine_homming_1(self):
    self.homming_routine_thread_run = True
    def _routine_homming_1():
        step1 = True
        step2 = False
        step3 = False
        control = True
        while self.homming_routine_thread:
            if step1:
                if self.manager.ccm.STEPPER_ENDSTOPS[7] and self.manager.ccm.STEPPER_ENDSTOPS[7] and control:
                    Logger.info("HOMMING: Z axis in zero position")
                    self.z_offset_2 = self.z_current_pos_2
                    self.z_offset_1 = self.z_current_pos_1 
                    self.SET_ZERO_Z = True
                    step1 = False
                    step2 = True
                    control = True
                elif not self.SET_ZERO_Z and control:
                    self.z_homming()
                    control = False
                    # print("sent comand")
                elif self.SET_ZERO_Z and not control:
                    step1 = False
                    step2 = True
                    control = True
                    # print("next step")
            elif step2:
                if self.manager.ccm.STEPPER_ENDSTOPS[10] and control:
                    Logger.info("HOMMING: Turret in zero position.")
                    control = True
                    self.turret_offset = self.turret_current_pos
                    self.SET_ZERO_TURRET = True
                    step2 = False
                    step3 = True
                elif not self.SET_ZERO_TURRET and control:
                    self.turret_homming()
                    control = False
                    # print("sent comand")
                elif self.SET_ZERO_TURRET and not control:
                    step2 = False
                    step3 = True
                    control = True
            elif step3:
                if self.manager.ccm.STEPPER_ENDSTOPS[0] and self.manager.ccm.STEPPER_ENDSTOPS[3] and control: 
                    self.crucible_offset_2 = self.crucible_current_pos_2
                    self.crucible_offset_1 = self.crucible_current_pos_1 
                    self.SET_ZERO_CRUCIBLE = True
                    step3 = False
                    self.homming_routine_thread_run = False
                    Logger.info("HOMMING: Crucible in zero position.")
                    self.SET_ZERO_MACHINE = True
                    time.sleep(1)
                    self.routines('cover')
                    self.homming_routine_thread.join()
                    
                    
                elif not self.SET_ZERO_CRUCIBLE and control:
                    self.crucible_homming()
                    control = False
                    # print("sent comand")
                elif self.SET_ZERO_CRUCIBLE and not control:
                    step3 = False
                    self.homming_routine_thread_run = False
                    Logger.info("HOMMING: Homming Routine finished")
                    self.SET_ZERO_MACHINE = True
                    time.sleep(1)
                    self.routines('cover')
                    self.homming_routine_thread.join()
                    
            time.sleep(0.1)
    if self.homming_routine_thread_run:
        self.homming_routine_thread = Thread(target=_routine_homming_1, name='routine homming')
        Logger.info("HOMMING: homming Routine.")
        self.homming_routine_thread.start()
