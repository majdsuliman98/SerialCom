## The machine is fully in zero position 
ZERO_MACHINE = [
    True,False,False,
    True,False,False,
    False,True,
    False,True,
    True,False,False,
    False,False
]
 
## only the z axis is all the way down, TOUCHING BOTH ENSTOPS
SCENARIO_1 = [  
    True,False,False,
    True,False,False,
    True,False,
    True,False,
    True,False,False,
    False,False
]

## only the crucible is all the way down, TOUCHING BOTH ENSTOPS
SCENARIO_2 = [  
    False,True,False,
    False,True,False,
    False,True,
    False,True,
    True,False,False,
    False,False
]