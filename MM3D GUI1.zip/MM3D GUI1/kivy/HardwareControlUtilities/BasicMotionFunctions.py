#### BASIC MOTION FUNCTIONS 
from threading import Thread
from kivy.logger import Logger

#DONT MOVE THE SPEED
z_speed_fast = str(2900)    # 3000
z_speed_medium = str(200)   # 350
z_speed_slow = str(100)     # 100

turret_speed_fast = str(2050)  #2100
turret_speed_slow = str(700)   #400

crucible_speed_fast = str(300)
crucible_speed_medium = str(40)
crucible_speed_slow = str(30)

#<< Z AXIS MOVEMENTS
def z_up_f(self,dist, *args):
    dist= str(dist)
    code = '$J=G21G91A'+dist+'Z'+dist+'F'+z_speed_fast+'\r\n'
    self.send_gcode(code=code)
    
def z_down_f(self, dist, *args):
    dist= str(dist)
    code = '$J=G21G91A-'+dist+'Z-'+dist+'F'+z_speed_fast +'\r\n'
    self.send_gcode(code=code)

def z_up(self,dist, *args):
    dist= str(dist)
    code = '$J=G21G91A'+dist+'Z'+dist+'F'+z_speed_medium+'\r\n'
    self.send_gcode(code=code)
    
def z_down(self, dist, *args):
    dist= str(dist)
    code = '$J=G21G91A-'+dist+'Z-'+dist+'F'+z_speed_medium+'\r\n'
    self.send_gcode(code=code)

def z_up_1(self,dist, *args):
    dist= str(dist)
    code = '$J=G21G91Z'+dist+'F'+z_speed_slow+'\r\n'
    self.send_gcode(code=code)

def z_up_2(self,dist, *args):
    dist= str(dist)
    code = '$J=G21G91A'+dist+'F'+z_speed_slow+'\r\n'
    self.send_gcode(code=code)

#<< CRUCIBLE MOVEMENTS

def crucible_down_f(self, dist, *args):
    dist= str(dist)
    code = '$J=G21G91X'+dist+'Y'+dist+'F'+crucible_speed_fast+'\r\n'
    self.send_gcode(code=code)
def crucible_up_f(self, dist, *args):
    dist= str(dist)
    code = '$J=G21G91X-'+dist+'Y-'+dist+'F'+crucible_speed_fast+'\r\n'
    self.send_gcode(code=code)


def crucible_down(self, dist, *args):
    dist= str(dist)
    code = '$J=G21G91X'+dist+'Y'+dist+'F'+crucible_speed_medium+'\r\n'
    self.send_gcode(code=code)
def crucible_up(self, dist, *args):
    dist= str(dist)
    code = '$J=G21G91X-'+dist+'Y-'+dist+'F'+crucible_speed_medium+'\r\n'
    self.send_gcode(code=code)

def crucible_up_1(self,dist, *args):
    dist= str(dist)
    code = '$J=G21G91X-'+dist+'F'+crucible_speed_slow+'\r\n'
    self.send_gcode(code=code)

def crucible_up_2(self,dist, *args):
    dist= str(dist)
    code = '$J=G21G91Y-'+dist+'F'+crucible_speed_slow+'\r\n'
    self.send_gcode(code=code)

#<< TURRET MOVEMENTS   
def turret_clockwise(self, dist, *args):
    dist= str(dist)
    code = '$J=G21G91B-'+dist+'F'+turret_speed_slow+'\r\n'
    self.send_gcode(code=code)

def turret_anticlockwise(self, dist, *args):
    dist= str(dist)
    code = '$J=G21G91B'+dist+'F'+turret_speed_slow+'\r\n'
    self.send_gcode(code=code)

def turret_clockwise_f(self, dist, *args):
    dist= str(dist)
    code = '$J=G21G91B-'+dist+'F'+turret_speed_fast+'\r\n'
    self.send_gcode(code=code)

def turret_anticlockwise_f(self, dist, *args):
    dist= str(dist)
    code = '$J=G21G91B'+dist+'F'+turret_speed_fast+'\r\n'
    self.send_gcode(code=code)

#!stop motion 
def stop_stepper(self, *args):
    code = '!\n'
    self.send_gcode(code=code)



    
