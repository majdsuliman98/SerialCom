from threading import Thread
import time 
from Ports import (
    DOOR_ENSTOP_INPUT
)
import RPi.GPIO as GPIO

from kivy.logger import Logger

def routines(self, name):
    self.routines_thread_run = True
    
    def _cover_crucible():
        step1 = True
        control = True
        Logger.info("Routines: Cover crucible starting...")
        if round(self.turret_current_pos) == 0 and round(self.z_current_pos_2) == 0:
            while self.routines_thread_run and self.SET_ZERO_MACHINE:
                if step1:
                    if round(self.z_current_pos_2) == 0 and control:
                        
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        #Send z axis down 
                        Logger.info("Routines: moving z axis down ...")
                        self.z_down_f(dist=self.z_touch)
                        control = False
                    elif round(self.z_current_pos_2) == -self.z_touch and not control:
                        step1 = False
                        control= True
                        Logger.info("Routines: Cover finished")
                        self.routines_thread_run = False
        else:
            Logger.info("Routines: Movement not allowed with that conditions.")
            self.routines_thread_run = False


    def _uncover_crucible():
        step1 = True
        control = True
        Logger.info("Routines: Uncover crucible starting...")
        if round(self.turret_current_pos) == 0 and round(self.z_current_pos_2) == -self.z_touch :
            while self.routines_thread_run and self.SET_ZERO_MACHINE:
                if step1:
                    if round(self.z_current_pos_2) == -self.z_touch and control:
                        
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        #Send z axis down 
                        Logger.info("Routines: moving z axis up ...")
                        self.z_up_f(dist=self.z_touch)
                        control = False
                    elif round(self.z_current_pos_2) == 0 and not control:
                        step1 = False
                        self.routines_thread_run = False
                        Logger.info("Routines: Uncover finished")
        else:
            Logger.info("Routines: Movement not allowed with that conditions.")
            self.routines_thread_run = False
    def _send_home_crucible():
        step1 = True
        step2 = False
        control = True
        Logger.info("Routines: Homming crucible starting...")
        self.threadLock2.acquire()
        self.threadLock2.release()
        if self.SET_ZERO_MACHINE and round(self.z_current_pos_2) == 0 and round(self.turret_current_pos) == 0:
            while self.routines_thread_run and self.SET_ZERO_MACHINE:
                if step1:
                    if control:
                        #Send z axis down 
                        Logger.info("Routines: moving crucible axis up ...")
                        self.crucible_up_f(dist=self.crucible_current_pos_2)
                        control = False
                    elif round(self.crucible_current_pos_2) == 0 and not control:
                        step1 = False
                        step2 = True
                        control = True
                        Logger.info("Routines: Crucible in zero position")
                if step2:
                    if round(self.crucible_current_pos_2) == 0 and control:
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        #Send z axis down 
                        Logger.info("Routines: cover crucible...")
                        self.z_down_f(dist=self.z_touch)
                        control = False
                    elif round(self.z_current_pos_2) == -self.z_touch and not control:
                        step2 = False
                        self.routines_thread_run = False
                        Logger.info("Routines: Crucible in home finished")
        else:
            Logger.info("Routines: Movement not allowed with that conditions.")
            self.routines_thread_run = False
    def _pouring_routine():
        step1 = True
        step2 = False
        step3 = False
        step4 = False
        control = True
        Logger.info("Routines: Pouring crucible starting...")
        self.threadLock2.acquire()
        self.threadLock2.release()
        if self.SET_ZERO_MACHINE and round(self.z_current_pos_2) == -self.z_touch and round(self.turret_current_pos) == 0:
            while self.routines_thread_run and self.SET_ZERO_MACHINE:
                if step1:
                    if control:
                        #Send z axis down 
                        Logger.info("Routines: moving z axis up ...")
                        self.z_up_f(dist=self.z_touch)
                        control = False
                    elif round(self.z_current_pos_2) == 0 and not control:
                        step1 = False
                        step2 = True
                        control = True
                        Logger.info("Routines: Z UP")
                if step2:
                    if round(self.z_current_pos_2) == 0 and control:
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        #Send z axis down 
                        Logger.info("Routines: Pouring crucible...")
                        self.crucible_down_f(dist=80)
                        control = False
                    elif round(self.crucible_current_pos_2) == 80 and not control:
                        step2 = False
                        step3 = True
                        control = True
                        Logger.info("Routines: Crucible waiting to Pour")
                        time.sleep(2)
                if step3:
                    if round(self.crucible_current_pos_2) == 80 and control:
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        #Send z axis down 
                        Logger.info("Routines: Crucible up...")
                        self.crucible_up_f(dist=80)
                        control = False
                    elif round(self.crucible_current_pos_2) == 0 and not control:
                        step3 = False
                        step4 = True
                        control = True
                        Logger.info("Routines: Crucible waiting to Pour")
                        time.sleep(2)
                if step4:
                    if round(self.crucible_current_pos_2) == 0 and control:
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        #Send z axis down 
                        Logger.info("Routines: Covering Crucible..")
                        self.z_down_f(dist=self.z_touch)
                        control = False
                    elif round(self.z_current_pos_2) == -self.z_touch and not control:
                        step4 = False
                        self.routines_thread_run = False
                        Logger.info("Routines: Pouring finished.")
                        self.manager.get_screen("MetalCastingProcess").transition_finish()
                time.sleep(0.5)
                        
        else:
            Logger.info("Routines: Movement not allowed with that conditions.")
            self.routines_thread_run = False

    def _add_material():
        step1 = True
        step2 = False
        step3 = False
        step4 = False
        control = True
        Logger.info("Routines: Adding material starting...")
        if round(self.turret_current_pos) == 0 and round(self.z_current_pos_2) == -self.z_touch :
            while self.routines_thread_run and self.SET_ZERO_MACHINE:
                if step1:
                    if round(self.z_current_pos_2) == -self.z_touch and control:
                        
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        #Send z axis down 
                        Logger.info("Routines: moving z axis up ...")
                        self.z_up_f(dist=110)
                        control = False
                    elif round(self.z_current_pos_2) == (-self.z_touch +110) and not control:
                        step1 = False
                        step2 = True
                        control = True
                        Logger.info("Routines: Z axis in position")
                if step2:
                    # Logger.debug(GPIO.input(DOOR_ENSTOP_INPUT["TOP"]))
                    if round(self.z_current_pos_2) == (-self.z_touch +110) and control:
                        self.manager.ccm.toggle_output_mcp(dev="LATCH_TOP",state=True)
                        #Send z axis down 
                        ##Todo: on latch
                        Logger.info("Routines: Openning Latch...")
                        control = False
                    elif GPIO.input(DOOR_ENSTOP_INPUT["TOP"]) == 0 and not control:
                        ##Todo: off latch
                        self.manager.ccm.toggle_output_mcp(dev="LATCH_TOP",state=False)
                        Logger.info("Routines: Latch openned")
                        step2 = False
                        step3 = True
                        control = True
                if step3:
                    if GPIO.input(DOOR_ENSTOP_INPUT["TOP"]) == 0 and control:
                        #Send z axis down 
                        Logger.info("Routines: waiting  to move the motor...")
                        control = False
                    elif GPIO.input(DOOR_ENSTOP_INPUT["TOP"]) == 1 and not control:
                        step3 = False
                        step4 = True
                        control = True
                        Logger.info("Routines: Latch closed")
                if step4:
                    if GPIO.input(DOOR_ENSTOP_INPUT["TOP"]) == 1 and control:
                        #Send z axis down 
                        Logger.info("Routines: MOving the motor...")
                        self.z_down_f(dist=110)
                        control = False
                    elif round(self.z_current_pos_2) == -self.z_touch and not control:
                        step4 = False
                        self.routines_thread_run = False
                        Logger.info("Routines: Motor down")
        else:
            Logger.info("Routines: Movement not allowed with that conditions.")
            self.routines_thread_run = False

    def _degassing2():
        step1 = True
        step2 = False
        step3 = False
        step4 = False
        step5 = False
        step6 = False
        step7 = False
        control = True
        if round(self.turret_current_pos) == 0 and round(self.z_current_pos_2) == -self.z_touch  and round(self.crucible_current_pos_2) == 0:
            while self.routines_thread_run and self.SET_ZERO_MACHINE:
                if step1:
                    if round(self.z_current_pos_2) == -self.z_touch and control:
                        Logger.info("Routines: Degassing starting.")
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        self.z_up_f(dist= self.z_touch )

                        control = False
                    elif round(self.z_current_pos_2) == 0 and not control:
                        step1 = False
                        step2 = True
                        control = True
                        Logger.info("Routines: Z axis up")

                elif step2:
                    if  round(self.z_current_pos_2) == 0  and control:
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        self.turret_clockwise_f(dist=180)
                        control = False
                    elif round(self.turret_current_pos) == -180 and not control:
                        step2 = False
                        step3 = True
                        control = True
                        self.manager.ccm.toggle_valve(dev="VALVE_RB", state=True)
                        Logger.info("Routines: Turret in degassing position")

                elif step3:
                    if  round(self.turret_current_pos) == -180  and control:
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        self.z_down_f(dist=self.z_touch)
                        control = False
                    elif round(self.z_current_pos_2) == -self.z_touch and not control:
                        step3 = False
                        step4 = True
                        control = True
                        Logger.info("Routines: Z axis down")

                elif step4:
                    if round(self.z_current_pos_2) == -self.z_touch and control:
                        time.sleep(0.2)
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        self.turret_clockwise(dist=21)

                        for i in range(2):
                            time.sleep(0.2)
                            self.threadLock2.acquire()
                            self.threadLock2.release()
                            self.turret_anticlockwise(dist=42)
                            time.sleep(0.2)
                            self.threadLock2.acquire()
                            self.threadLock2.release()
                            self.turret_clockwise(dist=42)
  
                        time.sleep(0.2)
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        self.turret_anticlockwise(dist=21)
                        control = False
                    elif round(self.turret_current_pos) == -180 and not control:
                        step4 = False
                        step5 = True
                        control = True
                        Logger.info("Routines: Degassing finished")
                elif step5:
                    if round(self.turret_current_pos) == -180 and control:
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        self.z_up_f(dist=self.z_touch)
                        control = False
                    elif round(self.z_current_pos_2) == 0 and not control:
                        step5 = False
                        step6 = True
                        control = True
                        Logger.info("Routines: z axis up.")
                        self.manager.ccm.toggle_valve(dev="VALVE_RB", state=False)

                elif step6:
                    if round(self.z_current_pos_2) == 0 and control:
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        self.turret_anticlockwise_f(dist=180)
                        control = False
                    elif round(self.turret_current_pos) == 0 and not control:
                        step6 = False
                        step7 = True
                        control = True
                        Logger.info("Routines: Turret in mode rest")
                elif step7:
                    if round(self.turret_current_pos) == 0 and control:
                        self.threadLock2.acquire()
                        self.threadLock2.release()
                        self.z_down_f(dist=self.z_touch)
                        control = False
                    elif round(self.z_current_pos_2) == -self.z_touch and not control:
                        step7 = False
                        self.routines_thread_run = False
                        Logger.info("Routines: Routine finished and crucible covered")
                        if self.manager.ccm.DEGASSING:
                            self.manager.get_screen("MetalCastingProcess").degassing_next_screen()
        else:
            Logger.info("Routines: Movement not allowed with that conditions.")
            self.routines_thread_run = False

    if self.routines_thread_run:
        if name == 'cover':
            self.routines_thread = Thread(target=_cover_crucible, name="Cover")
            self.routines_thread.start()
        elif name == 'uncover':
            self.routines_thread = Thread(target=_uncover_crucible, name="Uncover")
            self.routines_thread.start()
        elif name == 'degassing':
            self.routines_thread = Thread(target=_degassing2, name="Degassing")
            self.routines_thread.start()
        elif name == 'add_material':
            self.routines_thread = Thread(target=_add_material, name="Material")
            self.routines_thread.start()
        elif name == 'home_crucible':
            self.routines_thread = Thread(target=_send_home_crucible, name="Crucible Home")
            self.routines_thread.start()
        elif name == 'pouring_routine':
            self.routines_thread = Thread(target=_pouring_routine(), name="Pouring routine")
            self.routines_thread.start()