"""First attempt at making app multilingual.

   Language codes: https://www.science.co.il/language/Locale-codes.php

   DO NOT USE AUTOFORMATTER HERE!
"""


from Faults import (
    # ! Error codes:
    ERROR_ARDUINO_USB0_INIT_CONNECTION,
    ERROR_ARDUINO_USB1_INIT_CONNECTION,
    ERROR_MCP23017_INIT_CONNECTION,
    ERROR_MPU9250_INIT_CONNECTION,
    ERROR_SOFTWARE_ID_MISMATCH,
    ERROR_MACHINE_ID_MISMATCH,
    ERROR_CRUCIBLE_SENSOR_1,
    ERROR_CRUCIBLE_SENSOR_2,
    ERROR_DIE_LEFT_SENSOR,
    ERROR_DIE_RIGHT_SENSOR,
    ERROR_OPEN_DOORS,
    ERROR_ARDUINO_CONTROL_RESPONSE_FAILSAFE_TRIGGER,
    ERROR_ARDUINO_STEPPER_RESPONSE_FAILSAFE_TRIGGER,
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE,
    ERROR_TEMPERATURE_TOO_HIGH_DIES,
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_1,
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_2,
    ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_LEFT,
    ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_RIGHT,
    ERROR_TEMPERATURE_TOO_HIGH_AMBIENT,
    ERROR_HUMIDITY_TOO_HIGH_AMBIENT,
    ERROR_ARDUINO_CONTROL_READ,
    ERROR_ARDUINO_STEPPER_READ,
    ERROR_NANO_INIT_CONNECTION,
    #^ Faults crucible microchip
    ERROR_CRUCIBLE_DISCONNECTED,
    ERROR_MICROCHIP_READING,
    ERROR_CRUCIBLE_INCOMPATIBLE,
    # ^ Warning codes:
    WARNING_OPEN_DOORS,
    WARNING_RESIDUAL_HEAT_CRUCIBLE,
    WARNING_RESIDUAL_HEAT_DIES,
    WARNING_TEMPERATURE_HIGH_CRUCIBLE_1,
    WARNING_TEMPERATURE_HIGH_CRUCIBLE_2,
    WARNING_TEMPERATURE_HIGH_DIE_LEFT,
    WARNING_TEMPERATURE_HIGH_DIE_RIGHT,
    WARNING_TEMPERATURE_HIGH_AMBIENT,
    WARNING_HUMIDITY_HIGH_AMBIENT,
    # WARNING_TEMPERATURE_LOW_CRUCIBLE_1,
    # WARNING_TEMPERATURE_LOW_CRUCIBLE_2,
    # WARNING_TEMPERATURE_LOW_DIE_LEFT,
    # WARNING_TEMPERATURE_LOW_DIE_RIGHT,
    # WARNING_TEMPERATURE_LOW_AMBIENT,
    # WARNING_HUMIDITY_LOW_AMBIENT,
    # WARNING_LOADCELLS_READINGS_DIFFERENCE,
    WARNING_EMERGENCY_BUTTON,
    #% Warning hardware lifespan codes:
    WARNING_LIFESPAN_CRUCIBLE,
    WARNING_LIFESPAN_SKIMMER,
    WARNING_LIFESPAN_NOZZLE,
    # > Bluetooth codes:
    BLUETOOTH_EOF,
    BLUETOOTH_TIMEOUT,
    BLUETOOTH_AGENT_NOT_REGISTERED,
    BLUETOOTH_AGENT_NOT_UNREGISTERED,
    BLUETOOTH_DISCOVERABLE_OFF_FAILED,
    BLUETOOTH_UNABLE_TO_START_DISCOVERY,
    BLUETOOTH_DISCOVERY_IN_PROGRESS,
    BLUETOOTH_UNABLE_TO_STOP_DISCOVERY,
    BLUETOOTH_UNABLE_TO_GET_DEVICE_LIST,
    BLUETOOTH_PAIRING_ERROR,
    BLUETOOTH_UNABLE_TO_UNPAIR,
    BLUETOOTH_UNABLE_TO_CANCEL_PAIRING,
    # BLUETOOTH_CANNOT_POWER_ON,
    BLUETOOTH_CONNECTION_LOST,
    BLUETOOTH_UNABLE_TO_DISCONNECT,
    BLUETOOTH_NOT_IMPLEMENTED_ERROR,
    BLUETOOTH_UNKNOWN_ERROR,
    BLUETOOTH_OTHER_ERROR,
    # * Other codes:
    UNKNOWN_FAULT,
    UNEXPECTED_FAULT,
    # $ MAX31856 fault codes:
    # MAX31856_FAULT_CJRANGE,
    # MAX31856_FAULT_TCRANGE,
    # MAX31856_FAULT_CJHIGH,
    # MAX31856_FAULT_CJLOW,
    # MAX31856_FAULT_TCHIGH,
    # MAX31856_FAULT_TCLOW,
    # MAX31856_FAULT_OVUV,
    # MAX31856_FAULT_OPEN,
    # & PiCamera faults:
    WARNING_PICAMERA_GENERAL,
    WARNING_PICAMERA_DEPRECATED,
    WARNING_PICAMERA_FALLBACK,
    WARNING_PICAMERA_RESIZER_ENCODING,
    WARNING_PICAMERA_ALPHA_STRIPPING,
    ERROR_PICAMERA_GENERAL,
    ERROR_PICAMERA_VALUE_ERROR,
    ERROR_PICAMERA_RUNTIME_ERROR,
    ERROR_PICAMERA_CLOSED,
    ERROR_PICAMERA_NOT_RECORDING,
    ERROR_PICAMERA_ALREADY_RECORDING,
    ERROR_PICAMERA_MMAL,
)

# ^ Symbols:
CM3 = " cm\u00b3"
DEG_C = " \u00b0C"

NAV_BUTTONS = {
    "back": {
        "en": "BACK",
        "pl": "WRÓĆ"
    },
    "exit": {
        "en": "EXIT",
        "pl": "WYJDŹ"
    },
    "next": {
        "en": "NEXT",
        "pl": "DALEJ"
    },
}

# $ Main screens' translations
MAIN_MENU = {
    "process": {
        "en": "PROCESS",
        "pl": "PROCESY"
    },
    "shutdown": {
        "en": "SHUTDOWN",
        "pl": "ZAKOŃCZ"
    },
    "utilities": {
        "en": "UTILITIES",
        "pl": "NARZĘDZIA"
    },
}

UTILITIES_MENU = {
    "machine settings": {
        "en": "MACHINE SETTINGS",
        "pl": "USTAWIENIA MASZYNY"
    },
    "language": {
        "en": "LANGUAGE",
        "pl": "JĘZYK"
    },
    "invert_colors": {
        "en": "INVERT COLORS",
        "pl": "ODWRÓĆ KOLORY"
    },
    "consumables": {
        "en": "CONSUMABLES",
        "pl": "\nMATERIAŁY\nI CZĘŚCI"
    },
}

UTILITIES_SCREEN = {
    "selected_language": {
        "en": "Selected language:",
        "pl": "Wybrany język:"
    },
    "invert_colors": {
        "en": "Invert colors:",
        "pl": "Odwróć:"
    }
}

CONSUMABLES_MENU = {
    "add_consumable": {
        "en": "ADD CONSUMABLE",
        "pl": "DODAJ NOWY"
    },
    "hardware": {
        "en": "HARDWARE",
        "pl": "PODZESPOŁY"
    },
    "materials": {
        "en": "MATERIALS",
        "pl": "MATERIAŁY"
    },
}

HARDWARE_MENU = {
    "crucible": {
        "en": "CRUCIBLES",
        "pl": "TYGLE"
    },
    "dies": {
        "en": "DIES",
        "pl": "MATRYCE"
    },
    "nozzle": {
        "en": "\nDEGASSING\nNOZZLES",
        "pl": "DYSZE"
    },
    "skimmer": {
        "en": "SKIMMER",
        "pl": "CEDZIDŁO"
    },
}

MATERIALS_MENU = {
    "casting_alloy": {
        "en": "\nCASTING\nALLOYS",
        "pl": "\nSTOPY\nODLEWNICZE"
    },
    "green_sand": {
        "en": "\nGREEN\nSAND",
        "pl": "\nPIASEK\nFORMIERSKI"
    },
    "investment_powder": {
        "en": "\nINVESTMENT\nPOWDERS",
        "pl": "\nPROSZKI\nFORMIERSKIE"
    },
}

PROCESS_MENU = {
    "die_casting": {
        "en": "DIE CASTING",
        "pl": "\nODLEWANIE\nMATRYCOWE"
    },
    "investment_casting": {
        "en": "\nINVESTMENT\nCASTING",
        "pl": "\nODLEWANIE\nMETODĄ TRACONĄ"
    },
    "sand_casting": {
        "en": "SAND CASTING",
        "pl": "\nODLEWANIE\nPIASKOWE"
    },
}

PROCESS_MENUS = {
    "die_preparation": {
        "en": "DIE PREPARATION",
        "pl": "PRZYGOTOWANIE MATRYC"
    },
    "metal_casting": {
        "en": "METAL CASTING",
        "pl": "ODLEWANIE"
    },
    "mold_preparation": {
        "en": "MOLD PREPARATION",
        "pl": "PRZYGOTOWANIE FORMY"
    },
}

PROCESS_FINISHING = {
    "finish_die_cast": {
        "en": "FINISHING DIE METAL CASTING PROCESS",
        "pl": "ZAKAŃCZANIE PROCESU ODLEWANIA DO MATRYC"
    },
    "finish_die_prep": {
        "en": "FINISHING DIE PREPARATION PROCESS",
        "pl": "ZAKAŃCZANIE PROCESU PRZYGOTOWANIA MATRYC"
    },
    "finish_investment_cast": {
        "en": "FINISHING INVESTMENT METAL CASTING PROCESS",
        "pl": "ZAKAŃCZANIE PROCESU ODLEWANIA METODĄ TRACONĄ",
    },
    "finish_investment_prep": {
        "en": "FINISHING MOLD PREPARATION PROCESS",
        "pl": "ZAKAŃCZANIE PROCESU PRZYGOTOWANIA FORMY",
    },
    "finish_sand_cast": {
        "en": "FINISHING SAND METAL CASTING PROCESS",
        "pl": "ZAKAŃCZANIE PROCESU ODLEWANIA PIASKOWEGO",
    },
    "finish_sand_prep": {
        "en": "FINISHING SAND MOLD PREPARATION PROCESS",
        "pl": "ZAKAŃCZANIE PROCESU PRZYGOTOWANIA FORMY PIASKOWEJ",
    },
    "finish_cast": {
        "en": "FINISHING METAL CASTING PROCESS",
        "pl": "ZAKAŃCZANIE PROCESU ODLEWANIA METODĄ TRACONĄ",
    },
}

# % Tab translations
TAB_TITLES = {
    "bluetooth": {
        "en": "Bluetooth",
        "pl": "Bluetooth",
    },
    "confirmation": {
        "en": "Confirmation",
        "pl": "Potwierdź akcję",
    },
    "info": {
        "en": "Information",
        "pl": "Informacje",
    },
    "status": {
        "en": "Machine status",
        "pl": "Status urządzenia",
    },
    "video": {
        "en": "Camera feed",
        "pl": "Obraz z kamery",
    },
}

TAB_NAMES = {
    "bluetooth": {
        "en": "BLUETOOTH",
        "pl": "BLUETOOTH",
    },
    "confirmation": {
        "en": "CONFIRMATION",
        "pl": "POTWIERDZENIE",
    },
    "info": {
        "en": "INFO",
        "pl": "INFO",
    },
    "status": {
        "en": "STATUS",
        "pl": "STATUS",
    },
    "video": {
        "en": "VIDEO",
        "pl": "KAMERA",
    },
}

BLUETOOTH_TAB = {
    "accept": {
        "en": "ACCEPT",
        "pl": "AKCEPTUJ",
    },
    "already_paired_description": {
        "en": "Selected device has been previously paired with this M1 Foundry. "
        + "Please open MetalMaker 3D app, select this machine on the main screen and wait for automatic connection.",
        "pl": "Wybrane urządzenie zostało już wcześniej sparowane z Twoim urządzeniem M1 Foundry."
        + "Otwórz aplikację MM3D na telefonie, wybierz to urządzenie z listy i poczekaj na automatyczne połączenie.",
    },
    "available_devices": {
        "en": "Available devices:",
        "pl": "Dostępne urządzenia:",
    },
    "bluetooth_status_connected_to": {
        "en": "Current Bluetooth status: connected to ",
        "pl": "Aktualny status połączenia Bluetooth: połączono z ",
    },
    "bluetooth_status_current": {
        "en": "Current Bluetooth status: ",
        "pl": "Aktualny status połączenia Bluetooth: ",
    },
    "bluetooth_status_waiting": {
        "en": "Current Bluetooth status: enabled, waiting for connection",
        "pl": "Aktualny status połączenia Bluetooth: oczekuje na połączenie",
    },
    "cancel": {
        "en": "CANCEL",
        "pl": "ANULUJ",
    },
    "canceled": {
        "en": "Canceled",
        "pl": "Anulowano",
    },
    "connected_description": {
        "en": "Your device is connected to MM3D App using Bluetooth. Now you can manage your "
        + "consumables, start processes or install updates. Please make sure your device stays "
        + "in range during the time it is required to.",
        "pl": "",
    },
    "disconnect": {
        "en": "DISCONNECT",
        "pl": "ROZŁĄCZ",
    },
    "disconnecting": {
        "en": "Disconnecting...",
        "pl": "Rozłączanie...",
    },
    "exit": {
        "en": "EXIT",
        "pl": "WYJDŹ",
    },
    "not_connected_description": {
        "en": "Please use the button below to begin searching for new devices to pair with or select this machine "
        + "in your MetalMaker 3D mobile app, if you have your phone paired already, and wait for automatic connection.",
        "pl": "Użyj przycisku poniżej aby rozpocząć skanowanie w poszukiwaniu nowych urządzeń lub wybierz to "
        + "urządzenie w aplikacji MM3D na swoim telefonie, jeżeli został już sparowany, i poczekaj na automatyczne "
        + "połączenie.",
    },
    "pairing": {
        "en": "Pairing...",
        "pl": "Parowanie...",
    },
    "pairing_info": {
        "en": "\n\nAccept the pairing request on your\nphone before the time runs out",
        "pl": "\n\nZaakceptuj prośbę o sparowanie na swoim\ntelefonie zanim upłynie czas",
    },
    "rescan": {
        "en": "RESCAN",
        "pl": "POWTÓRZ SKAN",
    },
    "scan": {
        "en": "SCAN",
        "pl": "SKANUJ",
    },
    "scanning": {
        "en": "Scanning...",
        "pl": "Skanowanie...",
    },
    "stop_scan": {
        "en": "STOP SCAN",
        "pl": "ZATRZYMAJ SKAN",
    },
    "success": {
        "en": "Success!",
        "pl": "Sukces!",
    },
    "timed_out": {
        "en": "Timed out",
        "pl": "Przekroczono limit czasu",
    },
    "unpair": {
        "en": "UNPAIR",
        "pl": "ROZPARUJ",
    },
}

CONFIRMATION_TAB = {
    "cancel_process_message": {
        "en": "Are you sure you want to cancel the current process?",
        "pl": "Czy na pewno chcesz przerwać aktualny proces?",
    },
    "process_stopped_message": {
        "en": "Process has been canceled due to losing Bluetooth connection.",
        "pl": "Proces został przerwany z uwagi na utratę połączenia Bluetooth.",
    },
    "remove_consumable_message": {
        "en": "Are you sure you want to remove the selected consumable?",
        "pl": "Czy na pewno chcesz usunąć wybrany materiał lub część?",
    },
        "change_cruicible_message": {
        "en": "Are you sure you want to change the cruicible?",
        "pl": "Czy na pewno chcesz ...?",
    },
        "change_nozzle_message": {
        "en": "Are you sure you want to change the nozzle?",
        "pl": "Czy na pewno chcesz ...?",
    },
        "change_skimmer_message": {
        "en": "Are you sure you want to change the skimmer?",
        "pl": "Czy na pewno chcesz ...?",
    },
}

INFO_TAB = {
    "back_to_main": {
        "en": "BACK TO MAIN PAGE",
        "pl": "",
    },
}

STATUS_TAB = {
    "ambient_cond_title": {
        "en": "Ambient temperature and humidity:",
        "pl": "Temperatura i wilgotność otoczenia:",
    },
    "closed": {
        "en": "Closed",
        "pl": "Zamknięty",
    },
    "crucible_cjc_title": {
        "en": "Crucible temperature modules temperatures:",
        "pl": "Temperatury modułów pomiarowych tygla:",
    },
    "crucible_temp_title": {
        "en": "Crucible temperature (TC1, TC2, avg.):",
        "pl": "Temperatura tygla (TC1, TC2, średnia):",
    },
    "device_monitor_title": {
        "en": "Device monitor:",
        "pl": "Monitor urządzenia:",
    },
    "device_status": {
        "en": "Device status: ",
        "pl": "Status urządzenia: ",
    },
    "dies_cjc_title": {
        "en": "Dies temperature modules temperatures:",
        "pl": "Temperatury modułów pomiarowych matryc:",
    },
    "dies_temp_title": {
        "en": "Dies temperatures:",
        "pl": "Temperatury matryc:",
    },
    "error": {
        "en": "Error",
        "pl": "Błąd",
    },
    "error_list_title": {
        "en": "Detected errors:",
        "pl": "Wykryte błędy:",
    },
    "fault_message": {
        "en": "Please use the information provided to fix the faults listed below or to provide"
        + " necessary information for customer support.",
        "pl": "Wiadomość",
    },
    "open": {
        "en": "Fully open",
        "pl": "W pełni otwarty",
    },
    "partially_open": {
        "en": "Partially open",
        "pl": "Częściowo otwarty",
    },
    "pressure_title": {
        "en": "Pressure values:",
        "pl": "Wartości ciśnienia:",
    },
    "valve_argon_control_title": {
        "en": "Argon control valve openness:",
        "pl": "Stopień otwarcia zaworu kontrolnego argonu:",
    },
    "valve_argon_main_title": {
        "en": "Argon main valve:",
        "pl": "Główny zawór argonu:",
    },
    "valve_main_vacuum_title": {
        "en": "Vacuum main valve:",
        "pl": "Główny zawór pompy próżniowej:",
    },
    "valve_vacuum_split_title": {
        "en": "Vacuum split valve state:",
        "pl": "Zawór rozdzielczy pompy póżniowej:",
    },
    "warning_list_title": {
        "en": "Detected warnings:",
        "pl": "Wykryte ostrzeżenia:",
    },
    "weight_title": {
        "en": "Weight values (1, 2, avg.):",
        "pl": "Odczyty wagi (1, 2, średnia):",
    },
}

VIDEO_TAB = {
    "brightness": {
        "en": "Brightness",
        "pl": "Jasność"
    },
    "contrast": {
        "en": "Contrast",
        "pl": "Kontrast"
    },
    "exception_camera": {
        "en": "Error, unable to get\nimage from camera!",
        "pl": "Błąd, nie można pobrać\nobrazu z kamery!",
    },
    "exception_file_read": {
        "en": "VideoFeedTab: Unable to read camera settings from file.",
        "pl": "",
    },
    "exception_file_write": {
        "en": "VideoFeedTab: Unable to save settings to file.",
        "pl": "",
    },
    "exposure": {
        "en": "Exposure comp.",
        "pl": "Kompens. eksp."
    },
    "sharpness": {
        "en": "Sharpness",
        "pl": "Ostrość"
    },
    "toggle_lighting": {
        "en": "Toggle lighting",
        "pl": "Oświetlenie"
    },
    "turn_off": {
        "en": "TURN OFF",
        "pl": "WYŁĄCZ"
    },
    "turn_on": {
        "en": "TURN ON",
        "pl": "ZAŁĄCZ"
    },
    "zoom": {
        "en": "Zoom",
        "pl": "Powiększenie"
    },
}

# < Consumable lists
CONSUMABLE_RV = {
    "crucibles": {
        "title": {
            "en": "Crucibles",
            "pl": "Tygle"
        },
        "column_1": {
            "en": "No.",
            "pl": "Lp."
        },
        "column_2": {
            "en": "Bound to",
            "pl": "Przyp. materiał"
        },
        "column_3": {
            "en": "Lifespan left",
            "pl": "Żywotność"
        },
    },
    "dies": {
        "title": {
            "en": "Casting dies",
            "pl": "Matryce",
        },
        "column_1": {
            "en": "No.",
            "pl": "Lp."
        },
        "column_2": {
            "en": "Profile",
            "pl": "Profil",
        },
        "column_3": {
            "en": "Lifespan left",
            "pl": "Żywotność",
        },
    },
        "skimmer": {
        "title": {
            "en": "Skimmer",
            "pl": "-",
        },
        "column_1": {
            "en": "No.",
            "pl": "Lp."
        },
        "column_2": {
            "en": "Lifespan left",
            "pl": "Żywotność",
        },
        "column_3": {
            "en": "",
            "pl": "",
        },
    },
    "nozzles": {
        "title": {
            "en": "Degassing nozzles",
            "pl": "Dysze",
        },
        "column_1": {
            "en": "No.",
            "pl": "Lp."
        },
        "column_2": {
            "en": "Lifespan left",
            "pl": "Żywotność",
        },
        "column_3": {
            "en": "",
            "pl": "",
        },
    },
    "casting_mat": {
        "title": {
            "en": "Casting materials",
            "pl": "Stopy odlewnicze",
        },
        "column_1": {
            "en": "No.",
            "pl": "Lp."
        },
        "column_2": {
            "en": "Name",
            "pl": "Nazwa"
        },
        "column_3": {
            "en": "Amount avail.",
            "pl": "Pozost. ilość"
        },
    },
    "investment_mat": {
        "title": {
            "en": "Investment powders",
            "pl": "Proszki formierskie",
        },
        "column_1": {
            "en": "No.",
            "pl": "Lp."
        },
        "column_2": {
            "en": "Name",
            "pl": "Nazwa"
        },
        "column_3": {
            "en": "Amount avail.",
            "pl": "Pozost. ilość"
        },
    },
    "sand_mat": {
        "title": {
            "en": "Sand materials",
            "pl": "Piasek formierski",
        },
        "column_1": {
            "en": "No.",
            "pl": "Lp."
        },
        "column_2": {
            "en": "Name",
            "pl": "Nazwa"
        },
        "column_3": {
            "en": "Amount avail.",
            "pl": "Pozost. ilość"
        },
    },
    "remove_button": {
        "en": "REMOVE",
        "pl": "USUŃ"
    },
    "none": {
        "en": "None",
        "pl": "Brak"
    },
}

# & Translations of processes
PROCESS_COMMON = {
    "accept": {
        "en": "ACCEPT",
        "pl": "AKCEPTUJ",
    },
    "begin_pouring": {
        "en": "BEGIN POURING",
        "pl": "ROZPOCZNIJ ODLEWANIE",
    },
    "begin_process": {
        "en": "BEGIN PROCESS",
        "pl": "ROZPOCZNIJ PROCES",
    },
    "casting": {
        "en": "CASTING",
        "pl": "ODLEWANIE",
    },
    "caution": {
        "en": "CAUTION!",
        "pl": "UWAGA!",
    },
    "close_dies": {
        "en": "CLOSE DIES",
        "pl": "ZAMKNIJ MATRYCE",
    },
    "finish": {
        "en": "FINISH",
        "pl": "ZAKOŃCZ",
    },
    "home_left_die": {
        "en": "HOME LEFT DIE",
        "pl": "BAZUJ LEWĄ MATRYCĘ",
    },
    "home_right_die": {
        "en": "HOME RIGHT DIE",
        "pl": "BAZUJ PRAWĄ MATRYCĘ",
    },
    "new_material_add": {
        "en": "Drop metal alloy ingots of the new material one-by-one into the hopper until "
        + "the measured new material is equal to the required new material.\n\n",
        "pl": "",
    },
    "new_material_measured": {
        "en": "Measured new material volume: ",
        "pl": "",
    },
    "new_material_required": {
        "en": "Required new material volume: ",
        "pl": "",
    },
    "no": {
        "en": "NO",
        "pl": "NIE",
    },
    "open_dies": {
        "en": "OPEN DIES",
        "pl": "OTWÓRZ MATRYCE",
    },
    "recycled_material_add": {
        "en": "Drop metal alloy ingots of the recycled material one-by-one into the hopper until "
        + "the measured new material is equal to the required new material.\n\n",
        "pl": "",
    },
    "recycled_material_measured": {
        "en": "Measured recycled material volume: ",
        "pl": "",
    },
    "recycled_material_required": {
        "en": "Required recycled material volume: ",
        "pl": "",
    },
    "repeat": {
        "en": "REPEAT",
        "pl": "POWTÓRZ",
    },
    "start_casting": {
        "en": "START CASTING",
        "pl": "ROZPOCZNIJ ODLEWANIE",
    },
    "yes": {
        "en": "YES",
        "pl": "TAK",
    },
}

DIE_PREPARATION = {
    "screen_1": {
        "en": "Homing die carriages, please wait.",
        "pl": "",
    },
    "screen_2": {
        "en": "Secure the left die to the left carriage in the foundry using the hardware provided.",
        "pl": "",
    },
    "screen_3": {
        "en": "Plug in the heater and thermistor connections for the left die.",
        "pl": "",
    },
    "screen_4": {
        "en": "Close the front door.",
        "pl": "",
    },
    "screen_5": {
        "en": "Homing die carriages, please wait.",
        "pl": "",
    },
    "screen_6": {
        "en": "Secure the right die to the right carriage in the foundry using the hardware provided.",
        "pl": "",
    },
    "screen_7": {
        "en": "Plug in the heater and thermistor connections for the right die.",
        "pl": "",
    },
    "screen_8": {
        "en": "Close the front door.",
        "pl": "",
    },
    "screen_9": {
        "en": "Die preparation complete! Would you like to begin casting or finish the process?",
        "pl": "",
    },
}

DIE_METAL_CASTING = {
    "screen_1": {
        "en": "Ensure that [b]all ingot materials[/b] are [b]completely dry[/b] before use. "
        + "[b]Any moisture[/b] could cause a [b]steam explosion![/b] Press the Next button to continue.",
        "pl": "",
    },
    "screen_2": {
        "en": "Would you like to use recycled material with this casting?",
        "pl": "",
    },
    "screen_3": {
        "en": "What percentage of recycled material would you like to use with this casting?",
        "pl": "",
    },
    "screen_4": {
        "en": "Open the hopper on top of the front door to the foundry.",
        "pl": "",
    },
    "screen_5": {
        "en": "",
        "pl": "",
    },
    "screen_6": {
        "en": "",
        "pl": "",
    },
    "screen_7": {
        "en": "Close the hopper on top of the front door to the foundry.",
        "pl": "",
    },
    "screen_8": {
        "en": "Press the button below to begin heating the dies and the crucible.",
        "pl": "",
    },
    "screen_9": {
        "en": "Press the buttons below to home the left and right dies.",
        "pl": "",
    },
    "screen_10": {
        "en": "Press the button below to close the dies.",
        "pl": "",
    },
    "screen_11": {
        "en": "Melting in progress.",
        "pl": "",
    },
    "screen_12": {
        "en": "Melting complete.",
        "pl": "",
    },
    "screen_13": {
        "en": "Dross removal in progress.",
        "pl": "",
    },
    "screen_14": {
        "en": "Degassing in progress.",
        "pl": "",
    },
    "screen_15": {
        "en": "Dross removal and degassing complete. Press the button below to start casting process.",
        "pl": "",
    },
    "screen_16": {
        "en": "Casting complete, solidification in progress.",
        "pl": "",
    },
    "screen_17": {
        "en": "Solidification Complete. Press the button below to open the dies.",
        "pl": "",
    },
    "screen_18": {
        "en": "You may now open the door to remove the casting. CAUTION: WEAR GLOVES AND A FACE SHIELD!",
        "pl": "",
    },
    "screen_19": {
        "en": "Remove the casting using a pair of tongs and place it on a metal table or sand bed "
        + "to allow it to cool, then close the door. CAUTION: WEAR GLOVES AND A FACE SHIELD",
        "pl": "",
    },
    "screen_20": {
        "en": "Die casting complete!",
        "pl": "",
    },
}

INVESTMENT_MOLD_PREPARATION = {
    "screen_1": {
        "en": "You [b]MUST[/b] wear a face mask throughout the entire mold preparation process. "
        + "The investment powder contains [b]fine silica particles[/b] and [b]can cause "
        + "respiratory illness if inhaled[/b].",
        "pl": "",
    },
    "screen_23_1": {
        "en": "Use the provided scale to measure [b]",
        "pl": "",
    },
    "screen_2_2": {
        "en": " g[/b] of investment powder for creating a mold for the selected profile.",
        "pl": "",
    },
    "screen_3_2": {
        "en": " g [/b] of water for creating a mold for the selected profile.",
        "pl": "",
    },
    "screen_4": {
        "en": "Assemble the casting flask with the rubber base, rubber flask cover, "
        + "and pattern, and insert it in the shelf in the vacuum chamber. Then turn "
        + "the chamber horizontal and open the transparent door.",
        "pl": "",
    },
    "screen_5": {
        "en": "The next several steps [b]MUST[/b] be completed within a 10-minute time frame! "
        + "Please have the containers of measured investment powder and water ready along "
        + "with the electric mixer and mixing bowl. \n\nThe next steps will be as follows:"
        + "\n\uFEFF      \u2022 2 minutes – mixing"
        + "\n\uFEFF      \u2022 5 minutes – vacuuming"
        + "\n\uFEFF      \u2022 1 minute – pouring"
        + "\n\nThis provides extra time to ensure you can complete all of the steps within "
        + "10 minutes. Press the Next button to begin the process.",
        "pl": "",
    },
    "screen_6": {
        "en": "Pour the measured water into the mixing bowl and then pour the measured "
        + "investment powder into the mixing bowl. Mix for 2 minutes using an electric "
        + "mixer to form a smooth consistent slurry.",
        "pl": "",
    },
    "screen_7": {
        "en": "Secure the mixing bowl containing the slurry in the vacuum chamber which already "
        + "contains the flask. Hold the transparent door closed to seal the chamber and press "
        + "the button below to start the vacuum pump.",
        "pl": "",
    },
    "screen_8": {
        "en": "Slowly tilt the vacuum chamber upright so that the slurry flows from the mixing bowl "
        + "into the flask. Maintain a consistent flow until the chamber is completely upright and "
        + "the slurry has flowed into the mold.",
        "pl": "",
    },
    "screen_9": {
        "en": "Carefully open the door of the vacuum chamber and remove the flask. "
        + "Place the flask on a level table and allow it to cure undisturbed for "
        + "at least 1 hour before removing the rubber base and cover and placing "
        + "it in the furnace for burnout.",
        "pl": "",
    },
    "start_vacuuming": {
        "en": "START PUMP",
        "pl": "ZAŁĄCZ POMPĘ"
    },
}

INVESTMENT_METAL_CASTING = {
    "screen_1": {
        "en": "Check that the burnout process is finished before beginning the metal casting process!"
        + "The flask must be at the required flask temperature so that it can be transferred to "
        + "the foundry chamber for casting. \n\n[b]Additionally, ensure that all ingot materials "
        + "are completely dry before use. [u]Any moisture[/u] could cause a "
        + "[u]steam explosion![/u][/b] \n\nPress the Next button to continue.",
        "pl": "",
    },
    "screen_2": {
        "en": "Would you like to use recycled material with this casting?",
        "pl": "",
    },
    "screen_3": {
        "en": "What percentage of recycled material would you like to use with this casting?",
        "pl": "",
    },
    "screen_4": {
        "en": "Open the hopper on top of the front door to the foundry.",
        "pl": "",
    },
    "screen_5": {
        "en": "Drop metal alloy ingots of the new material one-by-one into the hopper until "
        + "the measured new material is equal to the required new material.\n\n",
        "pl": "",
    },
    "screen_6": {
        "en": "", "pl": "", },
    "screen_7": {
        "en": "Close the hopper on top of the front door to the foundry.", "pl": "",
    },
    "screen_8": {
        "en": "Press the button below to begin heating the crucible.", "pl": "",
    },
    "screen_9": {
        "en": "Open the front door.", "pl": "",
    },
    "screen_10": {
        "en": "Transfer the prepared flask from the furnace to the casting chamber.", "pl": "",
    },
    "screen_11": {
        "en": "Close the front door.", "pl": "",
    },
    "screen_12": {
        "en": "Melting in progress.", "pl": "",
    },
    "screen_13": {
        "en": "Melting complete.", "pl": "",
    },
    "screen_14": {
        "en": "Dross removal in progress.", "pl": "",
    },
    "screen_15": {
        "en": "Degassing in progress.", "pl": "",
    },
    "screen_16": {
        "en": "Dross removal and degassing complete. Press the button below to start vacuum pouring process.",
        "pl": "",
    },
    "screen_17": {
        "en": "Casting complete, solidification in progress.",
        "pl": "",
    },
    "screen_18": {
        "en": "Solidification complete. You may now open the door to remove the flask. "
        + "CAUTION: WEAR GLOVES AND A FACE SHIELD!",
        "pl": "",
    },
    "screen_19": {
        "en": "Remove the flask using the tongs and quench it in a bucket of hot water "
        + "(40 \u00B0C to 80 \u00B0C). Then close the door. CAUTION: WEAR GLOVES AND A FACE SHIELD!",
        "pl": "",
    },
    "screen_20": {
        "en": "Investment casting complete!",
        "pl": "",
    },
}

METAL_CASTING = {
    "screen_1": {
        "en": "Press the Next button to continue.",
        "pl": "",
    },
    "screen_2": {
        "en": "Would you like to use recycled material with this casting?",
        "pl": "",
    },
    "screen_3": {
        "en": "What percentage of recycled material would you like to use with this casting?",
        "pl": "",
    },
    "screen_4": {
        "en": "Open the hopper on top of the front door to the foundry.",
        "pl": "",
    },
    "screen_5": {
        "en": "Drop metal alloy ingots of the new material one-by-one into the hopper until "
        + "the measured new material is equal to the required new material.\n\n",
        "pl": "",
    },
    "screen_6": {
        "en": "", "pl": "", },
    "screen_7": {
        "en": "Close the hopper on top of the front door to the foundry.", "pl": "",
    },
    "screen_8": {
        "en": "Press the button below to begin heating the crucible.", "pl": "",
    },
    "screen_9": {
        "en": "Open the front door.", "pl": "",
    },
    "screen_10": {
        "en": "Transfer the prepared flask from the furnace to the casting chamber.", "pl": "",
    },
    "screen_11": {
        "en": "Close the front door.", "pl": "",
    },
    "screen_12": {
        "en": "Melting in progress.", "pl": "",
    },
    "screen_13": {
        "en": "Melting complete.", "pl": "",
    },
    "screen_14": {
        "en": "Dross removal in progress.", "pl": "",
    },
    "screen_15": {
        "en": "Degassing in progress.", "pl": "",
    },
    "screen_16": {
        "en": "Dross removal and degassing complete. Press the button below to start vacuum pouring process.",
        "pl": "",
    },
    "screen_17": {
        "en": "Casting complete, solidification in progress.",
        "pl": "",
    },
    "screen_18": {
        "en": "Solidification complete. You may now open the door to remove the flask. "
        + "CAUTION: WEAR GLOVES AND A FACE SHIELD!",
        "pl": "",
    },
    "screen_19": {
        "en": "Remove the flask using the tongs and quench it in a bucket of hot water "
        + "(40 \u00B0C to 80 \u00B0C). Then close the door. CAUTION: WEAR GLOVES AND A FACE SHIELD!",
        "pl": "",
    },
    "screen_20": {
        "en": "Investment casting complete!",
        "pl": "",
    },
}
SAND_MOLD_PREPARATION = {
    "screen_1": {
        "en": "You [b]MUST[/b] wear a face mask throughout the entire mold preparation process. "
        + "The green sand contains [b]fine sand particles[/b] and [b]can cause respiratory illness if inhaled[/b]."
        + "\n\nPress a button to continue or to go back.",
        "pl": "",
    },
    "screen_2": {
        "en": "Are you using new or used green sand?",
        "pl": "",
    },
    "screen_3": {
        "en": "Mix the green sand thoroughly in the bucket.",
        "pl": "",
    },
    "screen_4": {
        "en": "Compact the sand tightly in your fist and try breaking the compacted sand evenly in "
        + "two pieces. If the sand breaks clean in half and does not crumble, then it has the "
        + "proper moisture level. If the sand does not break clean in half and crumbles easily "
        + "then it is too dry. ",
        "pl": "",
    },
    "screen_5": {
        "en": "Add 50 ml of water to the bucket of used green sand.",
        "pl": "",
    },
    "screen_6": {
        "en": "Place the drag section of the flask upside down on a flat surface.",
        "pl": "",
    },
    "screen_7": {
        "en": "Place the drag section of the pattern on the flat surface within the drag section "
        + "of the flask. Ensure that the sprue is positioned in the middle towards the rear "
        + "of the flask.",
        "pl": "",
    },
    "screen_8": {
        "en": "Sprinkle the mold release powder over the pattern using the sifter.",
        "pl": "",
    },
    "screen_9": {
        "en": "Carefully add the green sand to the drag section of the flask until the pattern "
        + "is completely covered. Compact the green sand over the entire surface area of the "
        + "flask and scrape off the extra sand to create a smooth top surface.",
        "pl": "",
    },
    "screen_10": {
        "en": "Turn over the drag section of the flask containing the pattern and compacted green "
        + "sand. Insert the cope section of the flask to the drag section and secure the "
        + "four clasps.",
        "pl": "",
    },
    "screen_11": {
        "en": "Align and connect the cope section of the pattern with the drag section of the pattern.",
        "pl": "",
    },
    "screen_12": {
        "en": "Sprinkle the mold release powder over the assembled pattern using the sifter.",
        "pl": "",
    },
    "screen_13": {
        "en": "Carefully add the green sand to the assembled cope section of the flask until "
        + "the pattern is completely covered. Compact the green sand over the entire surface "
        + "area of the flask and scrape off the extra sand to create a smooth top surface and "
        + "bevel the inlet to the sprue channel.",
        "pl": "",
    },
    "screen_14": {
        "en": "Slowly release the four clasps holding the cope and drag sections of the flask "
        + "together. Carefully lift the cope away from the drag and set it aside with pattern "
        + "facing up.",
        "pl": "",
    },
    "screen_15": {
        "en": "Carefully remove the two sections of the pattern from the cope and drag sections of the flasks.",
        "pl": "",
    },
    "screen_16": {
        "en": "Insert the cope section of the flask to the drag section and secure the four clasps.",
        "pl": "",
    },
    "screen_17": {
        "en": "Mold preparation complete! Would you like to repeat the process or finish it?",
        "pl": "",
    },
    "new": {
        "en": "NEW",
        "pl": "",
    },
    "okay": {
        "en": "IT'S OKAY",
        "pl": "",
    },
    "too_dry": {
        "en": "TOO DRY",
        "pl": "",
    },
    "used": {
        "en": "USED",
        "pl": "",
    },
}

SAND_METAL_CASTING = {
    "screen_1": {
        "en": "Ensure that all ingot materials are [b]completely dry[/b] before use. "
        + "[b]Any moisture[/b] could cause a [b]steam explosion![/b] "
        + "\n\nPress a button to continue or to go back.",
        "pl": "",
    },
    "screen_2": {
        "en": "Would you like to use recycled material with this casting?",
        "pl": "",
    },
    "screen_3": {
        "en": "What percentage of recycled material would you like to use with this casting?",
        "pl": "",
    },
    "screen_4": {
        "en": "Open the hopper on top of the front door to the foundry.",
        "pl": "",
    },
    "screen_5": {
        "en": "",
        "pl": "",
    },
    "screen_6": {
        "en": "",
        "pl": "",
    },
    "screen_7": {
        "en": "Close the hopper on top of the front door to the foundry.",
        "pl": "",
    },
    "screen_8": {
        "en": "Press the button below to begin heating the crucible.",
        "pl": "",
    },
    "screen_9": {
        "en": "Open the front door.",
        "pl": "",
    },
    "screen_10": {
        "en": "Transfer the prepared flask from the furnace to the casting chamber.",
        "pl": "",
    },
    "screen_11": {
        "en": "Close the front door.",
        "pl": "",
    },
    "screen_12": {
        "en": "Melting in progress.",
        "pl": "",
    },
    "screen_13": {
        "en": "Melting complete.",
        "pl": "",
    },
    "screen_14": {
        "en": "Dross removal in progress.",
        "pl": "",
    },
    "screen_15": {
        "en": "Degassing in progress.",
        "pl": "",
    },
    "screen_16": {
        "en": "Dross removal and degassing complete. Press the button below to start pouring process.",
        "pl": "",
    },
    "screen_17": {
        "en": "Casting complete, solidification in progress.",
        "pl": "",
    },
    "screen_18": {
        "en": "Solidification complete. You may now open the door to remove the flask. "
        + "CAUTION: WEAR GLOVES AND A FACE SHIELD!",
        "pl": "",
    },
    "screen_19": {
        "en": "Remove the flask using the tongs and quench it in a bucket of hot water "
        + "(40 " + DEG_C + " to 80 " + DEG_C + "). "
        + "Then close the door. CAUTION: WEAR GLOVES AND A FACE SHIELD!",
        "pl": "",
    },
    "screen_20": {
        "en": "Sand casting complete!",
        "pl": "",
    },
}

FAULT_TITLES = {
    -1: {
        "en": "No fault code provided.",
        "pl": "Nie podano kodu błędu."
    },
    # ! Fault codes:
    ERROR_ARDUINO_USB0_INIT_CONNECTION["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_ARDUINO_USB1_INIT_CONNECTION["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_NANO_INIT_CONNECTION["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_MCP23017_INIT_CONNECTION["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_MPU9250_INIT_CONNECTION["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_SOFTWARE_ID_MISMATCH["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_MACHINE_ID_MISMATCH["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_CRUCIBLE_SENSOR_1["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_CRUCIBLE_SENSOR_2["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_DIE_LEFT_SENSOR["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_DIE_RIGHT_SENSOR["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_OPEN_DOORS["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_ARDUINO_CONTROL_RESPONSE_FAILSAFE_TRIGGER["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_ARDUINO_STEPPER_RESPONSE_FAILSAFE_TRIGGER["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_DIES["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_1["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_2["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_LEFT["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_RIGHT["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_AMBIENT["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_HUMIDITY_TOO_HIGH_AMBIENT["code"]: {
        "en": "",
        "pl": "",
    },
    #^ Faults crucible microchip
    ERROR_CRUCIBLE_DISCONNECTED["code"]: {
        "en": "Error crucible not connected",
        "pl": "",
    },
    ERROR_MICROCHIP_READING["code"]: {
        "en": "Error crucible microchip reading",
        "pl": "",
    },
    ERROR_CRUCIBLE_INCOMPATIBLE["code"]: {
        "en": "Error crucible incompatible",
        "pl": "",
    },

    # TODO: Too low temp errors
    ERROR_ARDUINO_CONTROL_READ["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_ARDUINO_STEPPER_READ["code"]: {
        "en": "",
        "pl": "",
    },
    # $ Warning codes:
    WARNING_RESIDUAL_HEAT_CRUCIBLE["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_RESIDUAL_HEAT_DIES["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_CRUCIBLE_1["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_CRUCIBLE_2["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_DIE_LEFT["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_DIE_RIGHT["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_AMBIENT["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_HUMIDITY_HIGH_AMBIENT["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_OPEN_DOORS["code"]: {
        "en": "Open doors (code: " + str(WARNING_OPEN_DOORS["code"]) + ")",
        "pl": "Otwarte drzwi urządzenia (kod: " + str(WARNING_OPEN_DOORS["code"]) + ")",
    },
    WARNING_EMERGENCY_BUTTON["code"]: {
        "en": "Emergency Button pressed",
        "pl": "",
    },
    #% Warning hardware lifespan codes:
    WARNING_LIFESPAN_CRUCIBLE["code"]: {
        "en": "Lifespan of cruicible about to end",
        "pl": "",
    },
    WARNING_LIFESPAN_SKIMMER["code"]: {
        "en": "Lifespan of skimmer about to end",
        "pl": "",
    },
    WARNING_LIFESPAN_NOZZLE["code"]: {
        "en": "Lifespan of nozzle about to end",
        "pl": "",
    },
    # > Bluetooth
    BLUETOOTH_EOF["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_TIMEOUT["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_AGENT_NOT_REGISTERED["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_AGENT_NOT_UNREGISTERED["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_DISCOVERABLE_OFF_FAILED["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_START_DISCOVERY["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_DISCOVERY_IN_PROGRESS["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_STOP_DISCOVERY["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_GET_DEVICE_LIST["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_PAIRING_ERROR["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_UNPAIR["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_CANCEL_PAIRING["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_CONNECTION_LOST["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_DISCONNECT["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_NOT_IMPLEMENTED_ERROR["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNKNOWN_ERROR["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_OTHER_ERROR["code"]: {
        "en": "",
        "pl": "",
    },
    # & PiCamera
    WARNING_PICAMERA_GENERAL["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_PICAMERA_DEPRECATED["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_PICAMERA_FALLBACK["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_PICAMERA_RESIZER_ENCODING["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_PICAMERA_ALPHA_STRIPPING["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_GENERAL["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_VALUE_ERROR["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_RUNTIME_ERROR["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_CLOSED["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_NOT_RECORDING["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_ALREADY_RECORDING["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_MMAL["code"]: {
        "en": "",
        "pl": "",
    },
    # % Miscellanous codes:
    UNKNOWN_FAULT["code"]: {
        "en": "",
        "pl": "",
    },
    UNEXPECTED_FAULT["code"]: {
        "en": "",
        "pl": "",
    },
}

FAULT_DESCRIPTIONS = {
    # ! Fault codes:
    ERROR_ARDUINO_USB0_INIT_CONNECTION["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_ARDUINO_USB1_INIT_CONNECTION["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_NANO_INIT_CONNECTION["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_MCP23017_INIT_CONNECTION["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_SOFTWARE_ID_MISMATCH["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_MACHINE_ID_MISMATCH["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_CRUCIBLE_SENSOR_1["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_CRUCIBLE_SENSOR_2["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_DIE_LEFT_SENSOR["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_DIE_RIGHT_SENSOR["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_OPEN_DOORS["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_ARDUINO_CONTROL_RESPONSE_FAILSAFE_TRIGGER["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_ARDUINO_STEPPER_RESPONSE_FAILSAFE_TRIGGER["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_DIES["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_1["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_2["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_LEFT["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_RIGHT["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_AMBIENT["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_HUMIDITY_TOO_HIGH_AMBIENT["code"]: {
        "en": "",
        "pl": "",
    },
        #^ Faults crucible microchip
    ERROR_CRUCIBLE_DISCONNECTED["code"]: {
        "en": """The crucible is not connected. In case it is installed, please be sure that the cables are well connected. \nIf the problem persist contact the support service.""",
        "pl": "",
    },
    ERROR_MICROCHIP_READING["code"]: {
        "pl": "",
        "en": """The crucible microchip has been impossible to read. Please make sure that the cable is well connected. 
        If the problem persist contact the support.""",
    },
    ERROR_CRUCIBLE_INCOMPATIBLE["code"]: {
        "en": "The crucible is incompatible or has been damaged. Please contact the support.",
        "pl": "",
    },
    # TODO: Too low temp errors
    ERROR_ARDUINO_CONTROL_READ["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_ARDUINO_STEPPER_READ["code"]: {
        "en": "",
        "pl": "",
    },
    # $ Warning codes:
    WARNING_RESIDUAL_HEAT_CRUCIBLE["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_RESIDUAL_HEAT_DIES["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_CRUCIBLE_1["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_CRUCIBLE_2["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_DIE_LEFT["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_DIE_RIGHT["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_AMBIENT["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_HUMIDITY_HIGH_AMBIENT["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_OPEN_DOORS["code"]: {
        "en": "Machine's doors are open. You have to close them, "
        + "to be able to start a process. Please check the information in STATUS "
        + "tab to see exactly which doors are opened.",
        "pl": "",
    },
    WARNING_EMERGENCY_BUTTON["code"]: {
        "en": "The Emmergency button was pressed, please reset it",
        "pl": "",
    },
        #% Warning hardware lifespan codes:
    WARNING_LIFESPAN_CRUCIBLE["code"]: {
        "en": "The lifespan of the cruicible is about to end, "
        + "to have the best results and safety in your production, "
        + "it is highly recommended to change it  as soon as possible.",
        "pl": "",
    },
    WARNING_LIFESPAN_SKIMMER["code"]: {
        "en": "The lifespan of the skimmer is about to end, "
        + "to have the best results and safety in your production, "
        + "it is highly recommended to change it as soon as possible.",
        "pl": "",
    },
    WARNING_LIFESPAN_NOZZLE["code"]: {
        "en": "The lifespan of the nozzle is about to end, "
        + "to have the best results and safety in your production, "
        + "it is highly recommended to change it as soon as possible.",
        "pl": "",
    },
    # > Bluetooth
    BLUETOOTH_EOF["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_TIMEOUT["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_AGENT_NOT_REGISTERED["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_AGENT_NOT_UNREGISTERED["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_DISCOVERABLE_OFF_FAILED["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_START_DISCOVERY["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_DISCOVERY_IN_PROGRESS["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_STOP_DISCOVERY["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_GET_DEVICE_LIST["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_PAIRING_ERROR["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_UNPAIR["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_CANCEL_PAIRING["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_CONNECTION_LOST["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_DISCONNECT["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_NOT_IMPLEMENTED_ERROR["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_UNKNOWN_ERROR["code"]: {
        "en": "",
        "pl": "",
    },
    BLUETOOTH_OTHER_ERROR["code"]: {
        "en": "",
        "pl": "",
    },
    # & PiCamera
    WARNING_PICAMERA_GENERAL["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_PICAMERA_DEPRECATED["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_PICAMERA_FALLBACK["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_PICAMERA_RESIZER_ENCODING["code"]: {
        "en": "",
        "pl": "",
    },
    WARNING_PICAMERA_ALPHA_STRIPPING["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_GENERAL["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_VALUE_ERROR["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_RUNTIME_ERROR["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_CLOSED["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_NOT_RECORDING["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_ALREADY_RECORDING["code"]: {
        "en": "",
        "pl": "",
    },
    ERROR_PICAMERA_MMAL["code"]: {
        "en": "",
        "pl": "",
    },
    # % Miscellanous codes:
    UNKNOWN_FAULT["code"]: {
        "en": "",
        "pl": "",
    },
    UNEXPECTED_FAULT["code"]: {
        "en": "",
        "pl": "",
    },
}

FAULTS = {
    # ! Fault codes:
    ERROR_ARDUINO_USB0_INIT_CONNECTION["code"]: {
        "en": "Arduino at port USB0 connection error",
        "pl": "",
    },
    ERROR_ARDUINO_USB1_INIT_CONNECTION["code"]: {
        "en": "Arduino at port USB1 connection error",
        "pl": "",
    },
    ERROR_NANO_INIT_CONNECTION["code"]: {
        "en": "NANO  connection error",
        "pl": "",
    },
    ERROR_MCP23017_INIT_CONNECTION["code"]: {
        "en": "MCP23017 initialization error",
        "pl": "",
    },
    ERROR_SOFTWARE_ID_MISMATCH["code"]: {
        "en": "Software ID mismatch error",
        "pl": "",
    },
    ERROR_MACHINE_ID_MISMATCH["code"]: {
        "en": "Machine ID mismatch error",
        "pl": "",
    },
    ERROR_CRUCIBLE_SENSOR_1["code"]: {
        "en": "Crucible temperature sensor No.1 error",
        "pl": "",
    },
    ERROR_CRUCIBLE_SENSOR_2["code"]: {
        "en": "Crucible temperature sensor No.2 error",
        "pl": "",
    },
    ERROR_DIE_LEFT_SENSOR["code"]: {
        "en": "Left die temperature sensor error",
        "pl": "",
    },
    ERROR_DIE_RIGHT_SENSOR["code"]: {
        "en": "Right die temperature sensor error",
        "pl": "",
    },
    ERROR_OPEN_DOORS["code"]: {
        "en": "Doors opened during process",
        "pl": "",
    },
    ERROR_ARDUINO_CONTROL_RESPONSE_FAILSAFE_TRIGGER["code"]: {
        "en": "Control Arduino responsiveness failsafe triggered",
        "pl": "",
    },
    ERROR_ARDUINO_STEPPER_RESPONSE_FAILSAFE_TRIGGER["code"]: {
        "en": "Stepper Arduino responsiveness failsafe triggered",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE["code"]: {
        "en": "Crucible temperature too high",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_DIES["code"]: {
        "en": "Dies temperature too high",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_1["code"]: {
        "en": "Crucible temperature sensor No.1 CJC temperature too high",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_2["code"]: {
        "en": "Crucible temperature sensor No.2 CJC temperature too high",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_LEFT["code"]: {
        "en": "Left die temperature sensor CJC temperature too high",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_RIGHT["code"]: {
        "en": "Right die temperature sensor CJC temperature too high",
        "pl": "",
    },
    ERROR_TEMPERATURE_TOO_HIGH_AMBIENT["code"]: {
        "en": "Ambient temperature too high",
        "pl": "",
    },
    ERROR_HUMIDITY_TOO_HIGH_AMBIENT["code"]: {
        "en": "Ambient humidity too high",
        "pl": "",
    },
            #^ Faults crucible microchip
    ERROR_CRUCIBLE_DISCONNECTED["code"]: {
        "en": "Crucible is not connected",
        "pl": "",
    },
    ERROR_MICROCHIP_READING["code"]: {
        "pl": "",
        "en": "Error reading the crucible microchip",
    },
    ERROR_CRUCIBLE_INCOMPATIBLE["code"]: {
        "en": "The crucible is incompatible.",
        "pl": "",
    },
    # TODO: Too low temp errors
    ERROR_ARDUINO_CONTROL_READ["code"]: {
        "en": "Control Arduino read error",
        "pl": "",
    },
    ERROR_ARDUINO_STEPPER_READ["code"]: {
        "en": "Stepper Arduino read error",
        "pl": "",
    },
    # $ Warning codes:
    WARNING_RESIDUAL_HEAT_CRUCIBLE["code"]: {
        "en": "High crucible residual heat",
        "pl": "",
    },
    WARNING_RESIDUAL_HEAT_DIES["code"]: {
        "en": "High dies residual heat",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_CRUCIBLE_1["code"]: {
        "en": "Crucible temperature sensor No.1 high CJC temperature",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_CRUCIBLE_2["code"]: {
        "en": "Crucible temperature sensor No.2 high CJC temperature",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_DIE_LEFT["code"]: {
        "en": "Left die temperature sensor high CJC temperature",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_DIE_RIGHT["code"]: {
        "en": "Right die temperature sensor high CJC temperature",
        "pl": "",
    },
    WARNING_TEMPERATURE_HIGH_AMBIENT["code"]: {
        "en": "High ambient temperature",
        "pl": "",
    },
    WARNING_HUMIDITY_HIGH_AMBIENT["code"]: {
        "en": "High ambient humidity",
        "pl": "",
    },
    WARNING_OPEN_DOORS["code"]: {
        "en": "Open doors",
        "pl": "",
    },
    WARNING_EMERGENCY_BUTTON["code"]: {
        "en": "Emergency Button pressed",
        "pl": "",
    },
        #% Warning hardware lifespan codes:
    WARNING_LIFESPAN_CRUCIBLE["code"]: {
        "en": "Lifespan of cruicible about to end",
        "pl": "",
    },
    WARNING_LIFESPAN_SKIMMER["code"]: {
        "en": "Lifespan of skimmer about to end",
        "pl": "",
    },
    WARNING_LIFESPAN_NOZZLE["code"]: {
        "en": "Lifespan of nozzle about to end",
        "pl": "",
    },
    # > Bluetooth
    BLUETOOTH_EOF["code"]: {
        "en": "Bluetooth unexpected EOF",
        "pl": "",
    },
    BLUETOOTH_TIMEOUT["code"]: {
        "en": "Bluetooth timeout",
        "pl": "",
    },
    BLUETOOTH_AGENT_NOT_REGISTERED["code"]: {
        "en": "Bluetooth agent not registered",
        "pl": "",
    },
    BLUETOOTH_AGENT_NOT_UNREGISTERED["code"]: {
        "en": "Bluetooth agent unable to unregister",
        "pl": "",
    },
    BLUETOOTH_DISCOVERABLE_OFF_FAILED["code"]: {
        "en": "Bluetooth unable to set discoverable off",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_START_DISCOVERY["code"]: {
        "en": "Bluetooth unable to start device discovery",
        "pl": "",
    },
    BLUETOOTH_DISCOVERY_IN_PROGRESS["code"]: {
        "en": "Bluetooth discovery in progress",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_STOP_DISCOVERY["code"]: {
        "en": "Bluetooth unable to stop discovery",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_GET_DEVICE_LIST["code"]: {
        "en": "Bluetooth unable to get device list",
        "pl": "",
    },
    BLUETOOTH_PAIRING_ERROR["code"]: {
        "en": "Bluetooth pairing error",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_UNPAIR["code"]: {
        "en": "Bluetooth unable to pair",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_CANCEL_PAIRING["code"]: {
        "en": "Unable to cancel Bluetooth pairing",
        "pl": "",
    },
    BLUETOOTH_CONNECTION_LOST["code"]: {
        "en": "Bluetooth device connection lost",
        "pl": "",
    },
    BLUETOOTH_UNABLE_TO_DISCONNECT["code"]: {
        "en": "Bluetooth unable to disconnect",
        "pl": "",
    },
    BLUETOOTH_NOT_IMPLEMENTED_ERROR["code"]: {
        "en": "TODO: Implement error",
        "pl": "",
    },
    BLUETOOTH_UNKNOWN_ERROR["code"]: {
        "en": "Unknown Bluetooth error",
        "pl": "",
    },
    BLUETOOTH_OTHER_ERROR["code"]: {
        "en": "Other Bluetooth error",
        "pl": "",
    },
    # & PiCamera
    WARNING_PICAMERA_GENERAL["code"]: {
        "en": "Camera general warning",
        "pl": "",
    },
    WARNING_PICAMERA_DEPRECATED["code"]: {
        "en": "Camera deprecated functionality used",
        "pl": "",
    },
    WARNING_PICAMERA_FALLBACK["code"]: {
        "en": "Camera fallback to old functionality",
        "pl": "",
    },
    WARNING_PICAMERA_RESIZER_ENCODING["code"]: {
        "en": "Camera resizer encoding",
        "pl": "",
    },
    WARNING_PICAMERA_ALPHA_STRIPPING["code"]: {
        "en": "Camera alpha stripping",
        "pl": "",
    },
    ERROR_PICAMERA_GENERAL["code"]: {
        "en": "Camera general error",
        "pl": "",
    },
    ERROR_PICAMERA_VALUE_ERROR["code"]: {
        "en": "Camera value error",
        "pl": "",
    },
    ERROR_PICAMERA_RUNTIME_ERROR["code"]: {
        "en": "Camera runtime error",
        "pl": "",
    },
    ERROR_PICAMERA_CLOSED["code"]: {
        "en": "Camera is closed",
        "pl": "",
    },
    ERROR_PICAMERA_NOT_RECORDING["code"]: {
        "en": "Camera is not recording",
        "pl": "",
    },
    ERROR_PICAMERA_ALREADY_RECORDING["code"]: {
        "en": "Camera is already recording",
        "pl": "",
    },
    ERROR_PICAMERA_MMAL["code"]: {
        "en": "Camera MMAL error",
        "pl": "",
    },
    # % Miscellanous codes:
    UNKNOWN_FAULT["code"]: {
        "en": "I'm a flying teapot!",
        "pl": "",
    },
    UNEXPECTED_FAULT["code"]: {
        "en": "Unexpected fault",
        "pl": "",
    },
}

MACHINE_STATES = {
    "state_errors": {
        "en": "errors detected!",
        "pl": "wykryto błędy!",
    },
    "state_faults": {
        "en": "warnings and errors detected!",
        "pl": "wykryto ostrzeżenia i błędy!",
    },
    "state_ok": {
        "en": "working properly.",
        "pl": "działa poprawnie.",
    },
    "state_warnings": {
        "en": "warnings detected!",
        "pl": "wykryto ostrzeżenia!",
    },
}

LANGUAGES = {
    "en": {
        "en": "English",
        "pl": "Angielski",
    },
    "pl": {
        "en": "Polish",
        "pl": "Polski",
    },
}

OTHER_STRINGS = {
    "exception_file_read": {
        "en": ": Unable to read settings file.",
        "pl": "",
    },
    "exception_file_write": {
        "en": ": Unable to write settings file.",
        "pl": "",
    },
}





RECYCLE_VIEW_DATA_LOADER = {
    "cycles_remaining": {
        "en": "cycles remaining",
        "pl": "pozostałe cykle",
    }
}
