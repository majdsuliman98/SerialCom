import os
import base64

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, padding, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from django.utils.encoding import force_bytes, force_text

from Constants import PUBLIC_KEY_FILE_OPERATOR


class Crypto_RSA:
    """RSA-based encryption for encrypting data used in machine QR code.
    This class is derived from API's and QR generation utility cryptography
    backends. The difference is that this class only implements encryption
    functionality that will be used for generating a QR code of this machine
    which will be shown to the user so he/she can add this machine through
    the mobile app.
    """

    def __init__(self):
        """Init with default backend.
        """
        self.backend = default_backend()
        self.public_key_operator = None

    def _load_public_key(self):
        """Loads public key from file.
        """
        try:
            with open(PUBLIC_KEY_FILE_OPERATOR, "rb") as public_key_file:
                public_key = serialization.load_pem_public_key(public_key_file.read(), backend=self.backend)
        # ValueErrors are risen in case of any other exceptions in order to be caught as plain encryption errors.
        except FileNotFoundError as exception:
            log(CRITICAL, "Public key file not found.", exc_info=exception)
            raise ValueError
        except ValueError as exception:
            log(CRITICAL, "Invalid public key data.", exc_info=exception)
            raise ValueError
        else:
            self.public_key_operator = public_key

    def encrypt(self, data_for_encryption):
        """Encrypts provided data.

        Args:
            data_for_encryption (string): Data for encryption

        Returns:
            string: Urlsafe B64 encoded data
        """
        if self.public_key_operator is None:
            self._load_public_key(mode)
        public_key = self.public_key_operator

        encrypted_data = public_key.encrypt(
            force_bytes(data_for_encryption),
            OAEP(mgf=MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None),
        )
        return force_text(base64.urlsafe_b64encode(encrypted_data))


class KeyExchange:
    """Key exchange feature meant for establishing secure data exchange between
    a MM3D machine and API. Based on Diffie-Hellman key exchange using
    Curve25519 as described in documentation:
    https://cryptography.io/en/latest/hazmat/primitives/asymmetric/x25519.html
    """

    def __init__(self):
        """Init with default backend.
        """
        self.backend = default_backend()

    def begin_key_exchange(self):
        """This function generates a new X25519 key and returns it for exchange with a peer.

        Returns:
            string: Serialized X25519 public key
        """
        self.private_key = X25519PrivateKey.generate()
        public_key = self.private_key.public_key()
        public_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
        )
        return self._to_text(force_bytes(public_bytes))

    def finish_key_exchange(self, piid, peer_public_key, salt):
        """Finish the key exchange process and generate the final keys (private and public).

        Args:
            piid (string): Raspberry Pi UID (used in HKDF)
            peer_public_key (string): Public key for key exchange given by peer
            salt (string): Salt used in HKDF given by peer
        """

        salt = self._to_bytes(salt)
        info = bytes(piid, "UTF-8")
        shared_key = self.private_key.exchange(
            X25519PublicKey.from_public_bytes(self._to_bytes(peer_public_key))
        )
        derived_key = HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=info, backend=self.backend).derive(
            shared_key
        )
        self.private_key = ed25519.Ed25519PrivateKey.from_private_bytes(derived_key)
        self.public_key = self.private_key.public_key()

    def sign(self, data):
        """Sign the passed data with shared ED25519 key.

        Args:
            data (string): Data to sign

        Returns:
            string: Base64 encoded signature
        """
        return self._to_text(self.private_key.sign(bytes(data, "UTF-8")))

    def verify(self, data, signature):
        """Signature verification function. Raises cryptography.exceptions.InvalidSignature in case of failure.

        Args:
            data (bytes): Data for signature verifiation
        """
        self.public_key.verify(self._to_bytes(signature), data)

    def _to_bytes(self, data):
        """Converts provided data from string to url-safe Base64 encoded bytes

        Args:
            data (string): Data for conversion

        Returns:
            bytes: Encoded and converted data
        """
        return force_bytes(base64.urlsafe_b64decode(force_bytes(data)))

    def _to_text(self, data):
        """Converts provided data from Base64 encoded bytes to string

        Args:
            data (bytes): Data for conversion

        Returns:
            string: Decoded bytes
        """
        return force_text(base64.urlsafe_b64encode(force_bytes(data)))
