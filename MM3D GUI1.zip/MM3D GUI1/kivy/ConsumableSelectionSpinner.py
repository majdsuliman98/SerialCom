from kivy.lang import Builder
from kivy.uix.spinner import Spinner, SpinnerOption
from kivy.properties import ListProperty, ObjectProperty, BooleanProperty

from SpinnerDropdown import SpinnerDropdown
from TouchRippleButton import TouchRippleButton

Builder.load_file("ConsumableSelectionSpinner.kv")


class ConsumableSelectionSpinnerOptions(SpinnerOption, TouchRippleButton):
    pass


class ConsumableSelectionSpinner(Spinner, TouchRippleButton):
    """Implements a spinner used for choosing consumables (crucibles and
    materials) or language.
    """
    values = ListProperty()
    text_autoupdate = BooleanProperty(False)
    option_cls = ObjectProperty(ConsumableSelectionSpinnerOptions)
    dropdown_cls = ObjectProperty(SpinnerDropdown)
    is_open = BooleanProperty(False)
    sync_height = BooleanProperty(False)

    def __init__(self, **kwargs):
        self._dropdown = None
        super(ConsumableSelectionSpinner, self).__init__(**kwargs)
        fbind = self.fbind
        fbind('on_release', self._toggle_dropdown)
        fbind('dropdown_cls', self._build_dropdown)
        fbind('option_cls', self._build_dropdown)
        fbind('values', self._update_dropdown)
        fbind('size', self._update_dropdown_size)
        fbind('text_autoupdate', self._update_dropdown)
        self._build_dropdown()

    def _toggle_dropdown(self, *largs):
        """Modified: blocks dropdown toggle when the dropdown is hidden
        or disabled.
        """
        if self.values and not (self.hidden or self.disabled):
            self.is_open = not self.is_open

    def on_is_open(self, instance, value):
        """Modified: fixes spinner closing itself after touch.
        """
        if value:
            self._dropdown.open(self)
        # Commenting out the else clause fixes dropdown closing itself
        # (something causes double firing of on_release event on touch)
        # else:
        #     if self._dropdown.attach_to:
        #         self._dropdown.dismiss()
