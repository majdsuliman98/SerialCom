from kivy.event import EventDispatcher
from kivy.properties import BooleanProperty, ListProperty, StringProperty
from Faults import (
    ERROR_ARDUINO_USB0_INIT_CONNECTION,
    ERROR_ARDUINO_USB1_INIT_CONNECTION,
    ERROR_CRUCIBLE_DISCONNECTED,
    ERROR_CRUCIBLE_INCOMPATIBLE,
    ERROR_MCP23017_INIT_CONNECTION,
    ERROR_MICROCHIP_READING,
    ERROR_SOFTWARE_ID_MISMATCH,
    ERROR_MACHINE_ID_MISMATCH,
    ERROR_CRUCIBLE_SENSOR_1,
    ERROR_CRUCIBLE_SENSOR_2,
    ERROR_DIE_LEFT_SENSOR,
    ERROR_DIE_RIGHT_SENSOR,
    ERROR_OPEN_DOORS,
    ERROR_ARDUINO_CONTROL_RESPONSE_FAILSAFE_TRIGGER,
    ERROR_ARDUINO_STEPPER_RESPONSE_FAILSAFE_TRIGGER,
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE,
    ERROR_TEMPERATURE_TOO_HIGH_DIES,
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_1,
    ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_2,
    ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_LEFT,
    ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_RIGHT,
    ERROR_TEMPERATURE_TOO_HIGH_AMBIENT,
    ERROR_HUMIDITY_TOO_HIGH_AMBIENT,
    ERROR_ARDUINO_CONTROL_READ,
    ERROR_ARDUINO_STEPPER_READ,
    WARNING_RESIDUAL_HEAT_CRUCIBLE,
    WARNING_RESIDUAL_HEAT_DIES,
    WARNING_TEMPERATURE_HIGH_CRUCIBLE_1,
    WARNING_TEMPERATURE_HIGH_CRUCIBLE_2,
    WARNING_TEMPERATURE_HIGH_DIE_LEFT,
    WARNING_TEMPERATURE_HIGH_DIE_RIGHT,
    WARNING_TEMPERATURE_HIGH_AMBIENT,
    WARNING_HUMIDITY_HIGH_AMBIENT,
    WARNING_OPEN_DOORS,
    WARNING_EMERGENCY_BUTTON,
    UNKNOWN_FAULT,
    UNEXPECTED_FAULT,
    MAX31856_FAULT_CJRANGE,
    MAX31856_FAULT_TCRANGE,
    MAX31856_FAULT_CJHIGH,
    MAX31856_FAULT_CJLOW,
    MAX31856_FAULT_TCHIGH,
    MAX31856_FAULT_TCLOW,
    MAX31856_FAULT_OVUV,
    MAX31856_FAULT_OPEN,
    BLUETOOTH_EOF,
    BLUETOOTH_TIMEOUT,
    BLUETOOTH_AGENT_NOT_REGISTERED,
    BLUETOOTH_AGENT_NOT_UNREGISTERED,
    BLUETOOTH_DISCOVERABLE_OFF_FAILED,
    BLUETOOTH_UNABLE_TO_START_DISCOVERY,
    BLUETOOTH_DISCOVERY_IN_PROGRESS,
    BLUETOOTH_UNABLE_TO_STOP_DISCOVERY,
    BLUETOOTH_UNABLE_TO_GET_DEVICE_LIST,
    BLUETOOTH_PAIRING_ERROR,
    BLUETOOTH_UNABLE_TO_UNPAIR,
    BLUETOOTH_UNABLE_TO_CANCEL_PAIRING,
    BLUETOOTH_CONNECTION_LOST,
    BLUETOOTH_UNABLE_TO_DISCONNECT,
    BLUETOOTH_NOT_IMPLEMENTED_ERROR,
    BLUETOOTH_UNKNOWN_ERROR,
    BLUETOOTH_OTHER_ERROR,
    WARNING_PICAMERA_GENERAL,
    WARNING_PICAMERA_DEPRECATED,
    WARNING_PICAMERA_FALLBACK,
    WARNING_PICAMERA_RESIZER_ENCODING,
    WARNING_PICAMERA_ALPHA_STRIPPING,
    ERROR_PICAMERA_GENERAL,
    ERROR_PICAMERA_VALUE_ERROR,
    ERROR_PICAMERA_RUNTIME_ERROR,
    ERROR_PICAMERA_CLOSED,
    ERROR_PICAMERA_NOT_RECORDING,
    ERROR_PICAMERA_ALREADY_RECORDING,
    ERROR_PICAMERA_MMAL,
    WARNING_LIFESPAN_CRUCIBLE,
    WARNING_LIFESPAN_SKIMMER,
    WARNING_LIFESPAN_NOZZLE
)
from Strings import MACHINE_STATES


class FaultManager(EventDispatcher):
    """An implementation of a manager that is responsible for managing
    all the warnings and errors that are defined and can be handled.
    """
    state = StringProperty('working properly.')  # Current machine state
    fault_codes = ListProperty([])  # List of currently used fault codes
    fault_states = ListProperty([])  # List of fault codes' states
    fault_clearabilities = ListProperty([])  # List of booleans indicating if fault code is clearable
    fault_process_blocking = ListProperty([])  # List of booleans indicating if fault code is meant to block a process from starting (and calling a failsafe)
    error_detected = BooleanProperty(False)  # Indicator of error detection
    warning_detected = BooleanProperty(False)  # Indicator of warning detection
    open_doors = BooleanProperty(False)  # Indicator of any doors being open (when they shouldn't)

    def __init__(self, manager, **kwargs):
        super(FaultManager, self).__init__(**kwargs)
        self.manager = manager
        self.manager.bind(lang=self.on_lang_change)

        # Init with fault codes
        self.faults = [

            # ! Fault codes:
            ERROR_ARDUINO_USB0_INIT_CONNECTION,
            ERROR_ARDUINO_USB1_INIT_CONNECTION,
            ERROR_MCP23017_INIT_CONNECTION,
            ERROR_SOFTWARE_ID_MISMATCH,
            ERROR_MACHINE_ID_MISMATCH,
            ERROR_CRUCIBLE_SENSOR_1,
            ERROR_CRUCIBLE_SENSOR_2,
            ERROR_DIE_LEFT_SENSOR,
            ERROR_DIE_RIGHT_SENSOR,
            ERROR_OPEN_DOORS,
            ERROR_ARDUINO_CONTROL_RESPONSE_FAILSAFE_TRIGGER,
            ERROR_ARDUINO_STEPPER_RESPONSE_FAILSAFE_TRIGGER,
            ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE,
            ERROR_TEMPERATURE_TOO_HIGH_DIES,
            ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_1,
            ERROR_TEMPERATURE_TOO_HIGH_CRUCIBLE_CJC_2,
            ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_LEFT,
            ERROR_TEMPERATURE_TOO_HIGH_DIE_CJC_RIGHT,
            ERROR_TEMPERATURE_TOO_HIGH_AMBIENT,
            ERROR_HUMIDITY_TOO_HIGH_AMBIENT,
            #^ Faults crucible microchip
            ERROR_CRUCIBLE_DISCONNECTED,
            ERROR_MICROCHIP_READING,
            ERROR_CRUCIBLE_INCOMPATIBLE,
            # TODO: Too low temp errors
            ERROR_ARDUINO_CONTROL_READ,
            ERROR_ARDUINO_STEPPER_READ,
            # $ Warning codes:
            WARNING_RESIDUAL_HEAT_CRUCIBLE,
            WARNING_RESIDUAL_HEAT_DIES,
            WARNING_TEMPERATURE_HIGH_CRUCIBLE_1,
            WARNING_TEMPERATURE_HIGH_CRUCIBLE_2,
            WARNING_TEMPERATURE_HIGH_DIE_LEFT,
            WARNING_TEMPERATURE_HIGH_DIE_RIGHT,
            WARNING_TEMPERATURE_HIGH_AMBIENT,
            WARNING_HUMIDITY_HIGH_AMBIENT,
            WARNING_OPEN_DOORS,
            WARNING_EMERGENCY_BUTTON,
            # % Warning hardware lifespan codes:
            WARNING_LIFESPAN_CRUCIBLE,
            WARNING_LIFESPAN_SKIMMER,
            WARNING_LIFESPAN_NOZZLE,
            # > Bluetooth
            BLUETOOTH_EOF,
            BLUETOOTH_TIMEOUT,
            BLUETOOTH_AGENT_NOT_REGISTERED,
            BLUETOOTH_AGENT_NOT_UNREGISTERED,
            BLUETOOTH_DISCOVERABLE_OFF_FAILED,
            BLUETOOTH_UNABLE_TO_START_DISCOVERY,
            BLUETOOTH_DISCOVERY_IN_PROGRESS,
            BLUETOOTH_UNABLE_TO_STOP_DISCOVERY,
            BLUETOOTH_UNABLE_TO_GET_DEVICE_LIST,
            BLUETOOTH_PAIRING_ERROR,
            BLUETOOTH_UNABLE_TO_UNPAIR,
            BLUETOOTH_UNABLE_TO_CANCEL_PAIRING,
            BLUETOOTH_CONNECTION_LOST,
            BLUETOOTH_UNABLE_TO_DISCONNECT,
            BLUETOOTH_NOT_IMPLEMENTED_ERROR,
            BLUETOOTH_UNKNOWN_ERROR,
            BLUETOOTH_OTHER_ERROR,
            # & PiCamera
            WARNING_PICAMERA_GENERAL,
            WARNING_PICAMERA_DEPRECATED,
            WARNING_PICAMERA_FALLBACK,
            WARNING_PICAMERA_RESIZER_ENCODING,
            WARNING_PICAMERA_ALPHA_STRIPPING,
            ERROR_PICAMERA_GENERAL,
            ERROR_PICAMERA_VALUE_ERROR,
            ERROR_PICAMERA_RUNTIME_ERROR,
            ERROR_PICAMERA_CLOSED,
            ERROR_PICAMERA_NOT_RECORDING,
            ERROR_PICAMERA_ALREADY_RECORDING,
            ERROR_PICAMERA_MMAL,
            # % Miscellanous codes:
            UNKNOWN_FAULT,
            UNEXPECTED_FAULT,
        ]

        # Init with MAX31856 fault codes
        self.max31856_faults = [
            MAX31856_FAULT_CJRANGE,
            MAX31856_FAULT_TCRANGE,
            MAX31856_FAULT_CJHIGH,
            MAX31856_FAULT_CJLOW,
            MAX31856_FAULT_TCHIGH,
            MAX31856_FAULT_TCLOW,
            MAX31856_FAULT_OVUV,
            MAX31856_FAULT_OPEN,
        ]

        # Initialize fault_states with False values and other properties with corresponding values from self.faults
        for fault in self.faults:
            self.fault_states.append(False)
            self.fault_codes.append(fault["code"])
            self.fault_clearabilities.append(fault["clearable"])
            self.fault_process_blocking.append(fault["block_process"])

    def late_init(self):
        """Meant to be called by ComplexControlManager's late_initialization()
        which is called by InitialLoader after all the screens are loaded.
        This way it's sure that the content below will be loaded when all
        necessary data is already loaded.
        """
        if sum(self.fault_states) > 0:
            self.manager.tpm.status_tab.on_fault_callback(None, self.fault_states)
            self.manager.tpm.status_tab.late_init()
            self.manager.tpm.add_tab("status")

    def on_fault_states(self, *args):
        """Called on fault state change. Checks what faults are present
        and updates the according variables up to current state.
        """
        error_detected = False
        warning_detected = False
        open_doors = False
        for index, code in enumerate(self.fault_codes):
            if (code == ERROR_OPEN_DOORS["code"] or code == WARNING_OPEN_DOORS["code"]) and self.fault_states[index]:
                open_doors = True
            # Errors are defined as codes below 100
            if code < 100 and self.fault_states[index]:
                error_detected = True
            # The rest are warnings. It can be modified anytime.
            elif code >= 100 and self.fault_states[index]:
                warning_detected = True

        self.open_doors = open_doors
        self.error_detected = error_detected
        self.warning_detected = warning_detected

        if self.error_detected and self.warning_detected:
            self.state = MACHINE_STATES["state_faults"][self.manager.lang]
        elif self.error_detected:
            self.state = MACHINE_STATES["state_errors"][self.manager.lang]
        elif self.warning_detected:
            self.state = MACHINE_STATES["state_warnings"][self.manager.lang]
        else:
            self.state = MACHINE_STATES["state_ok"][self.manager.lang]

    def on_lang_change(self, *args):
        """Reload state string on language change.
        """
        if self.error_detected and self.warning_detected:
            self.state = MACHINE_STATES["state_faults"][self.manager.lang]
        elif self.error_detected:
            self.state = MACHINE_STATES["state_errors"][self.manager.lang]
        elif self.warning_detected:
            self.state = MACHINE_STATES["state_warnings"][self.manager.lang]
        else:
            self.state = MACHINE_STATES["state_ok"][self.manager.lang]
