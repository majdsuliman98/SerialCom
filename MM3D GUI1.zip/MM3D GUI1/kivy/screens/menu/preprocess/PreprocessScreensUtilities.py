"""Preprocess screens' functions qualified as utulity functions
are contained in this file.
"""
import json 
from kivy.clock import Clock
from functools import partial

from Buttons import unbind_all_callbacks
from Constants import (
    OPACITY_FULL, 
    OPACITY_ZERO, 
    SCREEN_SWITCH_TIME,
    PROFILES_DATA_FILE,
    PROFILES_CUSTOM_DATA_FILE
    )


def check_for_faults(self):
    """In case of any faults being present it blocks the possiblity to start
    a process.
    """
    for index, fault in enumerate(self.manager.fm.faults):
        if self.manager.fm.fault_states[index] and self.manager.fm.fault_process_blocking[index]:
            self.next_button.disabled = True


def load_process(self, *args):
    """Loads chosen process and shows "STARTING [PROCESS] PROCESS"
    information on the screen.
    """

    def _hide_preprocess_info_layout(*args):
        """Hides preprocess info layout
        """
        self.preprocess_info_layout.opacity = OPACITY_ZERO
        self.preprocess_info_row1_column2_content_spinner.hidden = True
        self.preprocess_info_row2_column2_content_spinner.hidden = True
        self.edit_profile_button.hiden = True
        self.delete_profile_button.hiden = True
        self.profile_buttons_layout.opacity = OPACITY_ZERO

    def _next_screen_wrapper(next_screen, *args):
        """Wraps screen change into callable so it can be scheduled with Clock.

        Args:
            next_screen (string): Next (process) screen name
        """
        self.manager.current = next_screen

    unbind_all_callbacks(self.next_button)
    self.top_panel_layout.opacity = OPACITY_ZERO
    # Scheduled for next frame, layout was not hiding without it
    Clock.schedule_once(_hide_preprocess_info_layout, -1)
    # self.preprocess_info_layout.opacity = OPACITY_ZERO
    self.profile_choice_layout.opacity = OPACITY_ZERO
    self.bottom_panel_layout.opacity = OPACITY_ZERO
    self.loading_layout.opacity = OPACITY_FULL
    self.loading_percentage_label.opacity = OPACITY_ZERO
    self.loading_underbar.opacity = OPACITY_ZERO
    self.loading_bar.opacity = OPACITY_ZERO
    self.manager.ccm.PROCESS_IN_PROGRESS = True
    #self.manager.ccm.CRUCIBLE_TILTED = True

    if self.selected_process == "die_preparation":
        self.loading_label.text = "STARTING DIE PREPARATION PROCESS"
        if not self.manager.has_screen("diePreparationProcess"):
            from DiePreparationProcess import DiePreparationProcess
            self.manager.add_widget(DiePreparationProcess())
            Clock.schedule_once(partial(_next_screen_wrapper, "diePreparationProcess"), SCREEN_SWITCH_TIME)

    elif self.selected_process == "die_metal_casting":
        self.loading_label.text = "STARTING DIE METAL CASTING PROCESS"
        if not self.manager.has_screen("dieMetalCastingProcess"):
            from DieMetalCastingProcess import DieMetalCastingProcess
            self.manager.add_widget(DieMetalCastingProcess())
            Clock.schedule_once(partial(_next_screen_wrapper, "dieMetalCastingProcess"), SCREEN_SWITCH_TIME)

    elif self.selected_process == "investment_mold_preparation":
        self.loading_label.text = "STARTING INVESTMENT MOLD PREPARATION PROCESS"
        if not self.manager.has_screen("investmentMoldPreparationProcess"):
            from InvestmentMoldPreparationProcess import InvestmentMoldPreparationProcess
            self.manager.add_widget(InvestmentMoldPreparationProcess())
            Clock.schedule_once(partial(_next_screen_wrapper, "investmentMoldPreparationProcess"), SCREEN_SWITCH_TIME)

    elif self.selected_process == "investment_metal_casting":
        self.loading_label.text = "STARTING INVESTMENT METAL CASTING PROCESS"
        if not self.manager.has_screen("investmentMetalCastingProcess"):
            from InvestmentMetalCastingProcess import InvestmentMetalCastingProcess
            self.manager.add_widget(InvestmentMetalCastingProcess())
            Clock.schedule_once(partial(_next_screen_wrapper, "investmentMetalCastingProcess"), SCREEN_SWITCH_TIME)

    elif self.selected_process == "sand_mold_preparation":
        self.loading_label.text = "STARTING SAND MOLD PREPARATION PROCESS"
        if not self.manager.has_screen("sandMoldPreparationProcess"):
            from SandMoldPreparationProcess import SandMoldPreparationProcess
            self.manager.add_widget(SandMoldPreparationProcess())
            Clock.schedule_once(partial(_next_screen_wrapper, "sandMoldPreparationProcess"), SCREEN_SWITCH_TIME)

    elif self.selected_process == "sand_metal_casting":
        self.loading_label.text = "STARTING SAND CASTING PROCESS"
        if not self.manager.has_screen("sandMetalCastingProcess"):
            from SandMetalCastingProcess import SandMetalCastingProcess
            self.manager.add_widget(SandMetalCastingProcess())
            Clock.schedule_once(partial(_next_screen_wrapper, "sandMetalCastingProcess"), SCREEN_SWITCH_TIME)

    elif self.selected_process == "metal_casting":
        self.loading_label.text = "STARTING METAL CASTING PROCESS"
        if not self.manager.has_screen("MetalCastingProcess"):
            from MetalCastingProcess import MetalCastingProcess
            self.manager.add_widget(MetalCastingProcess())
            Clock.schedule_once(partial(_next_screen_wrapper, "MetalCastingProcess"), SCREEN_SWITCH_TIME)
        else:
            Clock.schedule_once(partial(_next_screen_wrapper, "MetalCastingProcess"), SCREEN_SWITCH_TIME)


def refresh_spinner_values(self, *args):
    loaded_files = []
    loaded_files_custom = []
    self.filenames = []
    self.volumes = []
    self.dim_x = []
    self.dim_y = []
    self.dim_z = []
    self.sizes = []
    self.modDates = []
    self.filename = ""
    with open(PROFILES_DATA_FILE, "r") as profiles:
        loaded_files = [line.strip() for line in profiles]
    
    
    with open(PROFILES_CUSTOM_DATA_FILE, "r+") as file:
        loaded = json.load(file)


    for p in loaded:
        info = p+';'+'-'+';'+'-'+';'+str(loaded[p]["volume"])+';'+'-'+';'+'-'+';'+'-'
        loaded_files.append(info)

    for loadedFile in loaded_files:
        data = loadedFile.split(";")
        if data[0][-4:] == ".stl": self.filenames.append(data[0][:-4])
        else: self.filenames.append(data[0])
        self.sizes.append(data[1])
        self.modDates.append(data[2])
        self.volumes.append(data[3])
        self.dim_x.append(data[4])
        self.dim_y.append(data[5])
        self.dim_z.append(data[6])
        
    try:
        self.filename = self.filenames[0]
    except:
        self.filename="No Data"

    self.profile_choice_spinner.values = self.filenames

