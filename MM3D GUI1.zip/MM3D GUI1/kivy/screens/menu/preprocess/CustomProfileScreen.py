"""Holds functions that are used on the "Profile Selection Screen".
"""
import os
import re
import datetime
import json 

from stl import mesh
from subprocess import Popen
from threading import Thread
from kivy.clock import Clock
from kivy.logger import Logger

from Buttons import bind_callback, unbind_all_callbacks
from Constants import OPACITY_ZERO, OPACITY_FULL, PROFILES_DIR, PROFILES_DATA_DIR, PROFILES_DATA_FILE, FULL_CRUCIBLE_CAP,PROFILES_CUSTOM_DATA_FILE
from Strings import CM3,OTHER_STRINGS
from Images import ICON_MENU_CUSTOM_PROFILE

def custom_profile_screen(self):
    """Sets up the "Custom Profile" screen.
    """

    def _next_screen(*args):
        try:
            if float(self.volumeinput_text.text)>float(FULL_CRUCIBLE_CAP):
                #!It has to open a Popup and clean the input text box
                Logger.debug("The profile exceed the capacity of the crucible")
                self.manager.pop.show_popup(1)
                self.volumeinput_text.text=""
            elif float(self.volumeinput_text.text)<1:
                Logger.debug("Invalid Volume")
                self.manager.pop.show_popup(4)
                self.volumeinput_text.text=""
            elif self.manager.ccm.NAME_PROFILE=="" and self.manager.ccm.NAME_PROFILE:
                Logger.debug("entro.")
                self.manager.pop.show_popup(2)
            elif self.nameinput_text.text == "" or self.nameinput_text.text == None:
                Logger.debug("Name is empty.")
                self.manager.pop.show_popup(2)
            elif self.nameinput_text.text == None and float(self.volumeinput_text.text)>float(FULL_CRUCIBLE_CAP):
                Logger.debug("No info.")
                self.manager.pop.show_popup(5)
            elif self.nameinput_text.text in self.filenames:
                Logger.debug("Name already exist, use diferent")
                self.manager.pop.show_popup(6)

            else:
                #*Everything went well with the capacity
                self.manager.ccm.REQUIRED_MATERIAL=float(self.volumeinput_text.text)
                self.manager.ccm.NAME_PROFILE=self.nameinput_text.text
                #it has to save the profile on the file and check if if exists, if so, add 1

                try:
                    with open(PROFILES_CUSTOM_DATA_FILE, "r+") as file:
                        loaded = json.load(file)
                    info = loaded[self.manager.ccm.NAME_PROFILE]
                    # i=2
                    # new_name=self.manager.ccm.NAME_PROFILE+'_'+str(i)
                    # self.manager.ccm.NAME_PROFILE=new_name
                    # Logger.debug("New name: "+self.manager.ccm.NAME_PROFILE)
                    # loaded[self.manager.ccm.NAME_PROFILE]={"volume":self.volumeinput_text.text}
                    # with open(PROFILES_CUSTOM_DATA_FILE, "w+") as file:
                    #     json.dump(loaded, file)
                    # self.nameinput_text.text=self.manager.ccm.NAME_PROFILE
                    # if self.nameinput_text.text in self.filenames:
                    Logger.debug("Name already exist, use diferent")
                    self.manager.pop.show_popup(6)

                except KeyError:    
                    Logger.debug("Saving the original given name, volume is valid.")
                    loaded[self.nameinput_text.text]={"volume":self.volumeinput_text.text}
                    with open(PROFILES_CUSTOM_DATA_FILE, "w+") as file:
                        json.dump(loaded, file)
                    self.custom_profile_layout.opacity = OPACITY_ZERO
                    self.load_process()
                except IOError:
                
                    Logger.exception(OTHER_STRINGS["exception_file_read"][self.lang])


        except:
            #!It has to open a Popup and clean the input text box
            if self.nameinput_text.text == "" :
                Logger.debug("CustomProfileScreen: EVERYTHING IS WRONG.")
                self.manager.pop.show_popup(5)
                self.nameinput_text.text=""
                self.volumeinput_text.text=""
            else:
                Logger.debug("Invalid Volume")
                self.manager.pop.show_popup(4)
                self.volumeinput_text.text=""
                
    self.refresh_spinner_values()
    self.nameinput_text.disabled = False
    self.volumeinput_text.disabled = False
    self.volumeinput_text.text=""
    self.nameinput_text.text=""

    self.manager.ccm.REQUIRED_MATERIAL=0
    self.manager.ccm.NAME_PROFILE=""
    self.volumeinput_text.hint_text = "Insert Volume in " + CM3
    self.nameinput_text.hint_text = "Insert Name"
    self.custom_image.source =ICON_MENU_CUSTOM_PROFILE
    self.custom_image.color= self.manager.COLOR_ICON
    self.top_panel_layout.opacity = OPACITY_FULL
    self.bottom_panel_layout.opacity = OPACITY_FULL
    self.bluetooth_spinner.anim_delay = -1
    self.bluetooth_sync_layout.opacity = OPACITY_ZERO
    self.loading_layout.opacity = OPACITY_ZERO
    self.profile_choice_layout.opacity = OPACITY_ZERO
    self.preprocess_info_layout.opacity = OPACITY_ZERO
    self.custom_profile_layout.opacity = OPACITY_FULL
    self.preprocess_info_row1_column2_content_spinner.hidden = True
    self.preprocess_info_row2_column2_content_spinner.hidden = True
    self.profile_choice_spinner.disabled = True
    self.next_button.disabled = False
    self.back_button.disabled = True
    self.back_button_label.opacity = OPACITY_ZERO

    unbind_all_callbacks(self.next_button)
    unbind_all_callbacks(self.back_button)
    unbind_all_callbacks(self.back_a_button)
    unbind_all_callbacks(self.home_button)

    bind_callback(self.back_button, self.go_back_to_process_selection)
    bind_callback(self.back_a_button, self.go_back_to_process_selection)
    bind_callback(self.home_button, self.go_back_to_home)
    bind_callback(self.next_button, _next_screen)




