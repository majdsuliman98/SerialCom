"""Contains functions related to the Consumable Selection Screen
(screen dialog shown just before process, where user can choose
which material, crucible, etc., he/she wants to use).
"""

from Buttons import bind_callback, unbind_all_callbacks
from Constants import OPACITY_FULL, OPACITY_OFF, OPACITY_ZERO
from Strings import CM3


def bluetooth_data_sync_screen(self):
    """A screen which displays an information that data is being
    synced through Bluetooth.
    """
    self.bluetooth_spinner.opacity = OPACITY_ZERO
    self.bluetooth_spinner_text.opacity = OPACITY_ZERO
    self.bluetooth_spinner.anim_delay = -1

    self.profile_choice_layout.opacity = OPACITY_ZERO
    self.profile_choice_spinner.hidden = True
    self.bluetooth_sync_layout.opacity = OPACITY_FULL

    unbind_all_callbacks(self.back_button)
    unbind_all_callbacks(self.next_button)
    self.next_button.disabled = True

    self.bluetooth_data_sync_screen_callback()

    bind_callback(self.next_button, self.consumables_info_selection_screen)
    if (
        self.manager.get_screen("main").current_screen == "die_preparation"
        or self.manager.get_screen("main").current_screen == "sand_mold_preparation"
    ):
        bind_callback(self.back_button, self.go_back_to_process_selection)
    else:
        bind_callback(self.back_button, self.go_back_to_profile_selection)


def material_selected(self, spinner):
    """Called when a casting material is selected in a spinner.

    Args:
        spinner (ConsumableSelectionSpinner): Reference to spinner that called this callback
    """
    index = spinner.values.index(spinner.text)
    self.manager.dm.DATA_MATERIAL_CASTING_SELECTED = self.manager.dm.DATA_MATERIAL_CASTING_MERGED[index]
    self.preprocess_info_row1_column3_content_label.text = str(self.manager.dm.DATA_MATERIAL_CASTING_SELECTED[2]) + CM3
    # Enable nozzle option (degassing) for Aluminium only
    if "Aluminium" not in self.manager.dm.DATA_MATERIAL_CASTING_SELECTED[0]:
        self.preprocess_info_row3_column1_image.opacity = OPACITY_OFF
        self.preprocess_info_row3_column1_content_label.opacity = OPACITY_OFF
        self.preprocess_info_row3_column2_label.opacity = OPACITY_OFF
        self.preprocess_info_row3_column2_content_label.opacity = OPACITY_OFF
        self.manager.ccm.DEGASSING = False
    else:
        self.preprocess_info_row3_column1_image.opacity = OPACITY_FULL
        self.preprocess_info_row3_column1_content_label.opacity = OPACITY_FULL
        self.preprocess_info_row3_column2_label.opacity = OPACITY_FULL
        self.preprocess_info_row3_column2_content_label.opacity = OPACITY_FULL
        self.manager.ccm.DEGASSING = True
    self.check_before_start()


def crucible_selected(self, spinner):
    """Called when a crucible is selected in a spinner.

    Args:
        spinner (ConsumableSelectionSpinner): Reference to spinner that called this callback
    """
    index = spinner.values.index(spinner.text)
    self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED = self.manager.dm.DATA_HARDWARE_CRUCIBLES[index]
    self.preprocess_info_row2_column3_content_label.text = str(self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED[1])
    self.preprocess_info_row2_column4_content_label.text = self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED[2] + " h"
    self.check_before_start()


def consumables_info_selection_screen(self):
    """Sets up the Consumables Selection screen view depending
    on the selected process.
    """
    self.preprocess_info_layout.opacity = OPACITY_FULL
    self.preprocess_info_row1_column2_content_spinner.disabled = False
    self.preprocess_info_row2_column2_content_spinner.disabled = False
    # self.profile_choice_layout.opacity = OPACITY_ZERO
    self.bluetooth_sync_layout.opacity = OPACITY_ZERO

    self.profile_choice_spinner.hidden = True
    self.check_before_start()

    unbind_all_callbacks(self.back_button)
    unbind_all_callbacks(self.next_button)
    bind_callback(self.back_button, self.show_profiles)

    if self.selected_process == "die_preparation":
        # Proceed without showing the preprocess screen
        self.load_process()

    elif self.selected_process == "die_metal_casting":
        # material, crucible, (nozzle), dies

        # ----------------------------------- ROW 1 ---------------------------------- #

        self.preprocess_info_row1_layout.opacity = OPACITY_FULL
        self.preprocess_info_row1_column1_content_label.text = "Material"
        self.preprocess_info_row1_column2_label.text = "Casting material"
        # Check how many casting materials available are there
        # TODO: No materials available case
        if len(self.manager.dm.DATA_MATERIAL_CASTING) > 1:
            # self.preprocess_info_row1_column2_content_spinner.opacity = OPACITY_FULL
            self.preprocess_info_row1_column2_content_label.opacity = OPACITY_ZERO
            self.preprocess_info_row1_column2_content_spinner.disabled = False
        else:
            # self.preprocess_info_row1_column2_content_spinner.opacity = OPACITY_ZERO
            self.preprocess_info_row1_column2_content_label.opacity = OPACITY_FULL
            self.preprocess_info_row1_column2_content_spinner.hidden = True

        # Add materials' names to spinner's values
        materials = []
        for index, material in enumerate(self.manager.dm.DATA_MATERIAL_CASTING_MERGED):
            materials.append(material[0])
        self.preprocess_info_row1_column2_content_spinner.values = materials

        if len(self.manager.dm.DATA_MATERIAL_CASTING_MERGED) > 0:
            self.preprocess_info_row1_column2_content_spinner.text = self.manager.dm.DATA_MATERIAL_CASTING_SELECTED[0]

        self.preprocess_info_row1_column3_label.text = "Available amount"
        self.preprocess_info_row1_column3_content_label.text = (
            str(self.manager.dm.DATA_MATERIAL_CASTING_SELECTED[2]) + CM3
        )
        self.preprocess_info_row1_column4_label.text = "Required amount"

        # ----------------------------------- ROW 2 ---------------------------------- #

        self.preprocess_info_row2_divider.opacity = OPACITY_FULL
        self.preprocess_info_row2_layout.opacity = OPACITY_FULL
        self.preprocess_info_row2_column1_content_label.text = "Crucible"
        # self.preprocess_info_row1_column2_label.text = ""
        if len(self.manager.dm.DATA_HARDWARE_CRUCIBLES) > 1:
            self.preprocess_info_row2_column2_label.text = "Crucible"  # choose between crucibles (somehow?)
            self.preprocess_info_row2_column2_content_spinner.opacity = OPACITY_FULL
            self.preprocess_info_row2_column2_content_label.opacity = OPACITY_ZERO
        else:
            # Display the only available crucible's associated material
            self.preprocess_info_row2_column2_label.text = "Associated material"
            self.preprocess_info_row2_column2_content_spinner.opacity = OPACITY_ZERO
            self.preprocess_info_row2_column2_content_label.opacity = OPACITY_FULL

        crucibles = []
        for index, crucible in enumerate(self.manager.dm.DATA_HARDWARE_CRUCIBLES):
            crucibles.append("Crucible No." + str(index + 1))
        self.preprocess_info_row2_column2_content_spinner.values = crucibles

        if len(self.manager.dm.DATA_HARDWARE_CRUCIBLES) == 1:
            self.preprocess_info_row2_column2_content_spinner.text = "Default crucible"
        elif len(self.manager.dm.DATA_HARDWARE_CRUCIBLES) > 1:
            self.preprocess_info_row2_column2_content_spinner.text = (
                self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED[0] + " No.1"
            )
        self.preprocess_info_row2_column3_label.text = "Associated material"
        self.preprocess_info_row2_column3_content_label.text = str(self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED[1])
        self.preprocess_info_row2_column4_label.text = "Lifespan left"
        self.preprocess_info_row2_column4_content_label.text = (
            self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED[2] + " h"
        )

        # ----------------------------------- ROW 3 ---------------------------------- #

        self.preprocess_info_row3_layout.opacity = OPACITY_FULL
        self.preprocess_info_row3_column1_content_label.text = "Nozzle"

        if len(self.manager.dm.DATA_HARDWARE_NOZZLES) > 1:
            # self.preprocess_info_row3_column2_content_spinner.opacity = OPACITY_FULL
            self.preprocess_info_row3_column2_content_label.opacity = OPACITY_ZERO
        else:
            # self.preprocess_info_row3_column2_content_spinner.opacity = OPACITY_ZERO
            self.preprocess_info_row3_column2_content_label.opacity = OPACITY_FULL

        self.preprocess_info_row3_column2_label.text = "Lifespan left"
        self.preprocess_info_row3_column2_content_label.text = (
            self.manager.dm.DATA_HARDWARE_NOZZLE_SELECTED[1] + " h"
        )  # this and others like that
        # will not update live because they are not assigned to properties
        # TODO: live update binding
        self.preprocess_info_row3_divider.opacity = OPACITY_FULL
        self.preprocess_info_row4_layout.opacity = OPACITY_ZERO
        bind_callback(self.next_button, self.load_process)

        # ----------------------------------- ROW 4 ---------------------------------- #

        self.preprocess_info_row4_layout.opacity = OPACITY_FULL
        self.preprocess_info_row4_column1_content_label.text = "Dies"
        self.preprocess_info_row4_column2_label.text = "Assigned profile"
        self.preprocess_info_row4_column2_content_label.text = self.manager.dm.DATA_HARDWARE_DIES_SELECTED[1]
        self.preprocess_info_row4_column3_label.text = "Lifespan left"
        self.preprocess_info_row4_column3_content_label.text = self.manager.dm.DATA_HARDWARE_DIES_SELECTED[2] + " h"
        bind_callback(self.next_button, self.load_process)

    elif self.selected_process == "investment_mold_preparation":
        self.preprocess_info_row1_column1_content_label.text = "Material"
        self.preprocess_info_row1_column2_label.text = "Mold material"

        if len(self.manager.dm.DATA_MATERIAL_MOLD) > 1:
            self.next_button.disabled = False  # remove after adding checking for investment powder amount
            # self.preprocess_info_row1_column2_content_spinner.opacity = OPACITY_FULL
            self.preprocess_info_row1_column2_content_label.opacity = OPACITY_ZERO
            self.preprocess_info_row1_column2_content_spinner.disabled = False

            # Add materials' names to spinner's values
            materials = []
            for index, material in enumerate(self.manager.dm.DATA_MATERIAL_MOLD_MERGED):
                materials.append(material[0])
            self.preprocess_info_row1_column2_content_spinner.values = materials

            if len(self.manager.dm.DATA_MATERIAL_MOLD_MERGED) > 0:
                self.preprocess_info_row1_column2_content_spinner.text = self.manager.dm.DATA_MATERIAL_MOLD_SELECTED[0]

        elif len(self.manager.dm.DATA_MATERIAL_MOLD) == 1:
            self.next_button.disabled = False  # remove after adding checking for investment powder amount
            # self.preprocess_info_row1_column2_content_spinner.opacity = OPACITY_ZERO
            self.preprocess_info_row1_column2_content_label.opacity = OPACITY_FULL
            self.preprocess_info_row1_column2_content_spinner.hidden = True
            self.preprocess_info_row1_column2_content_label.text = self.manager.dm.DATA_MATERIAL_MOLD_SELECTED[0]

        else:
            # TODO: no materials information popup
            pass

        self.preprocess_info_row1_column3_label.text = "Available amount"
        self.preprocess_info_row1_column3_content_label.text = (
            str(self.manager.dm.DATA_MATERIAL_MOLD_SELECTED[2]) + CM3
        )
        self.preprocess_info_row1_column4_label.text = "Required amount"

        self.preprocess_info_row1_layout.opacity = OPACITY_FULL
        self.preprocess_info_row2_layout.opacity = OPACITY_ZERO
        self.preprocess_info_row2_divider.opacity = OPACITY_ZERO
        self.preprocess_info_row3_layout.opacity = OPACITY_ZERO
        self.preprocess_info_row3_divider.opacity = OPACITY_ZERO
        self.preprocess_info_row4_layout.opacity = OPACITY_ZERO
        bind_callback(self.next_button, self.load_process)

    elif self.selected_process == "investment_metal_casting":
        # ----------------------------------- ROW 1 ---------------------------------- #

        self.preprocess_info_row1_layout.opacity = OPACITY_FULL
        self.preprocess_info_row1_column1_content_label.text = "Material"
        self.preprocess_info_row1_column2_label.text = "Casting material"
        # Check how many casting materials available are there
        # TODO: No materials available case
        if len(self.manager.dm.DATA_MATERIAL_CASTING) > 1:
            # self.preprocess_info_row1_column2_content_spinner.opacity = OPACITY_FULL
            self.preprocess_info_row1_column2_content_label.opacity = OPACITY_ZERO
            self.preprocess_info_row1_column2_content_spinner.disabled = False
        else:
            # self.preprocess_info_row1_column2_content_spinner.opacity = OPACITY_ZERO
            self.preprocess_info_row1_column2_content_label.opacity = OPACITY_FULL
            self.preprocess_info_row1_column2_content_spinner.hidden = True

        # Add materials' names to spinner's values
        materials = []
        for index, material in enumerate(self.manager.dm.DATA_MATERIAL_CASTING_MERGED):
            materials.append(material[0])
        self.preprocess_info_row1_column2_content_spinner.values = materials

        if len(self.manager.dm.DATA_MATERIAL_CASTING_MERGED) > 0:
            self.preprocess_info_row1_column2_content_spinner.text = self.manager.dm.DATA_MATERIAL_CASTING_SELECTED[0]

        self.preprocess_info_row1_column3_label.text = "Available amount"
        self.preprocess_info_row1_column3_content_label.text = (
            str(self.manager.dm.DATA_MATERIAL_CASTING_SELECTED[2]) + CM3
        )
        self.preprocess_info_row1_column4_label.text = "Required amount"

        # ----------------------------------- ROW 2 ---------------------------------- #

        self.preprocess_info_row2_divider.opacity = OPACITY_FULL
        self.preprocess_info_row2_layout.opacity = OPACITY_FULL
        self.preprocess_info_row2_column1_content_label.text = "Crucible"
        # self.preprocess_info_row1_column2_label.text = ""
        if len(self.manager.dm.DATA_HARDWARE_CRUCIBLES) > 1:
            self.preprocess_info_row2_column2_label.text = "Crucible"  # choose between crucibles (somehow?)
            self.preprocess_info_row2_column2_content_spinner.opacity = OPACITY_FULL
            self.preprocess_info_row2_column2_content_label.opacity = OPACITY_ZERO
        else:
            # Display the only available crucible's associated material
            self.preprocess_info_row2_column2_label.text = "Associated material"
            self.preprocess_info_row2_column2_content_spinner.opacity = OPACITY_ZERO
            self.preprocess_info_row2_column2_content_label.opacity = OPACITY_FULL

        crucibles = []
        for index, crucible in enumerate(self.manager.dm.DATA_HARDWARE_CRUCIBLES):
            crucibles.append("Crucible No." + str(index + 1))
        self.preprocess_info_row2_column2_content_spinner.values = crucibles

        if len(self.manager.dm.DATA_HARDWARE_CRUCIBLES) == 1:
            self.preprocess_info_row2_column2_content_spinner.text = "Default crucible"
        elif len(self.manager.dm.DATA_HARDWARE_CRUCIBLES) > 1:
            self.preprocess_info_row2_column2_content_spinner.text = (
                self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED[0] + " No.1"
            )
        self.preprocess_info_row2_column3_label.text = "Associated material"
        self.preprocess_info_row2_column3_content_label.text = str(self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED[1])
        self.preprocess_info_row2_column4_label.text = "Lifespan left"
        self.preprocess_info_row2_column4_content_label.text = (
            self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED[2] + " h"
        )

        # ----------------------------------- ROW 3 ---------------------------------- #

        self.preprocess_info_row3_layout.opacity = OPACITY_FULL
        self.preprocess_info_row3_column1_content_label.text = "Nozzle"

        if len(self.manager.dm.DATA_HARDWARE_NOZZLES) > 1:
            # self.preprocess_info_row3_column2_content_spinner.opacity = OPACITY_FULL
            self.preprocess_info_row3_column2_content_label.opacity = OPACITY_ZERO
        else:
            # self.preprocess_info_row3_column2_content_spinner.opacity = OPACITY_ZERO
            self.preprocess_info_row3_column2_content_label.opacity = OPACITY_FULL

        self.preprocess_info_row3_column2_label.text = "Lifespan left"
        self.preprocess_info_row3_column2_content_label.text = (
            self.manager.dm.DATA_HARDWARE_NOZZLE_SELECTED[1] + " h"
        )  # this and others like that
        # will not update live because they are not assigned to properties
        # TODO: live update binding
        self.preprocess_info_row3_divider.opacity = OPACITY_FULL
        self.preprocess_info_row4_layout.opacity = OPACITY_ZERO
        bind_callback(self.next_button, self.load_process)

    elif self.selected_process == "sand_mold_preparation":
        # Proceed without showing the preprocess screen
        self.load_process()

    elif self.selected_process == "sand_metal_casting":
        # ----------------------------------- ROW 1 ---------------------------------- #

        self.preprocess_info_row1_layout.opacity = OPACITY_FULL
        self.preprocess_info_row1_column1_content_label.text = "Material"
        self.preprocess_info_row1_column2_label.text = "Casting material"
        # Check how many casting materials available are there
        # TODO: No materials available case
        if len(self.manager.dm.DATA_MATERIAL_CASTING) > 1:
            # self.preprocess_info_row1_column2_content_spinner.opacity = OPACITY_FULL
            self.preprocess_info_row1_column2_content_spinner.disalbed = False
            self.preprocess_info_row1_column2_content_label.opacity = OPACITY_ZERO
        else:
            # self.preprocess_info_row1_column2_content_spinner.opacity = OPACITY_ZERO
            self.preprocess_info_row1_column2_content_spinner.hidden = True
            self.preprocess_info_row1_column2_content_label.opacity = OPACITY_FULL

        # Add materials' names to spinner's values
        materials = []
        for index, material in enumerate(self.manager.dm.DATA_MATERIAL_CASTING_MERGED):
            materials.append(material[0])
        self.preprocess_info_row1_column2_content_spinner.values = materials

        if len(self.manager.dm.DATA_MATERIAL_CASTING_MERGED) > 0:
            self.preprocess_info_row1_column2_content_spinner.text = self.manager.dm.DATA_MATERIAL_CASTING_SELECTED[0]

        self.preprocess_info_row1_column3_label.text = "Available amount"
        self.preprocess_info_row1_column3_content_label.text = (
            str(self.manager.dm.DATA_MATERIAL_CASTING_SELECTED[2]) + CM3
        )
        self.preprocess_info_row1_column4_label.text = "Required amount"

        # ----------------------------------- ROW 2 ---------------------------------- #

        self.preprocess_info_row2_divider.opacity = OPACITY_FULL
        self.preprocess_info_row2_layout.opacity = OPACITY_FULL
        self.preprocess_info_row2_column1_content_label.text = "Crucible"
        # self.preprocess_info_row1_column2_label.text = ""
        if len(self.manager.dm.DATA_HARDWARE_CRUCIBLES) > 1:
            self.preprocess_info_row2_column2_label.text = "Crucible"  # choose between crucibles (somehow?)
            self.preprocess_info_row2_column2_content_spinner.opacity = OPACITY_FULL
            self.preprocess_info_row2_column2_content_label.opacity = OPACITY_ZERO
        else:
            # Display the only available crucible's associated material
            self.preprocess_info_row2_column2_label.text = "Associated material"
            self.preprocess_info_row2_column2_content_spinner.opacity = OPACITY_ZERO
            self.preprocess_info_row2_column2_content_label.opacity = OPACITY_FULL

        crucibles = []
        for index, crucible in enumerate(self.manager.dm.DATA_HARDWARE_CRUCIBLES):
            crucibles.append("Crucible No." + str(index + 1))
        self.preprocess_info_row2_column2_content_spinner.values = crucibles

        if len(self.manager.dm.DATA_HARDWARE_CRUCIBLES) == 1:
            self.preprocess_info_row2_column2_content_spinner.text = "Default crucible"
        elif len(self.manager.dm.DATA_HARDWARE_CRUCIBLES) > 1:
            self.preprocess_info_row2_column2_content_spinner.text = (
                self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED[0] + " No.1"
            )
        self.preprocess_info_row2_column3_label.text = "Associated material"
        self.preprocess_info_row2_column3_content_label.text = str(self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED[1])
        self.preprocess_info_row2_column4_label.text = "Lifespan left"
        self.preprocess_info_row2_column4_content_label.text = (
            self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED[2] + " h"
        )

        # ----------------------------------- ROW 3 ---------------------------------- #

        self.preprocess_info_row3_layout.opacity = OPACITY_FULL
        self.preprocess_info_row3_column1_content_label.text = "Nozzle"

        if len(self.manager.dm.DATA_HARDWARE_NOZZLES) > 1:
            # self.preprocess_info_row3_column2_content_spinner.opacity = OPACITY_FULL
            self.preprocess_info_row3_column2_content_label.opacity = OPACITY_ZERO
        else:
            # self.preprocess_info_row3_column2_content_spinner.opacity = OPACITY_ZERO
            self.preprocess_info_row3_column2_content_label.opacity = OPACITY_FULL

        self.preprocess_info_row3_column2_label.text = "Lifespan left"
        self.preprocess_info_row3_column2_content_label.text = (
            self.manager.dm.DATA_HARDWARE_NOZZLE_SELECTED[1] + " h"
        )  # this and others like that
        # will not update live because they are not assigned to properties
        # TODO: live update binding
        self.preprocess_info_row3_divider.opacity = OPACITY_FULL
        self.preprocess_info_row4_layout.opacity = OPACITY_ZERO
        bind_callback(self.next_button, self.load_process)


def go_back_to_profile_selection(self):
    """Performs appropriate rebindings, enables next button,
    calls show_profiles() when going back to the Profile Selection
    Screen.
    """
    unbind_all_callbacks(self.back_button)
    unbind_all_callbacks(self.next_button)
    bind_callback(self.next_button, self.bluetooth_data_sync_screen)
    self.next_button.disabled = False
    self.profile_is_selected = True
    self.show_profiles()


def check_before_start(self):
    """Checks if the selected amount of material is enough to start a process,
    if the crucible's associated material matches the selected one and
    if the lifetime is enough to proceed with a process etc.
    """
    start = False

    if int(self.manager.dm.DATA_MATERIAL_CASTING_SELECTED[2]) >= self.manager.ccm.REQUIRED_MATERIAL:
        start = True
    else:
        start = False

    if self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED[1] == "None":
        start = True
    elif self.manager.dm.DATA_HARDWARE_CRUCIBLE_SELECTED[1] == self.manager.dm.DATA_MATERIAL_CASTING_SELECTED[0]:
        start = True
    else:
        start = False

    if start:
        self.next_button.disabled = False
    else:
        self.next_button.disabled = True
