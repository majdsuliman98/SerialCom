"""Holds functions that are used on the "Profile Selection Screen".
"""
import os
import datetime
import json 
from stl import mesh
from subprocess import Popen
from threading import Thread
from kivy.clock import Clock
from kivy.logger import Logger

from Buttons import bind_callback, unbind_all_callbacks, calculate_button_inner_layout
from Constants import (
    OPACITY_ZERO,
    OPACITY_FULL, 
    PROFILES_DIR, 
    PROFILES_DATA_DIR, 
    PROFILES_DATA_FILE,
    PROFILES_CUSTOM_DATA_FILE)
from Strings import CM3
from Images import ICON_MENU_CUSTOM_PROFILE


def show_profiles(self):
    """Sets up the "Profile Selection" screen.
    """
    self.bluetooth_spinner.anim_delay = -1
    self.bluetooth_sync_layout.opacity = OPACITY_ZERO
    self.loading_layout.opacity = OPACITY_ZERO
    self.top_panel_layout.opacity = OPACITY_FULL
    self.profile_choice_layout.opacity = OPACITY_FULL
    self.custom_profile_layout.opacity = OPACITY_ZERO
    self.profile_buttons_layout.opacity = OPACITY_FULL

    self.nameinput_text.disabled = True
    self.volumeinput_text.disabled = True

    self.preprocess_info_layout.opacity = OPACITY_ZERO
    self.preprocess_info_row1_column2_content_spinner.hidden = True
    self.preprocess_info_row2_column2_content_spinner.hidden = True

    self.bottom_panel_layout.opacity = OPACITY_FULL
    self.profile_choice_spinner.disabled = False

    self.next_button.hidden = True
    self.back_button.hidden = True

    self.back_button.disabled = True
    self.edit_profile_button.disabled = True

    self.back_button_label.opacity = OPACITY_ZERO
    self.back_button_background.opacity = OPACITY_ZERO

    self.next_button_label.text = "SELECT"

    unbind_all_callbacks(self.next_button)
    unbind_all_callbacks(self.back_button)
    unbind_all_callbacks(self.back_a_button)
    unbind_all_callbacks(self.home_button)

    bind_callback(self.back_button, self.go_back_to_process_selection)
    bind_callback(self.back_a_button, self.go_back_to_process_selection)
    bind_callback(self.home_button, self.go_back_to_home)

    self.profile_selection_screen()


def profile_selection_screen(self):
    """Sets up the "Profile Selection" screen. Loads profiles and populates
    the dropdown spinner.
    """
    self.refresh_spinner_values()

    self.profile_choice_spinner.values = self.filenames

    if self.profile_choice_spinner.text in self.filenames:
        self.next_button.disabled = False
        self.edit_profile_button.disabled = False
        self.delete_profile_button.disabled = False
        self.profile_buttons_layout.opacity = OPACITY_FULL
        bind_callback(self.next_button, self.load_process)
        bind_callback(self.delete_profile_button,self.confirmation_delete_profile)
        bind_callback(self.edit_profile_button,self.confirmation_edit_profile)

def read_profiles(self):
    """Reads the STL files (locally and from USB if present) using a thread
    and parses them (creates previews, saves data to profiles' data file).
    """
    def _read_profiles():
        """A complex function which takes care of reading the profiles (stl
        files), updating them from the USB stick or a memory card, generating
        previews and saving their data to file.
        """
        stl_files = []
        loaded_files = []
        profiles_data_file_copy = []
        progress = 0
        number_of_files = 0
        # Check if there is a USB stick or card reader present, mount it, sync data and unmount it so it can be removed
        if os.path.exists("/dev/sda1"):
            self.loading_label.text = "SYNCING PROFILE DATA FROM THE USB"
            Logger.debug("File loading: Syncing files from USB started.")
            # Mount the filesystem on /dev/sda1 into the folder /mnt

            Popen("sudo mount /dev/sda1 /mnt", shell=True)

            # Perform file syncing operation
            Popen(
                "sudo rsync -au --include './' --include '*.stl' --exclude '*' --delete-excluded /mnt/ /home/pi/MM3D/stl",
                shell=True,
            )
            # Unmount filesystem
            Popen("sudo umount /dev/sda1", shell=True)
            Logger.debug("File loading: Syncing files from USB finished.")

        else:
            self.loading_label.text = "READING PROFILE DATA, PLEASE WAIT"
            Logger.debug("File loading: No USB media available, skipping the syncing process.")
            
        # self.loading = Clock.schedule_interval(self.loadingThread, 0.5)

        # Check if profiles.txt exist and if not, create it
        try:
            file = open(PROFILES_DATA_FILE, "r")

        except IOError:
            file = open(PROFILES_DATA_FILE, "w")
        finally:
            file.close()


        # Read the contents of the profiles file
        with open(PROFILES_DATA_FILE, "r") as profiles:
            loaded_files = [line.strip() for line in profiles]

        # Read the contents of the profiles file and create a copy of it for later use
        with open(PROFILES_DATA_FILE, "r") as profiles:
            profiles_data_file_copy = profiles.readlines()

        # Count the number of valid stl files inside the profiles directory and append them to list for later use
        for file in os.listdir(PROFILES_DIR):
            if file.endswith(".stl"):
                try:
                    # test_mesh = mesh.Mesh.from_file(PROFILES_DIR + "/" + file)
                    _ = mesh.Mesh.from_file(PROFILES_DIR + "/" + file)
                except Exception:
                    Logger.error(
                        "File loading: File {} is not a proper STL file! It was removed from local directory!".format(
                            file
                        )
                    )
                    os.remove(PROFILES_DIR + "/" + file)
                else:
                    number_of_files += 1
                    stl_files.append(file)

        # Browse through the preloaded list remove the records and previews of stl files that no longer exist
        for loadedFile in loaded_files:
            filename = loadedFile.split(";")[0]
            deleteRecord = True

            for index, stl in enumerate(stl_files):
                if filename == stl:
                    Logger.debug("File loading: Already existing record found for {}.".format(filename))
                    deleteRecord = False
                    break

            if deleteRecord:
                Logger.debug("File loading: Record without STL present found. Deleting {}.".format(filename))
                stlPath = PROFILES_DATA_DIR + "/" + str("%s" % filename)
                with open(PROFILES_DATA_FILE, "r") as profiles:
                    profiles_data_file_copy = profiles.readlines()

                try:
                    os.remove(stlPath[:-4] + ".png")
                except Exception as exception:
                    Logger.exception(
                        "File loading: Preview deletion failed (was the file removed previously?) " + str(exception)
                    )

                with open(PROFILES_DATA_FILE, "r") as profiles:
                    loaded_files = [line.strip() for line in profiles]

                profiles_data_file_copy.pop(loaded_files.index(loadedFile))
                with open(PROFILES_DATA_FILE, "w") as profiles:
                    profiles.writelines(profiles_data_file_copy)

        # Read the contents of the profiles file again, after deletion of the nonexisting files' ones
        with open(PROFILES_DATA_FILE, "r") as profiles:
            loaded_files = [line.strip() for line in profiles]

        # If the profiles file does not contain any profiles and there are no stls then show a popup which notifies user
        if loaded_files == [] and number_of_files == 0:
            Logger.debug("File loading: No STL files found!")
            # TODO: handling this exception

        # If the profiles file is completely empty but there are stl files available
        elif loaded_files == [] and number_of_files > 0:
            Logger.debug("File loading: No preloaded STLs found but there are STL files available for processing.")
            for file in stl_files:
                Logger.debug("File loading: Adding file {}.".format(file))
                stlPath = PROFILES_DIR + "/" + str("%s" % file)
                stlDataPath = PROFILES_DATA_DIR + "/" + str("%s" % file)
                Popen("stl-thumb " + stlPath + " " + stlDataPath[:-4] + ".png", shell=True)
                stl = mesh.Mesh.from_file(stlPath)
                volume, cog, inertia = stl.get_mass_properties()
                # minx, maxx, miny, maxy, minz, maxz = self.find_min_max(stl)
                minx, maxx, miny, maxy, minz, maxz = stl.x.min(),stl.x.max(),stl.y.min(),stl.y.max(),stl.z.min(),stl.z.max()
                x = abs(minx) + abs(maxx)
                y = abs(miny) + abs(maxy)
                z = abs(minz) + abs(maxz)
                volume *= 0.001
                with open(PROFILES_DATA_FILE, "a") as profiles:
                    # TODO: convert into JSON format
                    profiles.write(
                        str(file)
                        + ";"
                        + str(os.path.getsize(stlPath))
                        + ";"
                        + str(os.path.getmtime(stlPath))
                        + ";"
                        + str("%.2f" % volume)
                        + ";"
                        + str("%.2f" % x)
                        + ";"
                        + str("%.2f" % y)
                        + ";"
                        + str("%.2f" % z)
                        + "\n"
                    )
                progress += 1
                self.loading_bar.size[0] = str(round(512 * progress / number_of_files, 0)) + "dp"
                self.loading_percentage_label.text = str(round(100 * progress / number_of_files, 0)) + "%"

        # If the profiles file has some data inside - adds files, updates the old ones and deletes the non existing ones
        else:
            Logger.debug("File loading: Preloaded STLs found.")
            # Firstly, browse through the stl files in their directory and add the new records or update the old ones
            for file in stl_files:
                step = 0
                for loadedFile in loaded_files:
                    step += 1
                    filename = loadedFile.split(";")[0]
                    # If there is file's name in the loaded_files, check if it was updated by the user
                    if file == filename:
                        Logger.debug("File loading: Found matching preloaded record for file {}.".format(file))
                        data = loadedFile.split(";")
                        stlPath = PROFILES_DIR + "/" + str("%s" % file)
                        stlDataPath = PROFILES_DATA_DIR + "/" + str("%s" % file)
                        # If size or modification date is different, update the file info in the profiles file
                        if not data[1] == str(os.path.getsize(stlPath)) or not data[2] == str(
                            os.path.getmtime(stlPath)
                        ):
                            Logger.debug("File loading: Updating the file record.")
                            Popen("stl-thumb " + stlPath + " " + stlDataPath[:-4] + ".png", shell=True)
                            stl = mesh.Mesh.from_file(stlPath)
                            volume, cog, inertia = stl.get_mass_properties()
                            # minx, maxx, miny, maxy, minz, maxz = self.find_min_max(stl)
                            minx, maxx, miny, maxy, minz, maxz =stl.x.min(),stl.x.max(),stl.y.min(),stl.y.max(),stl.z.min(),stl.z.max()
                            x = abs(minx) + abs(maxx)
                            y = abs(miny) + abs(maxy)
                            z = abs(minz) + abs(maxz)
                            volume *= 0.001
                            profiles_data_file_copy[loaded_files.index(loadedFile)] = []
                            profiles_data_file_copy[loaded_files.index(loadedFile)] = (
                                str(file)
                                + ";"
                                + str(os.path.getsize(stlPath))
                                + ";"
                                + str(os.path.getmtime(stlPath))
                                + ";"
                                + str("%.2f" % volume)
                                + ";"
                                + str("%.2f" % x)
                                + ";"
                                + str("%.2f" % y)
                                + ";"
                                + str("%.2f" % z)
                                + "\n"
                            )
                            with open(PROFILES_DATA_FILE, "w") as profiles:
                                profiles.writelines(profiles_data_file_copy)

                        # If there is a matching record, check if there is a preview for that file (just in case)
                        elif not os.path.exists(stlDataPath[:-4] + ".png"):
                            Logger.debug(
                                "File loading: Preview file for {} file not found. Regenerating preview.".format(file)
                            )
                            Popen("stl-thumb " + stlPath + " " + stlDataPath[:-4] + ".png", shell=True)

                        # If the file has been found finish the current search (break for loop)
                        break

                    else:
                        # If there is no file with this name on list (reached the end of the list) then add it
                        if step == len(loaded_files):
                            Logger.debug("File loading: Matching record for file {} not found! Adding!".format(file))
                            with open(PROFILES_DATA_FILE, "r") as profiles:
                                profiles_data_file_copy = profiles.readlines()

                            stlPath = PROFILES_DIR + "/" + str("%s" % file)
                            stlDataPath = PROFILES_DATA_DIR + "/" + str("%s" % file)
                            Popen("stl-thumb " + stlPath + " " + stlDataPath[:-4] + ".png", shell=True)
                            stl = mesh.Mesh.from_file(stlPath)
                            volume, cog, inertia = stl.get_mass_properties()
                            # minx, maxx, miny, maxy, minz, maxz = self.find_min_max(stl)
                            minx, maxx, miny, maxy, minz, maxz =stl.x.min(),stl.x.max(),stl.y.min(),stl.y.max(),stl.z.min(),stl.z.max()
                            x = abs(minx) + abs(maxx)
                            y = abs(miny) + abs(maxy)
                            z = abs(minz) + abs(maxz)
                            volume *= 0.001
                            with open(PROFILES_DATA_FILE, "a") as profiles:
                                # TODO: convert into JSON format
                                profiles.write(
                                    str(file)
                                    + ";"
                                    + str(os.path.getsize(stlPath))
                                    + ";"
                                    + str(os.path.getmtime(stlPath))
                                    + ";"
                                    + str("%.2f" % volume)
                                    + ";"
                                    + str("%.2f" % x)
                                    + ";"
                                    + str("%.2f" % y)
                                    + ";"
                                    + str("%.2f" % z)
                                    + "\n"
                                )
                progress += 1
                self.loading_bar.size[0] = str(round(512 * progress / number_of_files, 0)) + "dp"
                self.loading_percentage_label.text = str(round(100 * progress / number_of_files, 0)) + "%"
        Clock.schedule_once(self.show_profiles, 0.5)
    # Run the thread
    Thread(target=_read_profiles).start()


def profile_selected(self):
    """Called at the moment a profile is selected from the dropdown list.
    """
    # if self.next_button.disabled is True:
    if self.profile_is_selected is False:
        self.profile_is_selected = True
        
        self.next_button.disabled = False
        self.edit_profile_button.disabled = False
        self.delete_profile_button.disabled = False

        self.profile_preview_image.color = [1, 1, 1, 1]
        bind_callback(self.next_button, self.load_process)
        bind_callback(self.delete_profile_button,self.confirmation_delete_profile)
        bind_callback(self.edit_profile_button,self.confirmation_edit_profile)

    self.filename = self.profile_choice_spinner.text
    index = self.filenames.index(str(self.filename))


    self.manager.ccm.REQUIRED_WATER = 0
    volume = float(self.volumes[index])
    # self.manager.ccm.REQUIRED_MATERIAL = volume * (100 - self.manager.ccm.PERCENTAGE_RECYCLED) * 0.01
    self.manager.ccm.REQUIRED_MATERIAL = round(volume)
    self.manager.ccm.REQUIRED_RECYCLED = volume * self.manager.ccm.PERCENTAGE_RECYCLED * 0.01
    self.manager.ccm.NAME_PROFILE = self.filename
    if self.dim_x[index]=='-':
        self.profile_preview_image.source = ICON_MENU_CUSTOM_PROFILE
        self.profile_preview_image.color = self.manager.COLOR_ICON
        self.custom = True
    else:
        self.profile_preview_image.source = PROFILES_DATA_DIR + "/" + "%s" % self.filename+ ".png"
        self.profile_preview_image.color = [1, 1, 1, 1]
        self.custom = False

    self.profile_name_label.text = self.filename
    self.profile_volume_label.text = str(round(float(self.volumes[index]))) + CM3  # " cm\u00b3"

    self.check_for_faults()

def confirmation_delete_profile(self):
    self.current_screen = "delete_profile"
    self.manager.tpm.add_tab('confirmation')

def confirmation_edit_profile(self):
    self.current_screen = "edit_profile"
    self.manager.tpm.add_tab('confirmation')

def edit_profile(self):
    Logger.debug("editing profile")
    unbind_all_callbacks(self.delete_profile_button)
    unbind_all_callbacks(self.edit_profile_button)
    self.delete_profile_button.disabled = True 
    self.edit_profile_button.disabled = True
    self.edit_profile_screen()


def delete_profile(self):
    index = self.filenames.index(str(self.filename))
    if self.dim_x[index] == '-':
        try:
            with open(PROFILES_CUSTOM_DATA_FILE, "r+") as file:
                loaded = json.load(file)

            del loaded[self.filename]
            
            with open(PROFILES_CUSTOM_DATA_FILE, "w+") as file:
                json.dump(loaded, file)
        except:
            pass
    else:
        with open(PROFILES_DATA_FILE, "r") as profiles:
            loaded_files = [line.strip() for line in profiles]
        i=0
        for loadedFile in loaded_files:
            data = loadedFile.split(";")
            if data[0][:-4] == self.filename:
                print(str(i)+"got it ")
                break
            else:
                pass
            i+=1
            print(data[0])
        loaded_files.pop(i)
        with open(PROFILES_DATA_FILE, "w+") as profiles:
            for load_file in loaded_files:
                profiles.writelines(load_file+"\n")

        stlPath = PROFILES_DIR  + "/" + str("%s" % self.filename)+".stl"
        os.remove(stlPath)
        Logger.debug(f"{self.filename} stl file deleted")
        stlPath = PROFILES_DATA_DIR + "/" + str("%s" % self.filename+".png")
        os.remove(stlPath)
        Logger.debug(f"{self.filename} png file deleted")

    self.refresh_spinner_values()

    self.profile_choice_spinner.values = self.filenames
    self.profile_choice_spinner.text = self.filenames[0]

def go_back_to_profile_selection(self):
    """Takes user back to process selection screen.
    """
    def layout_update(*args):
        """Wraps layout update settings into callable function.
        """
        self.profile_choice_layout.opacity = OPACITY_ZERO
        self.profile_choice_spinner.hidden = True

        self.edit_profile_button.hiden = True
        self.delete_profile_button.hiden = True
        self.profile_buttons_layout.opacity = OPACITY_ZERO

    Clock.schedule_once(layout_update, -1)  # "Force" the hiding of the choice layout
    unbind_all_callbacks(self.next_button)
    unbind_all_callbacks(self.back_button)
    unbind_all_callbacks(self.delete_profile_button)
    unbind_all_callbacks(self.edit_profile_button)
    self.show_profiles()

def go_back_to_process_selection(self):
    """Takes user back to process selection screen.
    """
    def layout_update(*args):
        """Wraps layout update settings into callable function.
        """
        self.profile_choice_layout.opacity = OPACITY_ZERO
        self.profile_choice_spinner.hidden = True
        self.edit_profile_button.hiden = True
        self.delete_profile_button.hiden = True
        self.profile_buttons_layout.opacity = OPACITY_ZERO

    Clock.schedule_once(layout_update, -1)  # "Force" the hiding of the choice layout
    unbind_all_callbacks(self.next_button)
    unbind_all_callbacks(self.back_button)
    unbind_all_callbacks(self.delete_profile_button)
    unbind_all_callbacks(self.edit_profile_button)
    self.manager.get_screen("main").current_screen = "add_profile"
    self.manager.current = "main"

def go_back_to_home(self):
    """Takes user back to process selection screen.
    """
    def layout_update(*args):
        """Wraps layout update settings into callable function.
        """
        self.profile_choice_layout.opacity = OPACITY_ZERO
        self.profile_choice_spinner.hidden = True
        self.edit_profile_button.hiden = True
        self.delete_profile_button.hiden = True
        self.profile_buttons_layout.opacity = OPACITY_ZERO

    Clock.schedule_once(layout_update, -1)  # "Force" the hiding of the choice layout
    unbind_all_callbacks(self.next_button)
    unbind_all_callbacks(self.back_button)
    unbind_all_callbacks(self.delete_profile_button)
    unbind_all_callbacks(self.edit_profile_button)
    self.manager.get_screen("main").current_screen = "home"
    self.manager.current = "main"

