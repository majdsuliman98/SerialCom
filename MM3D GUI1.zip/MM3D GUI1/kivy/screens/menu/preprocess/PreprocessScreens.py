from threading import Thread
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.logger import Logger
from kivy.uix.screenmanager import Screen
from kivy.uix.popup import Popup 
from kivy.uix.label import Label
from kivy.properties import ObjectProperty
from Exceptions import NoBluetoothConnection, DataRefreshTimeout

from CustomProfileScreen import  custom_profile_screen

from EditProfileScreen import (
    edit_profile_screen,
    edit_profile_stl,
    edit_profile_custom
)

from ProfileSelectionScreen import (
    profile_selection_screen,
    read_profiles,
    show_profiles,
    profile_selected,
    go_back_to_process_selection,
    go_back_to_home,
    delete_profile,
    edit_profile,
    confirmation_delete_profile,
    confirmation_edit_profile,
    go_back_to_profile_selection
)
from ConsumableSelectionScreen import (
    bluetooth_data_sync_screen,
    consumables_info_selection_screen,
    material_selected,
    crucible_selected,
    check_before_start,
    go_back_to_profile_selection,
)
from PreprocessScreensUtilities import (
    load_process, 
    check_for_faults,
    refresh_spinner_values,
)

from Buttons import ( 
    calculate_nav_buttons, 
    calculate_button_inner_layout, 
)
from Constants import OPACITY_FULL, OPACITY_ZERO

from Images import (
    ICON_BOTTOM_PANEL_AL,
    ICON_BOTTOM_PANEL_ZA,
    ICON_BOTTOM_PANEL_NULL
)
from IconControlManager import(
    icon_material_manager,
    icon_crucible_manager,
    icon_temperature_manager
)

Builder.load_file("screens/menu/preprocess/PreprocessScreens.kv")


class PreprocessScreens(Screen):
    """Implementation of a set of screens that are shown to the user
    before any of the processes start. It includes a screen where user
    can choose the profile for casting, Bluetooth syncing screen and
    a screen where the user can choose between the available consumables
    he wants to use for the process.
    """
    top_panel_layout = ObjectProperty(None)
    back_button_background = ObjectProperty(None)
    back_button_label = ObjectProperty(None)
    back_button = ObjectProperty(None)
    next_button_background = ObjectProperty(None)
    next_button_label = ObjectProperty(None)
    next_button = ObjectProperty(None)

    edit_profile_button = ObjectProperty(None)
    delete_profile_button = ObjectProperty(None)
    profile_buttons_layout = ObjectProperty(None)
    custom_image = ObjectProperty(None)


    loading_layout = ObjectProperty(None)
    loading_percentage_label = ObjectProperty(None)
    loading_underbar = ObjectProperty(None)
    loading_bar = ObjectProperty(None)
    loading_label = ObjectProperty(None)

    profile_choice_layout = ObjectProperty(None)
    profile_choice_spinner = ObjectProperty(None)
    profile_preview_image = ObjectProperty(None)
    profile_dimensions_label = ObjectProperty(None)
    profile_volume_label = ObjectProperty(None)
    profile_name_label = ObjectProperty(None)
    #profile_size_label = ObjectProperty(None)
    #profile_date_label = ObjectProperty(None)

    preprocess_info_layout = ObjectProperty(None)
    preprocess_info_row1_layout = ObjectProperty(None)
    preprocess_info_row1_column1_image = ObjectProperty(None)
    preprocess_info_row1_column1_content_label = ObjectProperty(None)
    preprocess_info_row1_column2_label = ObjectProperty(None)
    preprocess_info_row1_column2_content_spinner = ObjectProperty(None)
    preprocess_info_row1_column2_content_label = ObjectProperty(None)
    preprocess_info_row1_column3_label = ObjectProperty(None)
    preprocess_info_row1_column3_content_label = ObjectProperty(None)
    preprocess_info_row1_column4_label = ObjectProperty(None)
    preprocess_info_row1_column4_content_label = ObjectProperty(None)
    preprocess_info_row1_divider = ObjectProperty(None)

    preprocess_info_row2_layout = ObjectProperty(None)
    preprocess_info_row2_column1_image = ObjectProperty(None)
    preprocess_info_row2_column1_content_label = ObjectProperty(None)
    preprocess_info_row2_column2_label = ObjectProperty(None)
    preprocess_info_row2_column2_content_spinner = ObjectProperty(None)
    preprocess_info_row2_column2_content_label = ObjectProperty(None)
    preprocess_info_row2_column3_label = ObjectProperty(None)
    preprocess_info_row2_column3_content_label = ObjectProperty(None)
    preprocess_info_row2_column4_label = ObjectProperty(None)
    preprocess_info_row2_column4_content_label = ObjectProperty(None)
    preprocess_info_row2_divider = ObjectProperty(None)

    preprocess_info_row3_layout = ObjectProperty(None)
    preprocess_info_row3_column1_image = ObjectProperty(None)
    preprocess_info_row3_column1_content_label = ObjectProperty(None)
    preprocess_info_row3_column2_label = ObjectProperty(None)
    # preprocess_info_row3_column2_content_spinner = ObjectProperty(None)
    preprocess_info_row3_column2_content_label = ObjectProperty(None)
    preprocess_info_row3_column3_label = ObjectProperty(None)
    preprocess_info_row3_column3_content_label = ObjectProperty(None)
    preprocess_info_row3_column4_label = ObjectProperty(None)
    preprocess_info_row3_column4_content_label = ObjectProperty(None)
    preprocess_info_row3_divider = ObjectProperty(None)

    preprocess_info_row4_layout = ObjectProperty(None)
    preprocess_info_row4_column1_image = ObjectProperty(None)
    preprocess_info_row4_column1_content_label = ObjectProperty(None)
    preprocess_info_row4_column2_label = ObjectProperty(None)
    preprocess_info_row4_column2_content_label = ObjectProperty(None)
    preprocess_info_row4_column3_label = ObjectProperty(None)
    preprocess_info_row4_column3_content_label = ObjectProperty(None)
    preprocess_info_row4_column4_label = ObjectProperty(None)
    preprocess_info_row4_column4_content_label = ObjectProperty(None)

    bluetooth_sync_layout = ObjectProperty(None)
    bluetooth_spinner = ObjectProperty(None)
    bluetooth_spinner_text = ObjectProperty(None)
    bluetooth_screen_text = ObjectProperty(None)

    bottom_panel_layout = ObjectProperty(None)
    custom_profile_layout = ObjectProperty(None)
    
    nameinput_text = ObjectProperty(None)
    volumeinput_text = ObjectProperty(None)
    button_layout_2 = ObjectProperty(None)

    bottom_material_icon = ObjectProperty(None)
    bottom_crucible_icon = ObjectProperty(None)
    bottom_temperature_icon = ObjectProperty(None)

    PopUp = ObjectProperty(None)

    def __init__(self, manager, **kwargs):
        super(PreprocessScreens, self).__init__(**kwargs)
        self.profile_is_selected = False
        # self.next_button.disabled = True
        self.next_button.hidden = True
        # self.back_button.disabled = True
        self.back_button.hidden = True
        self.edit_profile_button.disabled = True
        self.edit_profile_button.hiden = True

        self.delete_profile_button.disabled = True
        self.delete_profile_button.hiden = True

        manager.ccm.bind(MATERIAL=self.icon_material_callback)
        manager.ccm.bind(CRUCIBLE_MICROCHIP_EN=self.icon_crucible_callback)
        manager.ccm.bind(CRUCIBLE_TILTED=self.icon_crucible_callback)
        manager.ccm.bind(TEMP_CONTROL=self.icon_temperature_callback)
        manager.ccm.bind(CRUCIBLE_MICROCHIP_EN=self.icon_temperature_callback)

        self.icon_material_callback()
        self.icon_crucible_callback()
        self.icon_temperature_callback()
    
        manager.fm.bind(error_detected=self.error_detected_callback)
        manager.fm.bind(warning_detected=self.warning_detected_callback)
        manager.bcm.bind(bluetooth_status=self.bluetooth_data_sync_screen_callback)

        calculate_nav_buttons(
            self.back_button_label,
            self.back_button_background,
            self.next_button_label,
            self.next_button_background
            )
            #callbacks
    def icon_material_callback(self, *args):
        self.icon_material_manager(self.bottom_material_icon)

    def icon_crucible_callback(self, *args):
        self.icon_crucible_manager(self.bottom_crucible_icon)

    def icon_temperature_callback(self, *args):
        self.icon_temperature_manager(self.bottom_temperature_icon)
        # --------------------------------- IconControl -------------------------------- #
    # ---------------------------- IconControlManager.py ---------------------------- #
    def icon_material_manager(self, icon):
        icon_material_manager(self, icon)

    def icon_crucible_manager(self, icon):
        icon_crucible_manager(self, icon)

    def icon_temperature_manager(self, icon):
        icon_temperature_manager(self, icon)
    # ----------------------------- PROFILE SELECTION ---------------------------- #
    # ------------------------- ProfileSelectionScreen.py ------------------------ #

    def profile_selection_screen(self):
        profile_selection_screen(self)

    def read_profiles(self):
        read_profiles(self)

    def show_profiles(self, *args):
        show_profiles(self)

    def profile_selected(self, *args):
        profile_selected(self)

    def go_back_to_process_selection(self, *args):
        go_back_to_process_selection(self)

    def confirmation_delete_profile(self, *args):
        confirmation_delete_profile(self)

    def go_back_to_profile_selection(self, *args):
        go_back_to_profile_selection(self)

    def confirmation_edit_profile(self, *args):
        confirmation_edit_profile(self)

    def delete_profile(self, *args):
        delete_profile(self)

    def edit_profile(self, *args):
        edit_profile(self)

    # ----------------------------- CUSTOM PROFILE ---------------------------- #
    # ------------------------- CustomProfileScreen.py ------------------------ #
    def custom_profile_screen(self):
        custom_profile_screen(self)


 
    # ----------------------------- EDIT PROFILE ---------------------------- #
    # ------------------------- EditProfileScreen.py ------------------------ #
    def edit_profile_screen(self):
        edit_profile_screen(self)

    def edit_profile_custom(self):
        edit_profile_custom(self)

    def edit_profile_stl(self):
        edit_profile_stl(self)


    # --------------------------- CONSUMABLES SELECTION -------------------------- #
    # ----------------------- ConsumableSelectionScreen.py ----------------------- #
    def bluetooth_data_sync_screen(self, *args):
        bluetooth_data_sync_screen(self)

    def consumables_info_selection_screen(self, *args):
        consumables_info_selection_screen(self)

    def material_selected(self, *args):
        material_selected(self, *args)

    def crucible_selected(self, *args):
        crucible_selected(self, *args)

    def go_back_to_profile_selection(self, *args):
        go_back_to_profile_selection(self)

    def go_back_to_home(self, *args):
        go_back_to_home(self)

    # --------------------------------- UTILITIES -------------------------------- #
    # ----------------------- PreprocessScreensUtilities.py ---------------------- #

    def load_process(self, *args):
        load_process(self)

    def check_for_faults(self, *args):
        check_for_faults(self)

    def check_before_start(self, *args):
        check_before_start(self)
        
    def refresh_spinner_values(self, *args):
        refresh_spinner_values(self)

    # --------------------------------- CALLBACKS -------------------------------- #

    def on_pre_enter(self):
        """Defines what happens just before this screen is entered into.
        """
        self.selected_process = self.manager.ccm.selected_process
        self.preprocess_info_layout.opacity = OPACITY_ZERO
        self.preprocess_info_row1_column2_content_spinner.hidden = True
        self.preprocess_info_row2_column2_content_spinner.hidden = True
        if self.selected_process == "die_preparation" or self.selected_process == "sand_mold_preparation":
            # Skip the consumable selection
            self.bluetooth_data_sync_screen()
        else:
            self.bluetooth_screen_text.opacity = OPACITY_ZERO
            self.bluetooth_sync_layout.opacity = OPACITY_ZERO
            self.profile_choice_layout.opacity = OPACITY_ZERO
            self.top_panel_layout.opacity = OPACITY_ZERO
            self.loading_layout.opacity = OPACITY_FULL
            self.bottom_panel_layout.opacity = OPACITY_ZERO
            self.custom_profile_layout.opacity = OPACITY_ZERO
            self.profile_buttons_layout.opacity = OPACITY_ZERO

        if self.manager.get_screen("main").current_screen == "custom_profile":
            self.custom_profile_screen()
        else:
             self.read_profiles()
        self.selected_process ="metal_casting"



    def bluetooth_data_sync_screen_callback(self, *args):
        """Takes care of reacting to Bluetooth status changes.

        Raises:
            DataRefreshTimeout: In case event is not set until set timeout
            this exception is risen and signals app to start reading locally
            stored data only.
        """

        # TODO: Move strings defined below to the Strings.py file

        if self.manager.current == "preprocess":
            if self.manager.bcm.bluetooth_status == "disabled":
                self.bluetooth_spinner.opacity = 0
                self.bluetooth_spinner_text.opacity = 0
                self.bluetooth_spinner.anim_delay = -1

                self.bluetooth_screen_text.opacity = 1
                self.bluetooth_screen_text.text = (
                    "Bluetooth is disabled. This is not an expected behavior.\n"
                    + "Please try to restart the machine but if that doesn't help "
                    + "then please do contact support in order to resolve this issue."
                )

            elif self.manager.bcm.bluetooth_status == "enabled":
                self.bluetooth_spinner.opacity = 0
                self.bluetooth_spinner_text.opacity = 0
                self.bluetooth_spinner.anim_delay = -1

                self.bluetooth_screen_text.opacity = 1
                self.bluetooth_screen_text.text = (
                    "Please connect your M1 Foundry with your phone using Bluetooth first. "
                    + "After it is done the data synchronization process will begin automatically."
                )

            elif self.manager.bcm.bluetooth_status == "connected":

                def _update_layout(dt):
                    """Bluetooth layout update wrapped into a callable
                    for scheduling.

                    Args:
                        dt (float): Schedule time
                    """
                    self.bluetooth_screen_text.opacity = 0
                    self.bluetooth_spinner.opacity = 1
                    self.bluetooth_spinner_text.opacity = 1
                    self.bluetooth_spinner.anim_delay = 0

                def _request_consumable_list():
                    """Calls the BluetoothConnectionManager's method to request
                    consumable list. Used before starting a process to make
                    sure that the data is up to date.

                    Raises:
                        DataRefreshTimeout: Indicates that data refresh has
                        timed out and the consumable data will have to be
                        read from the local file.
                    """
                    try:
                        event = self.manager.bcm.request_consumable_list()
                        refresh_result = event.wait(5)
                        # refresh_result = False
                        if not refresh_result:
                            raise DataRefreshTimeout
                    except NoBluetoothConnection:
                        Logger.exception(
                            "PreprocessScreen: Bluetooth connection unavailable, "
                            + "reading consumable data from locally stored file only"
                        )
                    except DataRefreshTimeout:
                        Logger.exception(
                            "PreprocessScreen: Data refresh timed out, "
                            + "reading consumable data from locally stored file only"
                        )

                Clock.schedule_once(_update_layout, -1)  # Needed to force showing the spinner etc
                # Might be avoided if hiding of that layout is removed in bluetooth_data_sync_screen()

                try:
                    Thread(target=_request_consumable_list, name="Request consumable list").start()
                except Exception as exception:
                    Logger.debug("PreprocessScreen: " + str(exception))
                finally:
                    Clock.schedule_once(self.consumables_info_selection_screen, 1)
                    self.bluetooth_screen_text.opacity = 1
                    self.bluetooth_spinner.opacity = 0
                    self.bluetooth_spinner_text.opacity = 0
                    self.bluetooth_spinner.anim_delay = -1

            elif self.manager.bcm.bluetooth_status == "fault":
                # What should happen if bluetooth_status changes to "fault"
                # when the sync screen is being shown.
                pass

            elif self.manager.bcm.bluetooth_status == "error":
                # What should happen if bluetooth_status changes to "error"
                # when the sync screen is being shown.
                pass

            elif self.manager.bcm.bluetooth_status == "warning":
                # What should happen if bluetooth_status changes to "warning"
                # when the sync screen is being shown.
                pass

    def warning_detected_callback(self, *args):
        """Disables or enables next button depending on the fault status.
        """
        if args[1] is True:
            if self.manager.fm.open_doors:
                self.next_button.disabled = True
        # Prevent reenabling button when there are errors present
        elif args[1] is False and self.manager.fm.error_detected is False:
            self.next_button.disabled = False

    def error_detected_callback(self, *args):
        """Disables or enables next button depending on the fault status.
        """
        if args[1] is True:
            self.next_button.disabled = True
        # Prevent reenabling button when there are warnings present
        elif args[1] is False and self.manager.fm.warning_detected is False:
            self.next_button.disabled = False

    def on_leave(self):
        """Definition of the behavior when this screen is being left.
        """
        self.top_panel_layout.opacity = OPACITY_FULL
        self.bottom_panel_layout.opacity = OPACITY_FULL