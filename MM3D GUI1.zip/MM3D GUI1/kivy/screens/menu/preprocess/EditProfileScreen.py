"""Holds functions that are used on the "Edit Profile Screen".
"""
import os
import re
import datetime
import json 

from stl import mesh
from subprocess import Popen
from threading import Thread
from kivy.clock import Clock
from kivy.logger import Logger

from Buttons import bind_callback, unbind_all_callbacks

from Constants import (
    OPACITY_ZERO, 
    OPACITY_FULL, 
    PROFILES_DIR, 
    PROFILES_DATA_DIR, 
    PROFILES_DATA_FILE, 
    FULL_CRUCIBLE_CAP,
    PROFILES_CUSTOM_DATA_FILE,
)
from Strings import CM3,OTHER_STRINGS
from Images import ICON_MENU_CUSTOM_PROFILE

def edit_profile_screen(self):
    """Sets up the "Custom Profile" screen.
    """
    def _confirmation_to_save(*args):
        self.current_screen = "save_changes"
        self.manager.tpm.add_tab('confirmation')

    self.nameinput_text.disabled = False
    self.volumeinput_text.disabled = False
    self.filename = self.profile_choice_spinner.text
    index = self.filenames.index(str(self.filename))
    self.volumeinput_text.text= self.volumes[index]
    self.nameinput_text.text= self.filename

    self.edit_profile_button.hiden = True
    self.delete_profile_button.hiden = True
    self.profile_buttons_layout.opacity = OPACITY_ZERO
    self.top_panel_layout.opacity = OPACITY_FULL
    self.bottom_panel_layout.opacity = OPACITY_FULL
    self.bluetooth_spinner.anim_delay = -1
    self.bluetooth_sync_layout.opacity = OPACITY_ZERO
    self.loading_layout.opacity = OPACITY_ZERO
    self.profile_choice_layout.opacity = OPACITY_ZERO
    self.preprocess_info_layout.opacity = OPACITY_ZERO
    self.custom_profile_layout.opacity = OPACITY_FULL
    self.preprocess_info_row1_column2_content_spinner.hidden = True
    self.preprocess_info_row2_column2_content_spinner.hidden = True
    self.profile_choice_spinner.disabled = True
    self.next_button.disabled = False
    self.back_button.disabled = True
    self.back_button_label.opacity = OPACITY_ZERO
    self.next_button_label.text = "SAVE"
    
    unbind_all_callbacks(self.next_button)
    unbind_all_callbacks(self.back_button)
    unbind_all_callbacks(self.back_a_button)
    unbind_all_callbacks(self.home_button)

    if self.profile_preview_image.source == ICON_MENU_CUSTOM_PROFILE:
        self.custom_image.source =ICON_MENU_CUSTOM_PROFILE
        self.custom_image.color= self.manager.COLOR_ICON
        self.custom = True
    else:
        self.custom_image.source = self.profile_preview_image.source
        self.custom_image.color = [1, 1, 1, 1]
        self.custom = False
        
    bind_callback(self.next_button, _confirmation_to_save)
    bind_callback(self.back_a_button, self.go_back_to_profile_selection)
    bind_callback(self.home_button, self.go_back_to_home)

def edit_profile_custom(self):
    print("custom")
    try:
        if float(self.volumeinput_text.text)>float(FULL_CRUCIBLE_CAP):
            #!It has to open a Popup and clean the input text box
            Logger.debug("The profile exceed the capacity of the crucible")
            self.manager.pop.show_popup(1)
            self.volumeinput_text.text=""
        elif float(self.volumeinput_text.text)<1:
            Logger.debug("Invalid Volume")
            self.manager.pop.show_popup(4)
            self.volumeinput_text.text=""
        elif self.manager.ccm.NAME_PROFILE=="" and self.manager.ccm.NAME_PROFILE:
            Logger.debug("Name is empty.")
            self.manager.pop.show_popup(2)
        elif self.nameinput_text.text == "" or self.nameinput_text.text == None:
            Logger.debug("Name is empty.")
            self.manager.pop.show_popup(2)
        elif self.nameinput_text.text == None and float(self.volumeinput_text.text)>float(FULL_CRUCIBLE_CAP):
            Logger.debug("No info.")
            self.manager.pop.show_popup(5)
        else:
            #*Everything went well with the capacity
            try:
                with open(PROFILES_CUSTOM_DATA_FILE, "r+") as file:
                    loaded = json.load(file)
                info = loaded[self.nameinput_text.text]
                if self.nameinput_text.text == self.filename:
                    Logger.debug("Change only volume value")
                    loaded[self.nameinput_text.text]={"volume":self.volumeinput_text.text}
                    print(loaded)
                    with open(PROFILES_CUSTOM_DATA_FILE, "w+") as file:
                        json.dump(loaded, file)
                    self.refresh_spinner_values()
                    self.profile_choice_spinner.text = self.nameinput_text.text
                    self.filename = self.nameinput_text.text
                    index = self.filenames.index(str(self.filename))
                    self.profile_name_label.text = self.filename
                    self.profile_volume_label.text = self.volumes[index] + CM3  # " cm\u00b3"
                    self.go_back_to_profile_selection()
                elif self.nameinput_text.text in self.filenames:
                    Logger.debug("Name already exist, use diferent")
                    self.manager.pop.show_popup(6)
                else:
                    pass
            except KeyError:    
                Logger.debug("Saving the original given name, volume is valid.")
                loaded[self.nameinput_text.text] = {"volume":self.volumeinput_text.text}
                Logger.debug("Different name, different volume")

                del loaded[self.filename]
                with open(PROFILES_CUSTOM_DATA_FILE, "w+") as file:
                    json.dump(loaded, file)
                self.refresh_spinner_values()
                self.profile_choice_spinner.text = self.nameinput_text.text
                self.filename = self.nameinput_text.text
                index = self.filenames.index(str(self.filename))
                self.profile_name_label.text = self.filename
                self.profile_volume_label.text = self.volumes[index] + CM3  # " cm\u00b3"
                self.go_back_to_profile_selection()
            except IOError:
                Logger.exception(OTHER_STRINGS["exception_file_read"][self.lang])
    except:
        #!It has to open a Popup and clean the input text box
        if self.nameinput_text.text == "" :
            Logger.debug("EditProfileScreen: EVERYTHING IS WRONG.")
            self.manager.pop.show_popup(5)
            self.nameinput_text.text=""
            self.volumeinput_text.text=""
        else:
            Logger.debug("Invalid Volume")
            self.manager.pop.show_popup(4)
            self.volumeinput_text.text=""

def edit_profile_stl(self):
    print(self.filename)
    try:
        if float(self.volumeinput_text.text)>float(FULL_CRUCIBLE_CAP):
            #!It has to open a Popup and clean the input text box
            Logger.debug("The profile exceed the capacity of the crucible")
            self.manager.pop.show_popup(1)
            self.volumeinput_text.text=""
        elif float(self.volumeinput_text.text)<1:
            Logger.debug("Invalid Volume")
            self.manager.pop.show_popup(4)
            self.volumeinput_text.text=""
        elif self.manager.ccm.NAME_PROFILE=="" and self.manager.ccm.NAME_PROFILE:
            Logger.debug("Name is empty.")
            self.manager.pop.show_popup(2)
        elif self.nameinput_text.text == "" or self.nameinput_text.text == None:
            Logger.debug("Name is empty.")
            self.manager.pop.show_popup(2)
        elif self.nameinput_text.text == None and float(self.volumeinput_text.text)>float(FULL_CRUCIBLE_CAP):
            Logger.debug("No info.")
            self.manager.pop.show_popup(5)
        else:
            try:
                if self.nameinput_text.text == self.filename:
                    #*Everything went well
                    Logger.debug("Change only volume value")
                    #>Change volume
                    with open(PROFILES_DATA_FILE, "r") as profiles:
                        loaded_files = [line.strip() for line in profiles]
                    i=0
                    for loadedFile in loaded_files:
                        data = loadedFile.split(";")
                        
                        if data[0][:-4] == self.filename:
                            data[3]=self.volumeinput_text.text
                            cadena = ";".join(data)
                            break
                        else:
                            pass
                        i+=1
                    loaded_files[i]=cadena
                    # print(loaded_files)
                    with open(PROFILES_DATA_FILE, "w+") as profiles:
                        for load_file in loaded_files:
                            profiles.writelines(load_file+"\n")
                    self.refresh_spinner_values()
                    self.profile_choice_spinner.text = self.nameinput_text.text
                    self.filename = self.nameinput_text.text
                    index = self.filenames.index(str(self.filename))
                    self.profile_name_label.text = self.filename
                    self.profile_volume_label.text = self.volumes[index] + CM3  # " cm\u00b3"
                    self.go_back_to_profile_selection()

                elif self.nameinput_text.text in self.filenames:
                    Logger.debug("Name already exist, use diferent")
                    self.manager.pop.show_popup(6)

                else:
                    with open(PROFILES_DATA_FILE, "r") as profiles:
                        loaded_files = [line.strip() for line in profiles]
                    i=0
                    for loadedFile in loaded_files:
                        data = loadedFile.split(";")
                        if data[0][:-4] == self.filename:
                            data[0] = self.nameinput_text.text+".stl" 
                            data[3] = self.volumeinput_text.text
                            cadena = ";".join(data)
                            break
                        else:
                            pass
                        i+=1
                    loaded_files[i]=cadena
                    with open(PROFILES_DATA_FILE, "w+") as profiles:
                        for load_file in loaded_files:
                            profiles.writelines(load_file+"\n")
                    name = PROFILES_DIR+"/"+self.filename+".stl"
                    new_name = PROFILES_DIR+"/"+self.nameinput_text.text+".stl"
                    os.rename(name, new_name)

                    name = PROFILES_DATA_DIR+"/"+self.filename+".png"
                    new_name = PROFILES_DATA_DIR+"/"+self.nameinput_text.text+".png"
                    os.rename(name, new_name)

                    self.refresh_spinner_values()
                    self.profile_choice_spinner.text = self.nameinput_text.text
                    self.filename = self.nameinput_text.text
                    index = self.filenames.index(str(self.filename))
                    self.profile_name_label.text = self.filename
                    self.profile_volume_label.text = self.volumes[index] + CM3  # " cm\u00b3"
                    self.go_back_to_profile_selection()
                    
            except KeyError:  
                #*Everything went well  
                pass
            except IOError:
                Logger.exception(OTHER_STRINGS["exception_file_read"][self.lang])
    except:
        #!It has to open a Popup and clean the input text box
        if self.nameinput_text.text == "" :
            Logger.debug("EVERYTHING IS WRONG.")
            self.manager.pop.show_popup(5)
            self.nameinput_text.text=""
            self.volumeinput_text.text=""
        else:
            Logger.debug("Invalid Volume")
            self.manager.pop.show_popup(4)
            self.volumeinput_text.text=""
            print("has to change only the name ")
