"""Holds definitions of functions used on the "Process Screen"
"""

from Buttons import bind_callback, unbind_all_callbacks
from Images import (
    ICON_MENU_DIE_PREPARATION,
    ICON_MENU_DIE_METAL_CASTING,
    ICON_MENU_INVESTMENT_MOLD_PREPARATION,
    ICON_MENU_INVESTMENT_METAL_CASTING,
    ICON_MENU_SAND_MOLD_PREPARATION,
    ICON_MENU_SAND_METAL_CASTING,
)
from Strings import PROCESS_MENUS


def die_casting_screen(self, *args):
    """Definition of the "Die Casting Screen".
    """
    self.current_screen = "die_casting"
    self.menu3_to_menu2()

    self.menu2_icon_left.source = ICON_MENU_DIE_PREPARATION
    self.menu2_icon_right.source = ICON_MENU_DIE_METAL_CASTING
    self.menu2_label_left.text = PROCESS_MENUS["die_preparation"][self.manager.lang]
    self.menu2_label_right.text = PROCESS_MENUS["metal_casting"][self.manager.lang]

    unbind_all_callbacks(self.menu3_button_left)
    unbind_all_callbacks(self.menu3_button_middle)
    unbind_all_callbacks(self.menu3_button_right)
    unbind_all_callbacks(self.menu2_button_left)
    unbind_all_callbacks(self.menu2_button_right)
    unbind_all_callbacks(self.back_button)
    bind_callback(self.menu2_button_left, self.start_die_preparation)
    bind_callback(self.menu2_button_right, self.start_die_metal_casting)
    bind_callback(self.back_button, self.add_profile_screen)

    self.warning_detected_callback()
    self.error_detected_callback()
    self.set_previous_screen()


def investment_casting_screen(self, *args):
    """Definition of the "Investment Casting Screen".
    """
    self.current_screen = "investment_casting"
    self.menu3_to_menu2()

    self.menu2_icon_left.source = ICON_MENU_INVESTMENT_MOLD_PREPARATION
    self.menu2_icon_right.source = ICON_MENU_INVESTMENT_METAL_CASTING
    self.menu2_label_left.text = PROCESS_MENUS["mold_preparation"][self.manager.lang]
    self.menu2_label_right.text = PROCESS_MENUS["metal_casting"][self.manager.lang]

    unbind_all_callbacks(self.menu3_button_left)
    unbind_all_callbacks(self.menu3_button_middle)
    unbind_all_callbacks(self.menu3_button_right)
    unbind_all_callbacks(self.menu2_button_left)
    unbind_all_callbacks(self.menu2_button_right)
    unbind_all_callbacks(self.back_button)
    bind_callback(self.menu2_button_left, self.start_investment_mold_preparation)
    bind_callback(self.menu2_button_right, self.start_investment_metal_casting)
    bind_callback(self.back_button, self.process_screen)

    self.warning_detected_callback()
    self.error_detected_callback()
    self.set_previous_screen()


def sand_casting_screen(self, *args):
    """Definition of the "Sand Casting Screen".
    """
    self.current_screen = "sand_casting"
    self.menu3_to_menu2()

    self.menu2_icon_left.source = ICON_MENU_SAND_MOLD_PREPARATION
    self.menu2_icon_right.source = ICON_MENU_SAND_METAL_CASTING
    self.menu2_label_left.text = PROCESS_MENUS["mold_preparation"][self.manager.lang]
    self.menu2_label_right.text = PROCESS_MENUS["metal_casting"][self.manager.lang]

    unbind_all_callbacks(self.menu3_button_left)
    unbind_all_callbacks(self.menu3_button_middle)
    unbind_all_callbacks(self.menu3_button_right)
    unbind_all_callbacks(self.menu2_button_left)
    unbind_all_callbacks(self.menu2_button_right)
    unbind_all_callbacks(self.back_button)
    bind_callback(self.menu2_button_left, self.start_sand_mold_preparation)
    bind_callback(self.menu2_button_right, self.start_sand_metal_casting)
    bind_callback(self.back_button, self.process_screen)


    self.warning_detected_callback()
    self.error_detected_callback()
    self.set_previous_screen()
