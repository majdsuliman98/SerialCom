import json
from threading import Thread
from kivy.logger import Logger
from Exceptions import NoBluetoothConnection, DataRefreshTimeout

from Constants import (
    TYPE_ID_CRUCIBLE,
    TYPE_ID_NOZZLE,
    TYPE_ID_DIES,
    TYPE_ID_SKIMMERS,
    TYPE_ID_MATERIAL_CASTING,
    TYPE_ID_MATERIAL_MOLD,
    TYPE_ID_MATERIAL_SAND,
    OPACITY_ON,
    OPACITY_OFF,
    CONSUMABES_FILE,
    CONSUMABLES_HARDWARE_FILE
)
from Strings import (
    CM3, 
    CONSUMABLE_RV,
    RECYCLE_VIEW_DATA_LOADER
)
from Images import (
    ICON_STATUS_DOWNLOADING,
    ICON_STATUS_OFFLINE,
    ICON_STATUS_UP_TO_DATE
)

def begin_consumable_data_reading_thread(self, consumable_type):
    """Requests a consumable list and waits for its arrival.

    Args:
        consumable_type (int): Consumable type which data is about to be read
    """


    def _begin_consumable_data_reading():
        """As described above. Wrapped for being called by a thread.

        Raises:
            DataRefreshTimeout: In case the data doesn't arrive fully or at all
            after 5 seconds then this exception is risen.
        """
        if not self.manager.bcm.consumables_up_to_date:
            try:
                event = self.manager.bcm.request_consumable_list()
                refresh_result = event.wait(5)

                if not refresh_result:
                    
                    raise DataRefreshTimeout

            except DataRefreshTimeout:
                
                self.continue_reading_thread(consumable_type)
                Logger.debug("Bluetooth data get timed out, reading consumable data from locally stored file only")

            except NoBluetoothConnection:
                
                self.continue_reading_thread(consumable_type)
                Logger.debug("Bluetooth connection unavailable, reading consumable data from locally stored file only")
     
    # Continue reading process no matter what the outcome of the above code 
    # print("continue")
    # self.continue_reading_thread(consumable_type)
    Thread(target=_begin_consumable_data_reading, name="Begin consumable data reading thread").start()


def continue_reading_thread(self, consumable_type):
    """Continues reading the given consumable's data and populates the
    RecycleView used to display that data on a screen.

    Args:
        consumable_type (int): Consumable type which data is being read
    """
    def _continue_consumable_data_reading():
        """As described above. Wrapped for being called by a thread.
        """
        def _convert_lifespan_time(lifespan):
            """Converts lifespan time into hours (and minutes).

            Args:
                lifespan (float): Element's lifespan as a float
                (hours and minutes in decimal format)

            Returns:
                string: Formatted lifespan time
            """
            hours = int(lifespan)
            minutes = (lifespan - hours) * 60
            if minutes == 0:
                return "{} h".format(hours)
            else:
                return "{} h {} min".format(hours, int(minutes))


        try:
            with open(CONSUMABES_FILE, "r+") as file:
                loaded = json.loads(file.read())

        except Exception as exception:
            Logger.exception("MainScreen: " + str(exception))
        else:
            index = 1
            self.ids.rv.data = []
            try:
                for element in loaded:
                    if element["TYPE"] == consumable_type:
                        if consumable_type == TYPE_ID_CRUCIBLE or consumable_type == TYPE_ID_DIES:
                            if element["ASSIGNED_MATERIAL"] is None:
                                column_1_data = "None"
                            else:
                                column_1_data = element["ASSIGNED_MATERIAL"]
                            column_2_data = _convert_lifespan_time(element["LIFESPAN_LEFT"])
                        elif consumable_type == TYPE_ID_NOZZLE or consumable_type == TYPE_ID_SKIMMERS:
                            column_1_data = _convert_lifespan_time(element["LIFESPAN_LEFT"])
                            column_2_data = ""
                        elif (
                            consumable_type == TYPE_ID_MATERIAL_CASTING
                            or consumable_type == TYPE_ID_MATERIAL_MOLD
                            or consumable_type == TYPE_ID_MATERIAL_SAND
                        ):
                            column_1_data = element["NAME"]
                            column_2_data = str(element["LIFESPAN_LEFT"]) + CM3
                        # serial_id = element["ID_SERIAL"]
                        serial_id = "0000000"
                        type_id = str(element["TYPE"])

                        self.rv.data.append(
                            {
                                "serial_id": serial_id,
                                "type_id": type_id,
                                "index": index,
                                "data_1": str(index),
                                "data_2": column_1_data,
                                "data_3": column_2_data,
                                "shx_data_1": self.rv_column1_title.size_hint_x,
                                "shx_data_2": self.rv_column2_title.size_hint_x,
                                "shx_data_3": self.rv_column3_title.size_hint_x,
                                "shx_button": self.rv_column4_title.size_hint_x,
                                "background_color": self.manager.COLOR_BACKGROUND
                                if index % 2
                                else self.manager.COLOR_BACKGROUND_SPINNER,
                                "button_opacity": OPACITY_ON
                                if self.manager.bcm.bluetooth_status == "connected"
                                else OPACITY_OFF,
                                "button_disabled": False if self.manager.bcm.bluetooth_status == "connected" else True,
                                "button_ripple_color": self.manager.COLOR_BACKGROUND
                                if index % 2
                                else self.manager.COLOR_BACKGROUND_SPINNER,
                                "button_label_text": CONSUMABLE_RV["remove_button"][self.manager.lang],
                            }
                        )
                        index += 1
                        # The background_color is set correctly, yet RV is somehow covering all rows,
                        # except for the last one, to have the default background color
                self.rv.refresh_from_data()

            except Exception as exception:
                Logger.exception(str(exception))
                self.rv.data.append(
                    {
                        "serial_id": "",
                        "type_id": "",
                        "index": 0,
                        "data_1": "Error",
                        "data_2": "Error",
                        "data_3": "Error",
                        "shx_data_1": self.rv_column1_title.size_hint_x,
                        "shx_data_2": self.rv_column2_title.size_hint_x,
                        "shx_data_3": self.rv_column3_title.size_hint_x,
                        "shx_button": self.rv_column4_title.size_hint_x,
                        "background_color": self.manager.COLOR_BACKGROUND,
                        "button_opacity": OPACITY_OFF,
                        "button_disabled": True,
                        "button_ripple_color": self.manager.COLOR_BACKGROUND,
                        "button_label_text": CONSUMABLE_RV["remove_button"][self.manager.lang],
                    }
                )
    Thread(target=_continue_consumable_data_reading, name="Continue consumable data reading thread").start()



def begin_hardware_data_reading_thread(self, consumable_hardware_type):

    def _begin_hardware_data_reading_thread():
        """As described above. Wrapped for being called by a thread.
        """
        def _convert_lifespan_time(lifespan):
            """Converts lifespan time into hours (and minutes).

            Args:
                lifespan (float): Element's lifespan as a float
                (hours and minutes in decimal format)

            Returns:
                string: Formatted lifespan time
            """
            hours = int(lifespan)
            minutes = (lifespan - hours) * 60
            if minutes == 0:
                return "{} h".format(hours)
            else:
                return "{} h {} min".format(hours, int(minutes))
        def _convert_lifespan_cycles(lifespan):
            """Converts lifespan into cycles remaining

            Args:
                lifespan (float): Element's lifespan as a float
                (hours and minutes in decimal format)

            Returns:
                string: Formatted lifespan cycles 
            """
            return "{} ".format(lifespan) + RECYCLE_VIEW_DATA_LOADER["cycles_remaining"][self.manager.lang]
        
        def _convert_lifespan_percentage(lifespan):
            """todo: This function has to be adjusted to convert the lifespan  into a percentage
            todo acording the the time and themperature of use"""

            """Converts lifespan time into hours (and minutes).

            Args:
                lifespan (float): Element's lifespan as a float
                (hours and minutes in decimal format)

            Returns:
                string: Formatted lifespan time
            """
            hours = int(lifespan)
            return "{} %".format(hours)
        try:
            with open(CONSUMABLES_HARDWARE_FILE, "r+") as file:
                loaded = json.loads(file.read())

        except Exception as exception:
            Logger.exception("MainScreen: " + str(exception))
        else:
            index = 1
            self.ids.rv.data = []
            try:
                for element in loaded:

                    if element["TYPE"] == consumable_hardware_type:
                        if consumable_hardware_type == TYPE_ID_CRUCIBLE or consumable_hardware_type == TYPE_ID_DIES:
                            if element["ASSIGNED_MATERIAL"] is None:
                                column_1_data = "None"
                            else:
                                column_1_data = element["ASSIGNED_MATERIAL"]
                            column_2_data = _convert_lifespan_percentage(element["LIFESPAN_LEFT"])

                        elif consumable_hardware_type == TYPE_ID_SKIMMERS or consumable_hardware_type == TYPE_ID_NOZZLE:
                            column_1_data = _convert_lifespan_cycles(element["LIFESPAN_LEFT"])
                            column_2_data = ""

                        serial_id = "0000000"
                        type_id = str(element["TYPE"])
                        self.rv.data.append(
                            {
                                "serial_id": serial_id,
                                "type_id": type_id,
                                "index": index,
                                "data_1": str(index),
                                "data_2": column_1_data,
                                "data_3": column_2_data,
                                "shx_data_1": self.rv_column1_title.size_hint_x,
                                "shx_data_2": self.rv_column2_title.size_hint_x,
                                "shx_data_3": self.rv_column3_title.size_hint_x,
                                "shx_button": self.rv_column4_title.size_hint_x,
                                "background_color": self.manager.COLOR_BACKGROUND
                                if index % 2
                                else self.manager.COLOR_BACKGROUND_SPINNER,
                                "button_opacity": OPACITY_ON
                                if self.manager.bcm.bluetooth_status == "connected"
                                else OPACITY_OFF,
                                "button_disabled": False if self.manager.bcm.bluetooth_status == "connected" else True,
                                "button_ripple_color": self.manager.COLOR_BACKGROUND
                                if index % 2
                                else self.manager.COLOR_BACKGROUND_SPINNER,
                                "button_label_text": CONSUMABLE_RV["remove_button"][self.manager.lang],
                            }
                        )
                        index += 1
                    # # The background_color is set correctly, yet RV is somehow covering all rows,
                    # # except for the last one, to have the default background color

                self.rv.refresh_from_data()

            except Exception as exception:
                Logger.exception(str(exception))
                self.rv.data.append(
                    {
                        "serial_id": "",
                        "type_id": "",
                        "index": 0,
                        "data_1": "Error",
                        "data_2": "Error",
                        "data_3": "Error",
                        "shx_data_1": self.rv_column1_title.size_hint_x,
                        "shx_data_2": self.rv_column2_title.size_hint_x,
                        "shx_data_3": self.rv_column3_title.size_hint_x,
                        "shx_button": self.rv_column4_title.size_hint_x,
                        "background_color": self.manager.COLOR_BACKGROUND,
                        "button_opacity": OPACITY_OFF,
                        "button_disabled": True,
                        "button_ripple_color": self.manager.COLOR_BACKGROUND,
                        "button_label_text": CONSUMABLE_RV["remove_button"][self.manager.lang],
                    }
                )
    Thread(target=_begin_hardware_data_reading_thread, name="Begin consumable hardware data reading thread").start()