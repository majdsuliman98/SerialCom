"""This file holds definitions of functions associated with finishing processes.
"""

from kivy.clock import Clock
from functools import partial

from Buttons import unbind_all_callbacks
from Constants import OPACITY_FULL, OPACITY_ZERO
from Strings import PROCESS_FINISHING


def finishing_process_screen(self):
    """Shows a "finishing" screen while coming back from preprocess
    or a process screen. Also switches back to a main screen and
    cleans up after a process.
    """
    def _clean_up_process_screens(self, screen, *args):
        """Removes process screen from WindowManager.

        Args:
            screen (string): Screen name
        """
        if screen == "die_preparation":
            self.manager.remove_widget(self.manager.get_screen("diePreparationProcess"))
        elif screen == "die_metal_casting":
            self.manager.remove_widget(self.manager.get_screen("dieMetalCastingProcess"))
        elif screen == "investment_mold_preparation":
            self.manager.remove_widget(self.manager.get_screen("investmentMoldPreparationProcess"))
        elif screen == "investment_metal_casting":
            self.manager.remove_widget(self.manager.get_screen("investmentMetalCastingProcess"))
        elif screen == "sand_mold_preparation":
            self.manager.remove_widget(self.manager.get_screen("sandMoldPreparationProcess"))
        elif screen == "sand_metal_casting":
            self.manager.remove_widget(self.manager.get_screen("sandMetalCastingProcess"))
        elif screen == "metal_casting":
           # self.manager.remove_widget(self.manager.get_screen("MetalCastingProcess"))
            print("")


    def _switch_to_main_screen(*args):
        """Switches the UI layout the Main Screen one.
        """
        self.loading_layout.opacity = OPACITY_ZERO
        self.top_panel_layout.opacity = OPACITY_FULL
        self.bottom_panel_layout.opacity = OPACITY_FULL
        if self.manager.get_screen("MetalCastingProcess").current_screen == "wrong_material":
            self.crucibles_screen()
        elif self.current_screen == "crucibles":
            self.crucibles_screen()
        elif self.current_screen == "nozzles":
            self.nozzles_screen()
        elif self.current_screen == "skimmers":
            self.skimmer_screen()
        else:
            self.main_screen()


    # If coming back from Preprocess screens
    if self.current_screen == "preprocess":
        if (
            self.manager.ccm.selected_process == "die_preparation"
            or self.manager.ccm.selected_process == "die_metal_casting"
        ):
            self.die_casting_screen()
        elif (
            self.manager.ccm.selected_process == "investment_mold_preparation"
            or self.manager.ccm.selected_process == "investment_metal_casting"
        ):
            self.investment_casting_screen()
        elif (
            self.manager.ccm.selected_process == "sand_mold_preparation"
            or self.manager.ccm.selected_process == "sand_metal_casting"
        ):
            self.sand_casting_screen()
    elif self.current_screen == "add_profile":
        # self.main_screen()
        self.add_profile_screen()
    elif self.current_screen == "home":
        # self.main_screen()
        self.main_screen()

    # If coming back from an actual process
    else:
        self.hide_menu2()
        self.loading_layout.opacity = OPACITY_FULL
        self.top_panel_layout.opacity = OPACITY_ZERO
        self.bottom_panel_layout.opacity = OPACITY_ZERO

        if self.current_screen == "die_preparation":
            self.loading_label.text = PROCESS_FINISHING["finish_die_prep"][self.manager.lang]
        elif self.current_screen == "die_metal_casting":
            self.loading_label.text = PROCESS_FINISHING["finish_die_cast"][self.manager.lang]
        elif self.current_screen == "investment_mold_preparation":
            self.loading_label.text = PROCESS_FINISHING["finish_investment_prep"][self.manager.lang]
        elif self.current_screen == "investment_metal_casting":
            self.loading_label.text = PROCESS_FINISHING["finish_investment_cast"][self.manager.lang]
        elif self.current_screen == "sand_mold_preparation":
            self.loading_label.text = PROCESS_FINISHING["finish_sand_prep"][self.manager.lang]
        elif self.current_screen == "sand_metal_casting":
            self.loading_label.text = PROCESS_FINISHING["finish_sand_cast"][self.manager.lang]
        elif self.current_screen == "metal_casting":
            self.loading_label.text = PROCESS_FINISHING["finish_cast"][self.manager.lang]
        else:
            self.loading_label.text = "FINISHING CASTING PROCESS."
        Clock.schedule_once(partial(_clean_up_process_screens, self,self.current_screen), 1)
        unbind_all_callbacks(self.menu3_button_left)
        unbind_all_callbacks(self.menu3_button_middle)
        unbind_all_callbacks(self.menu3_button_right)
        unbind_all_callbacks(self.back_button)
        Clock.schedule_once(_switch_to_main_screen, 1)
