"""Holds functions that are used to start Investment Casting processes.
"""


def start_investment_mold_preparation(self, *args):
    """Starts Investment Mold Preparation process.
    """
    self.current_screen = "investment_mold_preparation"
    self.manager.ccm.selected_process = "investment_mold_preparation"
    self.manager.current = "preprocess"


def start_investment_metal_casting(self, *args):
    """Starts Investment Metal Casting process.
    """
    self.current_screen = "investment_metal_casting"
    self.manager.ccm.selected_process = "investment_metal_casting"
    self.manager.current = "preprocess"
