"""Holds functions that are used to start Die Casting processes.
"""


def start_die_preparation(self, *args):
    """Starts Die Preparation process.
    """
    self.current_screen = "die_preparation"
    self.manager.ccm.selected_process = "die_preparation"
    self.manager.current = "preprocess"


def start_die_metal_casting(self, *args):
    """Starts Die Metal Casting process.
    """
    self.current_screen = "die_metal_casting"
    self.manager.ccm.selected_process = "die_metal_casting"
    self.manager.current = "preprocess"
