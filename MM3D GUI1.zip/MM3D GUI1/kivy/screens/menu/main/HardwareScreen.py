"""Holds definitions of functions used on the "Hardware Screen"
"""
from Buttons import (
    bind_callback, 
    unbind_all_callbacks
)
from Constants import (
    TYPE_ID_CRUCIBLE, 
    TYPE_ID_NOZZLE, 
    TYPE_ID_DIES, 
    TYPE_ID_DIES,
    TYPE_ID_SKIMMERS
)
from Images import (
    ICON_MENU_CRUCIBLE,
    ICON_MENU_NOZZLE,
    ICON_MENU_DIES,
    ICON_MENU_SKIMMER,
    ICON_STATUS_DOWNLOADING,
    ICON_STATUS_OFFLINE,
    ICON_STATUS_UP_TO_DATE
)
from Strings import CONSUMABLE_RV


def crucibles_screen(self, *args):
    """Definition of the "Crucibles Screen".
    """
    def _change_cruicible(*args):
        self.current_screen = "change_cruicible"
        self.manager.tpm.add_tab('confirmation')

    
    # self.manager.bcm.data_status_icon = ICON_STATUS_DOWNLOADING
    self.current_screen = "crucibles"
    self.rv_title_icon.source = ICON_MENU_CRUCIBLE
    self.rv_title_label.text = CONSUMABLE_RV["crucibles"]["title"][self.manager.lang]
    self.rv_column1_title.text = CONSUMABLE_RV["crucibles"]["column_1"][self.manager.lang]
    self.rv_column2_title.text = CONSUMABLE_RV["crucibles"]["column_2"][self.manager.lang]
    self.rv_column3_title.text = CONSUMABLE_RV["crucibles"]["column_3"][self.manager.lang]
    self.show_menu3()
    self.menu3_to_rv()

    unbind_all_callbacks(self.back_a_button)
    bind_callback(self.back_a_button, self.hardware_screen)

    
    unbind_all_callbacks(self.change_hardware_button)
    bind_callback(self.change_hardware_button,_change_cruicible)
    self.change_hardware_button.disabled = False
    self.manager.bcm.consumables_up_to_date = False
    self.ids.rv.data = []
    # self.begin_consumable_data_reading_thread(TYPE_ID_CRUCIBLE)
    self.begin_hardware_data_reading_thread(TYPE_ID_CRUCIBLE)
    self.set_previous_screen()


def nozzles_screen(self, *args):
    """Definition of the "Nozzles Screen".
    """
    def _change_nozzle(*args):
        self.current_screen = "change_nozzles"
        self.manager.tpm.add_tab('confirmation')

    self.current_screen = "nozzles"
    self.rv_title_icon.source = ICON_MENU_NOZZLE
    self.rv_title_label.text = CONSUMABLE_RV["nozzles"]["title"][self.manager.lang]
    self.rv_column1_title.text = CONSUMABLE_RV["nozzles"]["column_1"][self.manager.lang]
    self.rv_column2_title.text = CONSUMABLE_RV["nozzles"]["column_2"][self.manager.lang]
    self.rv_column3_title.text = CONSUMABLE_RV["nozzles"]["column_3"][self.manager.lang]
    self.show_menu3()
    self.menu3_to_rv()

    # self.manager.bcm.data_status_icon = ICON_STATUS_DOWNLOADING
    # self.manager.bcm.data_status_icon = ICON_STATUS_DOWNLOADING
    unbind_all_callbacks(self.back_a_button)
    bind_callback(self.back_a_button, self.hardware_screen)

    self.change_hardware_button.disabled = False
    unbind_all_callbacks(self.change_hardware_button)
    bind_callback(self.change_hardware_button,_change_nozzle)

    self.manager.bcm.consumables_up_to_date = False
    self.ids.rv.data = []
    # self.begin_consumable_data_reading_thread(TYPE_ID_NOZZLE)
    self.begin_hardware_data_reading_thread(TYPE_ID_NOZZLE)
    self.set_previous_screen()


def skimmer_screen(self, *args):
    """Definition of the "Dies Screen".
    """
    def _change_skimmer(*args):
        self.current_screen = "change_skimmer"
        self.manager.tpm.add_tab('confirmation')

    self.current_screen = "skimmers"
    self.rv_title_icon.source = ICON_MENU_SKIMMER
    self.rv_title_label.text = CONSUMABLE_RV["skimmer"]["title"][self.manager.lang]
    self.rv_column1_title.text = CONSUMABLE_RV["skimmer"]["column_1"][self.manager.lang]
    self.rv_column2_title.text = CONSUMABLE_RV["skimmer"]["column_2"][self.manager.lang]
    self.rv_column3_title.text = CONSUMABLE_RV["skimmer"]["column_3"][self.manager.lang]
    self.show_menu3()
    self.menu3_to_rv()

    # self.manager.bcm.data_status_icon = ICON_STATUS_DOWNLOADING
    # self.manager.bcm.data_status_icon = ICON_STATUS_DOWNLOADING
    unbind_all_callbacks(self.back_a_button)
    bind_callback(self.back_a_button, self.hardware_screen)
    
    self.change_hardware_button.disabled = False
    unbind_all_callbacks(self.change_hardware_button)
    bind_callback(self.change_hardware_button,_change_skimmer)

    self.manager.bcm.consumables_up_to_date = False
    self.ids.rv.data = []
    # self.begin_consumable_data_reading_thread(TYPE_ID_SKIMMERS)
    self.begin_hardware_data_reading_thread(TYPE_ID_SKIMMERS)
    self.set_previous_screen()





