"""Holds functions that are used to start Sand Casting processes.
"""


def start_sand_mold_preparation(self, *args):
    """Starts Sand Mold Preparation process.
    """
    self.current_screen = "sand_mold_preparation"
    self.manager.ccm.selected_process = "sand_mold_preparation"
    self.manager.current = "preprocess"


def start_sand_metal_casting(self, *args):
    """Starts Sand Metal Casting process.
    """
    self.current_screen = "sand_metal_casting"
    self.manager.ccm.selected_process = "sand_metal_casting"
    self.manager.current = "preprocess"
