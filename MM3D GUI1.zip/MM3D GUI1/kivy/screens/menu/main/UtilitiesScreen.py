"""Holds definitions of functions used on the "Utilities Screen"
"""

from Buttons import bind_callback, unbind_all_callbacks, calculate_nav_buttons, calculate_menu3_buttons_fonts
from Images import (
    ICON_MENU_HARDWARE,
    ICON_MENU_MATERIALS,
    ICON_MENU_ADD_MATERIAL,
    ICON_TOGGLE_ON,
    ICON_TOGGLE_OFF
)
from Strings import CONSUMABLES_MENU, LANGUAGES, UTILITIES_SCREEN


def invert_colors(self, *args):
    """Inverts the app's color theme.
    """
    if self.manager.theme == "light":
        self.manager.theme = "dark"
        self.invert_color_icon.source = ICON_TOGGLE_ON
    else:
        self.manager.theme = "light"
        self.invert_color_icon.source = ICON_TOGGLE_OFF

def machine_settings(self, *args):
    """Language choice screen.
    """
    def _go_back(*args):
        """Hides lang screen layout and switches to previous screen.
        """
        # unbind_all_callbacks(self.camera_feed_button)
        unbind_all_callbacks(self.invert_color_button)
        self.machine_settings_to_menu2()
        self.utilities_screen()
    def _go_home(*args):
        # unbind_all_callbacks(self.camera_feed_button)
        unbind_all_callbacks(self.invert_color_button)
        self.main_screen()

    self.menu2_to_machine_settings()
    self.current_screen = "settings"
    languages = []
    for language in LANGUAGES:
        languages.append(LANGUAGES[language][self.manager.lang])

    if self.manager.theme == "light":
        self.invert_color_icon.source = ICON_TOGGLE_OFF
    else:
        self.invert_color_icon.source = ICON_TOGGLE_ON

    self.lang_spinner.values = languages
    self.lang_spinner.text = LANGUAGES[self.manager.lang][self.manager.lang]
    self.lang_text.text = UTILITIES_SCREEN["selected_language"][self.manager.lang]
    self.light_mode_text.text = UTILITIES_SCREEN["invert_colors"][self.manager.lang]
    self.camera_settings_text.text = "Camera settings"
    
    unbind_all_callbacks(self.home_button)
    bind_callback(self.home_button,_go_home)

    # unbind_all_callbacks(self.camera_feed_button)
    # bind_callback(self.camera_feed_button, self.manager.tpm.camera_feed)

    unbind_all_callbacks(self.invert_color_button)
    bind_callback(self.invert_color_button, self.invert_colors)

    unbind_all_callbacks(self.back_a_button)
    bind_callback(self.back_a_button, _go_back)

    unbind_all_callbacks(self.utilities_button)
    bind_callback(self.utilities_button, _go_back)

    self.set_previous_screen()


def on_language(self, spinner):
    """Called on language selection - updates UI.

    Args:
        spinner (ConsumableSelectionSpinner): Language selection spinner object
    """
    self.manager.lang = list(LANGUAGES)[spinner.values.index(spinner.text)]

    languages = []
    for language in LANGUAGES:
        languages.append(LANGUAGES[language][self.manager.lang])
    self.lang_spinner.values = languages
    self.lang_spinner.text = LANGUAGES[self.manager.lang][self.manager.lang]
    self.lang_text.text = UTILITIES_SCREEN["selected_language"][self.manager.lang]
    self.light_mode_text.text = UTILITIES_SCREEN["invert_colors"][self.manager.lang]
    calculate_nav_buttons(
        self.back_button_label,
        self.back_button_background,
        self.next_button_label,
        self.next_button_background
    )


def consumables_screen(self, *args):
    """Definition of the "Consumables" screen.
    """
    if self.previous_screen == "materials":
        self.hide_rv()
        self.show_menu3()
    else:
        self.show_menu3()

    self.current_screen = "consumables"
    self.menu3_icon_left.source = ICON_MENU_HARDWARE
    self.menu3_icon_middle.source = ICON_MENU_MATERIALS
    self.menu3_icon_right.source = ICON_MENU_ADD_MATERIAL
    self.menu3_label_left.text = CONSUMABLES_MENU["hardware"][self.manager.lang]
    self.menu3_label_middle.text = CONSUMABLES_MENU["materials"][self.manager.lang]
    self.menu3_label_right.text = CONSUMABLES_MENU["add_consumable"][self.manager.lang]
    calculate_menu3_buttons_fonts(self.menu3_label_left, self.menu3_label_middle, self.menu3_label_right)

    unbind_all_callbacks(self.menu3_button_left)
    unbind_all_callbacks(self.menu3_button_middle)
    unbind_all_callbacks(self.menu3_button_right)
    unbind_all_callbacks(self.back_a_button)
    unbind_all_callbacks(self.utilities_button)

    bind_callback(self.menu3_button_left, self.hardware_screen)
    bind_callback(self.menu3_button_middle, self.casting_materials_screen)
    bind_callback(self.menu3_button_right, self.qr_screen)
    bind_callback(self.back_a_button, self.utilities_screen)
    bind_callback(self.utilities_button, self.utilities_screen)

    self.set_previous_screen()
