"""Holds definitions of functions used on the "Consumables Screen"
"""

from pyzbar import pyzbar
from threading import Thread
from picamera import PiCamera
from picamera.array import PiRGBArray

from Buttons import bind_callback, unbind_all_callbacks, calculate_menu3_buttons_fonts
from Constants import OPACITY_FULL, OPACITY_ZERO
from Images import (
    ICON_MENU_CRUCIBLE,
    ICON_MENU_NOZZLE,
    ICON_MENU_DIES,
    ICON_MENU_CASTING_MATERIAL,
    ICON_MENU_INVESTMENT_POWDER,
    ICON_MENU_SAND,
    ICON_MENU_SKIMMER
)
from Strings import HARDWARE_MENU, MATERIALS_MENU


def hardware_screen(self, *args):
    """Definition of the "Hardware Screen".
    """
    self.current_screen = "hardware"
    self.menu3_icon_left.source = ICON_MENU_CRUCIBLE
    self.menu3_icon_middle.source = ICON_MENU_NOZZLE
    self.menu3_icon_right.source = ICON_MENU_SKIMMER
    self.menu3_label_left.text = HARDWARE_MENU["crucible"][self.manager.lang]
    self.menu3_label_middle.text = HARDWARE_MENU["nozzle"][self.manager.lang]
    self.menu3_label_right.text = HARDWARE_MENU["skimmer"][self.manager.lang]
    calculate_menu3_buttons_fonts(self.menu3_label_left, self.menu3_label_middle, self.menu3_label_right)
    if self.previous_screen == "consumables":
        unbind_all_callbacks(self.menu3_button_left)
        unbind_all_callbacks(self.menu3_button_middle)
        unbind_all_callbacks(self.menu3_button_right)
        unbind_all_callbacks(self.back_a_button)
    else:
        unbind_all_callbacks(self.back_a_button)
        self.rv_to_menu3()

    if self.previous_screen == "consumables":
        bind_callback(self.menu3_button_left, self.crucibles_screen)
        bind_callback(self.menu3_button_middle, self.nozzles_screen)
        bind_callback(self.menu3_button_right, self.skimmer_screen)

    bind_callback(self.back_a_button, self.consumables_screen)
    self.set_previous_screen()


def materials_screen(self, *args):
    """Definition of the "Materials Screen".
    """
    self.current_screen = "materials"
    self.menu3_icon_left.source = ICON_MENU_CASTING_MATERIAL
    self.menu3_icon_middle.source = ICON_MENU_INVESTMENT_POWDER
    self.menu3_icon_right.source = ICON_MENU_SAND
    self.menu3_label_left.text = MATERIALS_MENU["casting_alloy"][self.manager.lang]
    self.menu3_label_middle.text = MATERIALS_MENU["investment_powder"][self.manager.lang]
    self.menu3_label_right.text = MATERIALS_MENU["green_sand"][self.manager.lang]
    calculate_menu3_buttons_fonts(self.menu3_label_left, self.menu3_label_middle, self.menu3_label_right)

    if self.previous_screen == "consumables":
        unbind_all_callbacks(self.menu3_button_left)
        unbind_all_callbacks(self.menu3_button_middle)
        unbind_all_callbacks(self.menu3_button_right)
        unbind_all_callbacks(self.back_a_button)
    else:
        unbind_all_callbacks(self.back_a_button)
        self.rv_to_menu3()

    if self.previous_screen == "consumables":
        bind_callback(self.menu3_button_left, self.casting_materials_screen)
        bind_callback(self.menu3_button_middle, self.investment_materials_screen)
        bind_callback(self.menu3_button_right, self.sand_materials_screen)

    bind_callback(self.back_a_button, self.consumables_screen)
    self.set_previous_screen()


def pause_qr_screen_preview(self, *args):
    """Pauses camera preview (when a tabbed popup is opened).
    """
    self.read = False
    self.qr_thread.join()
    self.camera.stop_preview()


def unpause_qr_screen_preview(self, *args):
    """Unpauses the preview.
    """
    self.read = True
    self.manager.tpm.video_tab_locked = False
    self.qr_thread = Thread(target=self._qr_reading, name="QR thread")
    self.qr_thread.start()
    self.camera.start_preview(fullscreen=False, window=(575, 144, 400, 300))


def _qr_reading(self):
    """Wraps QR code reading functionality in order to be called
    with a thread.
    """
    for frame in self.camera.capture_continuous(self.rawCapture, format="bgr", use_video_port=True):
        barcodes = pyzbar.decode(frame.array)
        for barcode in barcodes:
            self._qr_parse(barcode.type, barcode.data.decode())
        self.rawCapture.truncate(0)
        if not self.read:
            break


# TODO: Reimplement adding consumables using QR reading on the machine
def _qr_parse(self, barType, barData):
    """Meant to parse the QR code and call a functionality that would
    add a consumable it represents if the QR code is valid. Right now
    it just retuns information if a scanned code is a QR.

    Args:
        barType (string): Scanned code type
        barData (string): Scanned code data
    """
    print("[INFO] Found {} barcode: {}".format(barType, barData))
    if barType == "QRCODE":
        print("QR")
    else:
        print("else")


def qr_screen(self, *args):
    """Definition of the QR Screen.
    """
    def _leave(*args):
        """Takes the user back to the Consumables Screen.
        """
        self.read = False
        self.qr_thread.join()
        self.camera.stop_preview()
        self.camera.close()
        self.qr_layout.opacity = OPACITY_ZERO
        self.consumables_screen()
        self.show_menu3()
        unbind_all_callbacks(self.back_button)
        bind_callback(self.back_button, self.utilities_screen)
        self.manager.tpm.video_tab_locked = False

    def _home(*args):
        """Takes the user back to the Consumables Screen.
        """
        self.read = False
        self.qr_thread.join()
        self.camera.stop_preview()
        self.camera.close()
        self.main_screen()
        self.qr_layout.opacity = OPACITY_ZERO
        self.manager.tpm.video_tab_locked = False


    def _utilities(*args):
        """Takes the user back to the Utilities Screen.
        """
        self.read = False
        self.qr_thread.join()
        self.camera.stop_preview()
        self.camera.close()
        self.qr_layout.opacity = OPACITY_ZERO
        self.utilities_screen()
        self.show_menu3()
        unbind_all_callbacks(self.back_button)
        bind_callback(self.back_button, self.utilities_screen)
        self.manager.tpm.video_tab_locked = False

    if self.manager.tpm.video_tab.streaming:
        self.manager.tpm.video_tab.stop_livefeed()

    self.hide_menu3()
    self.current_screen = "qr"
    self.manager.tpm.video_tab_locked = True
    unbind_all_callbacks(self.back_a_button)
    bind_callback(self.back_a_button, _leave)

    unbind_all_callbacks(self.home_button)
    bind_callback(self.home_button, _home)


    unbind_all_callbacks(self.utilities_button)
    bind_callback(self.utilities_button, _utilities)
    
    self.set_previous_screen()
    self.qr_layout.opacity = OPACITY_FULL

    self.camera = PiCamera()
    self.camera.vflip = True
    self.camera.resolution = (640, 480)
    self.camera.exposure_compensation = 16
    self.rawCapture = PiRGBArray(self.camera, size=self.camera.resolution)
    self.read = True

    self.camera.start_preview(fullscreen=False, window=(575, 144, 400, 300))  # x, y, size_x, size_y
    self.qr_thread = Thread(target=self._qr_reading, name="QR reading thread")
    self.qr_thread.start()
