"""Holds definitions of functions used on the "Materials Screen"
"""

from Buttons import bind_callback, unbind_all_callbacks
from Constants import TYPE_ID_MATERIAL_CASTING, TYPE_ID_MATERIAL_MOLD, TYPE_ID_MATERIAL_SAND
from Images import (
    ICON_MENU_CASTING_MATERIAL,
    ICON_MENU_INVESTMENT_POWDER,
    ICON_MENU_SAND,
    ICON_STATUS_DOWNLOADING,
    ICON_STATUS_OFFLINE,
    ICON_STATUS_UP_TO_DATE
)
from Strings import CONSUMABLE_RV


def casting_materials_screen(self, *args):
    """Definition of the "Casting Materials Screen".
    """
    self.current_screen = "materials"
    self.rv_title_icon.source = ICON_MENU_CASTING_MATERIAL
    self.rv_title_label.text = CONSUMABLE_RV["casting_mat"]["title"][self.manager.lang]
    self.rv_column1_title.text = CONSUMABLE_RV["casting_mat"]["column_1"][self.manager.lang]
    self.rv_column2_title.text = CONSUMABLE_RV["casting_mat"]["column_2"][self.manager.lang]
    self.rv_column3_title.text = CONSUMABLE_RV["casting_mat"]["column_3"][self.manager.lang]
    self.menu3_to_rv()
    # self.manager.bcm.data_status_icon = ICON_STATUS_DOWNLOADING

    unbind_all_callbacks(self.back_a_button)
    bind_callback(self.back_a_button, self.consumables_screen)

    unbind_all_callbacks(self.home_button)
    bind_callback(self.home_button, self.main_screen)
    self.change_hardware_button.hidden = True

    self.manager.bcm.consumables_up_to_date = False

    self.ids.rv.data = []
    self.begin_consumable_data_reading_thread(TYPE_ID_MATERIAL_CASTING)
    self.set_previous_screen()


def investment_materials_screen(self, *args):
    """Definition of the "Investment Materials Screen".
    """
    self.current_screen = "materials"
    self.rv_title_icon.source = ICON_MENU_INVESTMENT_POWDER
    self.rv_title_label.text = CONSUMABLE_RV["investment_mat"]["title"][self.manager.lang]
    self.rv_column1_title.text = CONSUMABLE_RV["investment_mat"]["column_1"][self.manager.lang]
    self.rv_column2_title.text = CONSUMABLE_RV["investment_mat"]["column_2"][self.manager.lang]
    self.rv_column3_title.text = CONSUMABLE_RV["investment_mat"]["column_3"][self.manager.lang]
    self.menu3_to_rv()

    unbind_all_callbacks(self.back_a_button)
    bind_callback(self.back_a_button, self.materials_screen)

    unbind_all_callbacks(self.home_button)
    bind_callback(self.home_button, self.main_screen)

    self.ids.rv.data = []
    self.begin_consumable_data_reading_thread(TYPE_ID_MATERIAL_MOLD)
    self.set_previous_screen()


def sand_materials_screen(self, *args):
    """Definition of the "Sand Materials Screen".
    """
    self.current_screen = "materials"
    self.rv_title_icon.source = ICON_MENU_SAND
    self.rv_title_label.text = CONSUMABLE_RV["sand_mat"]["title"][self.manager.lang]
    self.rv_column1_title.text = CONSUMABLE_RV["sand_mat"]["column_1"][self.manager.lang]
    self.rv_column2_title.text = CONSUMABLE_RV["sand_mat"]["column_2"][self.manager.lang]
    self.rv_column3_title.text = CONSUMABLE_RV["sand_mat"]["column_3"][self.manager.lang]
    self.menu3_to_rv()

    unbind_all_callbacks(self.back_a_button)
    bind_callback(self.back_a_button, self.materials_screen)

    unbind_all_callbacks(self.home_button)
    bind_callback(self.home_button, self.main_screen)

    self.ids.rv.data = []
    self.begin_consumable_data_reading_thread(TYPE_ID_MATERIAL_SAND)
    self.set_previous_screen()
