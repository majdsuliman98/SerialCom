from kivy.app import App
from kivy.lang import Builder
from kivy.clock import Clock
# from kivy.logger import Logger
from kivy.uix.screenmanager import Screen
from kivy.properties import ObjectProperty, StringProperty

from UtilitiesScreen import machine_settings, on_language, invert_colors, consumables_screen
from ConsumablesScreen import (
    hardware_screen,
    materials_screen,
    qr_screen,
    _qr_reading,
    _qr_parse,
    pause_qr_screen_preview,
    unpause_qr_screen_preview,
)
from HardwareScreen import crucibles_screen, nozzles_screen, skimmer_screen
from MaterialsScreen import casting_materials_screen, investment_materials_screen, sand_materials_screen
from ProcessScreen import die_casting_screen, investment_casting_screen, sand_casting_screen
from DieCastingScreen import start_die_preparation, start_die_metal_casting
from InvestmentCastingScreen import start_investment_mold_preparation, start_investment_metal_casting
from SandCastingScreen import start_sand_mold_preparation, start_sand_metal_casting
from MainScreenUtilities import (
    hide_menu1,
    hide_menu2,
    hide_menu3,
    hide_rv,
    menu2_to_menu3,
    menu3_to_menu2,
    menu3_to_rv,
    rv_to_menu3,
    show_menu3,
    show_menu2,
    menu2_to_machine_settings,
   machine_settings_to_menu2,
   show_home
)
from PostProcessUtilities import finishing_process_screen
# from RecycleViewDataLoader import (
#     begin_consumable_data_reading_thread, 
#     continue_reading_thread,
#     begin_hardware_data_reading_thread
# )

from Buttons import bind_callback, unbind_all_callbacks, calculate_nav_buttons, calculate_menu3_buttons_fonts
from Images import (
    ICON_BOTTOM_PANEL_NULL,
    ICON_BOTTOM_PANEL_ZA,
    ICON_MENU_SHUTDOWN,
    ICON_MENU_UTILITIES,
    ICON_MENU_PROCESS,
    ICON_MENU_DIE_CASTING,
    ICON_MENU_INVESTMENT_CASTING,
    ICON_MENU_SAND_CASTING,
    ICON_MENU_LANGUAGE,
    ICON_MENU_INVERT_TO_DARK,
    ICON_MENU_INVERT_TO_LIGHT,
    ICON_MENU_CONSUMABLES,
    ICON_MENU_SETTINGS,
    ICON_MENU_CUSTOM,
    ICON_MENU_DATA,
    ICON_BOTTOM_PANEL_AL,
    ICON_BOTTOM_PANEL_ZA
)
from Strings import MAIN_MENU, UTILITIES_MENU, PROCESS_MENU
from Constants import (
    OPACITY_ZERO,
    TYPE_ID_SKIMMERS,
    TYPE_ID_NOZZLE,
    TYPE_ID_CRUCIBLE,
    MIN_LIFESPAN_SKIMMER,
    MIN_LIFESPAN_CRUCIBLE,
    MIN_LIFESPAN_NOZZLE
)
from IconControlManager import(
    icon_material_manager,
    icon_crucible_manager,
    icon_temperature_manager
)

Builder.load_file("screens/menu/main/MainScreen.kv")


class MainScreen(Screen):
    """This is an implementation of the class that contains all of the screens
    regarded as "main screens". That means that these screens are all of
    the ones that are available while browsing through the menu up until to
    the moment when user can choose a process he wants to run. If a process
    is chosen the UI switches to "Preprocess Screens".
    """
    utilities_button = ObjectProperty(None)
    top_panel_layout = ObjectProperty(None)
    menu3_layout = ObjectProperty(None)
    menu2_layout = ObjectProperty(None)
    menu1_layout = ObjectProperty(None)
    back_button_background = ObjectProperty(None)
    back_button_label = ObjectProperty(None)
    back_button = ObjectProperty(None)
    next_button_background = ObjectProperty(None)
    next_button_label = ObjectProperty(None)
    next_button = ObjectProperty(None)
    menu3_icon_left = ObjectProperty(None)
    menu3_label_left = ObjectProperty(None)
    menu3_button_left = ObjectProperty(None)
    menu3_icon_middle = ObjectProperty(None)
    menu3_label_middle = ObjectProperty(None)
    menu3_button_middle = ObjectProperty(None)
    menu3_icon_right = ObjectProperty(None)
    menu3_label_right = ObjectProperty(None)
    menu3_button_right = ObjectProperty(None)
    menu2_icon_left = ObjectProperty(None)
    menu2_label_left = ObjectProperty(None)
    menu2_button_left = ObjectProperty(None)
    menu2_icon_right = ObjectProperty(None)
    menu2_label_right = ObjectProperty(None)
    menu2_button_right = ObjectProperty(None)
    rv_layout = ObjectProperty(None)
    rv = ObjectProperty(None)
    rv_title_label = ObjectProperty(None)
    rv_title_icon = ObjectProperty(None)
    rv_column1_title = ObjectProperty(None)
    rv_column2_title = ObjectProperty(None)
    rv_column3_title = ObjectProperty(None)
    rv_column4_title = ObjectProperty(None)
    loading_layout = ObjectProperty(None)
    loading_label = ObjectProperty(None)
    qr_layout = ObjectProperty(None)
    lang_layout = ObjectProperty(None)
    lang_text = ObjectProperty(None)
    light_mode_text = ObjectProperty(None)
    camera_settings_text = ObjectProperty(None)
    invert_color_button= ObjectProperty(None)
    invert_color_icon = ObjectProperty(None)
    lang_spinner = ObjectProperty(None)
    bottom_panel_layout = ObjectProperty(None)
    bottom_temperature_label = ObjectProperty(None)
    bottom_capacity_label = ObjectProperty(None)
    current_screen = StringProperty()
    home_button = ObjectProperty(None)
    back_a_button = ObjectProperty(None)
    off_button = ObjectProperty(None)
    camera_feed_button = ObjectProperty(None)
    change_hardware_button = ObjectProperty(None)

    bottom_material_icon = ObjectProperty(None)
    bottom_crucible_icon = ObjectProperty(None)
    bottom_temperature_icon = ObjectProperty(None)


    def __init__(self, manager, **kwargs):
        super(MainScreen, self).__init__(**kwargs)
        manager.fm.bind(error_detected=self.error_detected_callback)
        manager.fm.bind(warning_detected=self.warning_detected_callback)

        manager.ccm.bind(MATERIAL=self.icon_material_callback)
        manager.ccm.bind(CRUCIBLE_MICROCHIP_EN=self.icon_crucible_callback)
        manager.ccm.bind(CRUCIBLE_TILTED=self.icon_crucible_callback)
        manager.ccm.bind(TEMP_CONTROL=self.icon_temperature_callback)
        #manager.ccm.bind(CRUCIBLE_MICROCHIP_EN=self.icon_temperature_callback)


        self.icon_material_callback()
        self.icon_crucible_callback()
        self.icon_temperature_callback()

        calculate_nav_buttons(
            self.back_button_label,
            self.back_button_background,
            self.next_button_label,
            self.next_button_background
        )


    # ----------------------------- MAIN MENU SCREEN ----------------------------- #
    def main_screen(self, *args):
        """Definition of the "Main Screen".
        """
        self.current_screen = "main"
        self.show_home()
        self.menu3_icon_middle.source = ICON_MENU_PROCESS
        # self.menu1_icon_middle.source = ICON_MENU_PROCESS
        self.menu3_label_middle.text = "START PROCESS"
        # Prevents calling that function at startup which would hang up the app

        if self.previous_screen is not None:
            calculate_menu3_buttons_fonts(self.menu3_label_left, self.menu3_label_middle, self.menu3_label_right)
        #self.home_button.disabled = True
        self.back_button.disabled = True
        self.next_button.disabled = True
        self.home_button.disabled = True
        self.back_a_button.disabled = True

        # self.next_button_label.hidden = True
        self.back_a_button.hidden = True
        self.back_button.hidden = True
        self.next_button.hidden = True
        self.home_button.hidden = True
        self.back_button_label.opacity = OPACITY_ZERO

        self.menu3_button_left.disabled = True
        self.menu3_button_right.disabled = True
        self.menu3_button_left.hidden = True
        self.menu3_button_right.hidden = True

        unbind_all_callbacks(self.menu3_button_left)
        unbind_all_callbacks(self.menu3_button_middle)
        unbind_all_callbacks(self.menu3_button_right)
        unbind_all_callbacks(self.home_button)
        unbind_all_callbacks(self.back_button)
        unbind_all_callbacks(self.utilities_button)
        bind_callback(self.off_button, self.shutdown)
        bind_callback(self.menu3_button_middle, self.add_profile_screen)
        bind_callback(self.utilities_button, self.utilities_screen)
        #In case, it starts with the E.button pressed
        
        if self.manager.ccm.EMERGENCY_STOP == True:
            self.warning_detected_callback()
        else: pass
        self.set_previous_screen()

    # ----------------------------- UTILITIES SCREEN ----------------------------- #
    def utilities_screen(self, *args):
        """Definition of the "Utilities Screen".
        """
        self.current_screen = "utilities"
        self.show_menu2()

        self.menu2_icon_left.source = ICON_MENU_SETTINGS

        self.menu2_icon_right.source = ICON_MENU_CONSUMABLES
        self.menu2_label_left.text = UTILITIES_MENU["machine settings"][self.manager.lang]
        self.menu2_label_right.text = UTILITIES_MENU["consumables"][self.manager.lang]
       # calculate_menu2_buttons_fonts(self.menu3_label_left, self.menu3_label_middle, self.menu3_label_right)
        if self.previous_screen == "main":
            self.back_button.disabled = True
        self.back_button.disabled = True
        self.back_button.hidden = True
        self.home_button.disabled = False
        self.back_a_button.disabled = False
        unbind_all_callbacks(self.menu2_button_left)
        unbind_all_callbacks(self.menu2_button_right)
        unbind_all_callbacks(self.back_button)
        unbind_all_callbacks(self.back_a_button)
        bind_callback(self.home_button,self.main_screen)
        bind_callback(self.menu2_button_left, self.machine_settings)
        bind_callback(self.menu2_button_right, self.consumables_screen)
        bind_callback(self.back_button, self.main_screen)
        bind_callback(self.back_a_button, self.main_screen)

        self.set_previous_screen()
    # ----------------------------- ADD PROFILE SCREEN ----------------------------- #

    def add_profile_screen(self, *args):
        """Definition of the "Add profile Screen".
        """
        self.current_screen = "add profile"
        self.show_menu2()
        self.menu2_icon_left.source = ICON_MENU_DATA
        self.menu2_icon_right.source = ICON_MENU_CUSTOM
        self.menu2_label_left.text = "SELECT FILE"
        self.menu2_label_right.text = "CUSTOM PART"
       # calculate_menu2_buttons_fonts(self.menu3_label_left, self.menu3_label_middle, self.menu3_label_right)
        if self.previous_screen == "main":
            self.back_button.disabled = True

        self.back_button.disabled = True
        self.back_button.hidden = True

        self.back_a_button.disabled = False
        self.home_button.disabled = False

        unbind_all_callbacks(self.menu2_button_left)
        unbind_all_callbacks(self.menu2_button_right)
        unbind_all_callbacks(self.back_a_button)
        unbind_all_callbacks(self.back_button)
        unbind_all_callbacks(self.home_button)
        bind_callback(self.home_button,self.main_screen)
        bind_callback(self.menu2_button_left, self.profile_selection)
        bind_callback(self.menu2_button_right, self.custom_profile)        
        bind_callback(self.back_button, self.main_screen)
        bind_callback(self.back_a_button, self.main_screen)
        self.set_previous_screen()


    # --------------------------------- CALLBACKS -------------------------------- #
    def on_pre_enter(self):
        """Pre-enter callback. Depending on the previous_screen variable
        it displays the MainScreen layout or calls a function to clean up
        after a process and display the post-process screen.
        """
        if not hasattr(self, "previous_screen"):
            
            self.current_screen = ""  # None
            self.previous_screen = None
            hide_menu2(self)
            hide_menu3(self)
            hide_rv(self)
            self.main_screen()
            
        else:
            self.finishing_process_screen()
        

    def warning_detected_callback(self, *args):
        """Called when a warning is detected. Blocks the possibility
        to start a process (disables button which lead to preprocess screens).
        """
        block_process = False
        for index, fault in enumerate(self.manager.fm.faults):
            if self.manager.fm.fault_states[index] and self.manager.fm.fault_process_blocking[index]:
                block_process = True
        if not block_process and not self.menu3_button_left.hidden:
            pass
        elif self.current_screen not in ["crucibles", "dies", "settings", "materials", "nozzles", "qr","main"]:
            self.menu2_button_left.disabled = block_process
            self.menu2_button_right.disabled = block_process
        elif self.current_screen == "main":
            self.menu3_button_middle.disabled = block_process

    def error_detected_callback(self, *args):
        """Called when a error is detected. Blocks the possibility
        to start a process (disables button which lead to preprocess screens).
        """
        block_process = False
        for index, fault in enumerate(self.manager.fm.faults):
            if self.manager.fm.fault_states[index] and self.manager.fm.fault_process_blocking[index]:
                block_process = True

        if not block_process and not self.menu3_button_left.hidden:
            pass
        # Prevent showing menu2 over screens that don't display any menu at all
        elif self.current_screen not in ["crucibles", "dies", "Settings", "materials", "nozzles", "qr","main"]:
            self.menu2_button_left.disabled = block_process
            self.menu2_button_right.disabled = block_process


    def icon_material_callback(self, *args):
        self.icon_material_manager(self.bottom_material_icon)

    def icon_crucible_callback(self, *args):
        self.icon_crucible_manager(self.bottom_crucible_icon)

    def icon_temperature_callback(self, *args):
        self.icon_temperature_manager(self.bottom_temperature_icon)

#------------FUNCTIONS---------------------
    def shutdown(self, *args):
        #"""Definition of what happens after the shutdown button is pressed.
        #"""
        # App.get_running_app().stop()
        # os.system('sudo shutdown -h now')
        self.manager.current = "debug2"

    def start_debug(self, *args):
        """Starts Die Metal Casting process.
        """
        self.manager.current = "debug2"


    def set_previous_screen(self, *args):
        """Updates the previous_screen variable.s
        """
        self.previous_screen = self.current_screen
    # Note: Definitions of functions defined below are in separate files







        # --------------------------------- IconControl -------------------------------- #
    # ---------------------------- IconControlManager.py ---------------------------- #
    def icon_material_manager(self, icon):
        icon_material_manager(self, icon)

    def icon_crucible_manager(self, icon):
        icon_crucible_manager(self, icon)

    def icon_temperature_manager(self, icon):
        icon_temperature_manager(self, icon)

    # --------------------------------- UTILITIES -------------------------------- #
    # ---------------------------- UtilitiesScreen.py ---------------------------- #

    def machine_settings(self, *args):
        machine_settings(self, *args)

    def on_language(self, *args):
        on_language(self, *args)

    def invert_colors(self, *args):
        invert_colors(self, *args)

    def consumables_screen(self, *args):
        consumables_screen(self, *args)

    # -------------------------------- CONSUMABLES ------------------------------- #
    # --------------------------- ConsumablesScreen.py --------------------------- #

    def hardware_screen(self, *args):
        hardware_screen(self, *args)

    def materials_screen(self, *args):
        materials_screen(self, *args)

    def qr_screen(self, *args):
        qr_screen(self, *args)

    def pause_qr_screen_preview(self, *args):
        pause_qr_screen_preview(self, *args)

    def unpause_qr_screen_preview(self, *args):
        unpause_qr_screen_preview(self, *args)

    def _qr_reading(self):
        _qr_reading(self)

    def _qr_parse(self, barType, barData):
        _qr_parse(self, barType, barData)

    # --------------------------------- HARDWARE --------------------------------- #
    # ----------------------------- HardwareScreen.py ---------------------------- #

    def crucibles_screen(self, *args):
        crucibles_screen(self, *args)

    def nozzles_screen(self, *args):
        nozzles_screen(self, *args)

    # def dies_screen(self, *args):
    #     dies_screen(self, *args)

    def skimmer_screen(self, *args):
        skimmer_screen(self, *args)

    # --------------------------------- MATERIALS -------------------------------- #
    # ---------------------------- MaterialsScreen.py ---------------------------- #

    def casting_materials_screen(self, *args):
        casting_materials_screen(self, *args)

    def investment_materials_screen(self, *args):
        investment_materials_screen(self, *args)

    def sand_materials_screen(self, *args):
        sand_materials_screen(self, *args)

    # ---------------------------------- PROCESS --------------------------------- #
    # ----------------------------- ProcessScreen.py ----------------------------- #

    def die_casting_screen(self, *args):
        die_casting_screen(self, *args)

    def investment_casting_screen(self, *args):
        investment_casting_screen(self, *args)

    def sand_casting_screen(self, *args):
        sand_casting_screen(self, *args)

    # ---------------------------- DIE CASTING PROCESS --------------------------- #
    # ---------------------------- DieCastingScreen.py --------------------------- #

    def start_die_preparation(self, *args):
        start_die_preparation(self, *args)

    def start_die_metal_casting(self, *args):
        start_die_metal_casting(self, *args)

    # ------------------------ INVESTMENT CASTING PROCESS ------------------------ #
    # ------------------------ InvestmentCastingScreen.py ------------------------ #

    def start_investment_mold_preparation(self, *args):
        start_investment_mold_preparation(self, *args)

    def start_investment_metal_casting(self, *args):
        start_investment_metal_casting(self, *args)

    #-------------------PREPROCESS--------------------------------------------#

    def profile_selection(self, *args):
        """Starts Investment Metal Casting process.
        """
        self.current_screen = "profile_selection"
        self.manager.ccm.selected_process = "metal_casting"
        self.manager.current = "preprocess"

    def custom_profile(self, *args):
        """Starts Investment Metal Casting process.
        """
        self.current_screen = "custom_profile"
        self.manager.ccm.selected_process = "metal_casting"
        self.manager.current = "preprocess"

    # --------------------------- SAND CASTING PROCESS --------------------------- #
    # --------------------------- SandCastingScreen.py --------------------------- #

    def start_sand_mold_preparation(self, *args):
        start_sand_mold_preparation(self, *args)

    def start_sand_metal_casting(self, *args):
        start_sand_metal_casting(self, *args)

    # ---------------------------- POST PROCESS TASKS ---------------------------- #
    # -------------------------- PostProcessUtilities.py ------------------------- #

    def finishing_process_screen(self, *args):
        finishing_process_screen(self)

    # ------------------------------ RV DATA LOADING ----------------------------- #
    # ------------------------- RecycleViewDataLoader.py ------------------------- #

    def begin_consumable_data_reading_thread(self, type_):
        begin_consumable_data_reading_thread(self, type_)

    def continue_reading_thread(self, type_):
        continue_reading_thread(self, type_)

    def begin_hardware_data_reading_thread(self, type_):
        begin_hardware_data_reading_thread(self, type_)

    # --------------------------------- UTILITIES -------------------------------- #
    # -------------------------- MainScreenUtilities.py -------------------------- #

    def hide_menu2(self):
        hide_menu2(self)

    def hide_menu3(self):
        hide_menu3(self)

    def hide_rv(self):
        hide_rv(self)

    def menu2_to_menu3(self):
        menu2_to_menu3(self)

    def menu3_to_menu2(self, *args):
        menu3_to_menu2(self)

    def menu3_to_rv(self, *args):
        menu3_to_rv(self)

    def rv_to_menu3(self):
        rv_to_menu3(self)

    def show_menu3(self):
        show_menu3(self)


    def show_home(self):
        show_home(self)

    def show_menu2(self):
        show_menu2(self)

    def menu2_to_machine_settings(self):
        menu2_to_machine_settings(self)

    def machine_settings_to_menu2(self):
        machine_settings_to_menu2(self)
