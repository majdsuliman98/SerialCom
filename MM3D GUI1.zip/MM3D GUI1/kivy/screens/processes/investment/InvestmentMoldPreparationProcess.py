from kivy.lang import Builder
from kivy.uix.screenmanager import Screen
from kivy.properties import ObjectProperty

from Buttons import (
    bind_callback,
    unbind_all_callbacks,
    calculate_button_inner_layout,
    calculate_one_button_layout,
    calculate_two_button_layout,
    calculate_nav_buttons,
)
from Constants import (
    OPACITY_FULL,
    OPACITY_ZERO,
    OPACITY_WARNING
)
from Images import (
    ICON_BUTTON_REPEAT,
    ICON_BUTTON_FINISH,
    ICON_BUTTON_VACUUM_PUMP
)
from Strings import INVESTMENT_MOLD_PREPARATION, PROCESS_COMMON

Builder.load_file("screens/processes/investment/InvestmentMoldPreparationProcess.kv")


class InvestmentMoldPreparationProcess(Screen):
    """Implementation of the Investment Mold Preparation process.
    Each function which name starts with "screen" corresponds
    to following process' steps.
    """
    exit_button_background = ObjectProperty(None)
    exit_button_label = ObjectProperty(None)
    next_button_background = ObjectProperty(None)
    next_button_label = ObjectProperty(None)
    next_button = ObjectProperty(None)
    warning_triangle = ObjectProperty(None)
    centered_text = ObjectProperty(None)
    screen_text = ObjectProperty(None)
    button_left_end = ObjectProperty(None)
    button_middle = ObjectProperty(None)
    button_right_end = ObjectProperty(None)
    button_icon = ObjectProperty(None)
    button_label = ObjectProperty(None)
    button_area = ObjectProperty(None)
    button_1_left_end = ObjectProperty(None)
    button_1_middle = ObjectProperty(None)
    button_1_right_end = ObjectProperty(None)
    button_1_icon = ObjectProperty(None)
    button_1_label = ObjectProperty(None)
    button_1_area = ObjectProperty(None)
    button_2_left_end = ObjectProperty(None)
    button_2_middle = ObjectProperty(None)
    button_2_right_end = ObjectProperty(None)
    button_2_icon = ObjectProperty(None)
    button_2_label = ObjectProperty(None)
    button_2_area = ObjectProperty(None)
    left_die_icon = ObjectProperty(None)
    left_die_label = ObjectProperty(None)
    time_icon = ObjectProperty(None)
    time_label = ObjectProperty(None)
    right_die_icon = ObjectProperty(None)
    right_die_label = ObjectProperty(None)
    pressure_icon = ObjectProperty(None)
    pressure_label = ObjectProperty(None)

    def __init__(self, **kwargs):
        super(InvestmentMoldPreparationProcess, self).__init__(**kwargs)
        calculate_nav_buttons(
            self.exit_button_label,
            self.exit_button_background,
            self.next_button_label,
            self.next_button_background
        )

    def on_pre_enter(self):
        # Set up all of the buttons
        self.button = [
            self.button_left_end,
            self.button_middle,
            self.button_right_end,
            self.button_icon,
            self.button_label,
            self.button_area,
        ]

        self.button_1 = [
            self.button_1_left_end,
            self.button_1_middle,
            self.button_1_right_end,
            self.button_1_icon,
            self.button_1_label,
            self.button_1_area,
        ]

        self.button_2 = [
            self.button_2_left_end,
            self.button_2_middle,
            self.button_2_right_end,
            self.button_2_icon,
            self.button_2_label,
            self.button_2_area,
        ]

        # Hide all of the buttons
        self.button_area.hidden = True
        self.button_1_area.hidden = True
        self.button_2_area.hidden = True

        self.left_die_icon.opacity = OPACITY_FULL
        self.left_die_label.opacity = OPACITY_FULL
        self.time_icon.opacity = OPACITY_ZERO
        self.time_label.opacity = OPACITY_ZERO
        self.right_die_icon.opacity = OPACITY_FULL
        self.right_die_label.opacity = OPACITY_FULL
        self.pressure_icon.opacity = OPACITY_ZERO
        self.pressure_label.opacity = OPACITY_ZERO
        self.screen_1()

    # > All of the screens defined below correspond to the steps of the process
    # > which are described in the file the processes are described in. They
    # > are left with the [summary] placeholders here because the steps might
    # > still change a little so it was a bit pointless to write all of their
    # > descriptions here right now.

    def screen_1(self, *args):
        """[summary]
        """
        self.screen_text.text = INVESTMENT_MOLD_PREPARATION["screen_1"][self.manager.lang]
        self.centered_text.text = PROCESS_COMMON["caution"][self.manager.lang]
        bind_callback(self.next_button, self.screen_2)

    def screen_2(self, *args):
        """[summary]
        """
        self.screen_text.text = (
            INVESTMENT_MOLD_PREPARATION["screen_23_1"][self.manager.lang]
            + str(round(self.manager.ccm.REQUIRED_MATERIAL, 2))
            + INVESTMENT_MOLD_PREPARATION["screen_2_2"][self.manager.lang]
        )

        self.warning_triangle.opacity = OPACITY_ZERO
        self.centered_text.text = ""
        self.centered_text.size_hint = (0, 0)
        self.centered_text.opacity = OPACITY_ZERO

        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_3)

    def screen_3(self, *args):
        """[summary]
        """
        self.screen_text.text = (
            INVESTMENT_MOLD_PREPARATION["screen_23_1"][self.manager.lang]
            + str(round(self.manager.ccm.REQUIRED_WATER, 2))
            + INVESTMENT_MOLD_PREPARATION["screen_3_2"][self.manager.lang]
        )
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_4)

    def screen_4(self, *args):
        """[summary]
        """
        self.screen_text.text = INVESTMENT_MOLD_PREPARATION["screen_4"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_5)

    def screen_5(self, *args):
        """[summary]
        """
        self.screen_text.text = INVESTMENT_MOLD_PREPARATION["screen_5"][self.manager.lang]

        self.screen_text.font_size = 28
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_6)

    def screen_6(self, *args):
        """[summary]
        """
        self.screen_text.text = INVESTMENT_MOLD_PREPARATION["screen_6"][self.manager.lang]

        self.screen_text.font_size = 36

        self.left_die_icon.opacity = OPACITY_ZERO
        self.left_die_label.opacity = OPACITY_ZERO
        self.time_icon.opacity = OPACITY_FULL
        self.time_label.opacity = OPACITY_FULL
        self.right_die_icon.opacity = OPACITY_ZERO
        self.right_die_label.opacity = OPACITY_ZERO

        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_7)

    def screen_7(self, *args):
        """[summary]
        """

        def _start_vacuuming(*args):
            """Turning on the vacuum pump will be called by this function
            some day. Right now it only changes the UI.
            """
            self.pressure_icon.opacity = OPACITY_FULL
            self.pressure_label.opacity = OPACITY_FULL
            self.button_area.hidden = True
            unbind_all_callbacks(self.button)
            self.next_button.disabled = False
            bind_callback(self.next_button, self.screen_8)

        self.screen_text.text = INVESTMENT_MOLD_PREPARATION["screen_7"][self.manager.lang]

        self.screen_text.parent.height -= 80

        self.button_label.text = INVESTMENT_MOLD_PREPARATION["start_vacuuming"][self.manager.lang]
        self.button_icon.source = ICON_BUTTON_VACUUM_PUMP
        calculate_button_inner_layout(self.button)
        calculate_one_button_layout(self.button, self.screen_text)

        self.button_area.disabled = False
        bind_callback(self.button, _start_vacuuming)
        self.next_button.disabled = True
        unbind_all_callbacks(self.next_button)

    def screen_8(self, *args):
        """[summary]
        """
        self.screen_text.text = INVESTMENT_MOLD_PREPARATION["screen_8"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_9)

    def screen_9(self, *args):
        """[summary]
        """

        def _repeat_process(*args):
            """Sets up process repetition.
            """
            self.warning_triangle.opacity = OPACITY_WARNING
            self.centered_text.size_hint = (None, None)
            self.centered_text.opacity = OPACITY_FULL

            self.button_1_area.hidden = True
            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)
            self.button_2_area.hidden = True
            self.next_button.disabled = False
            self.screen_1()

        def _finish_process(*args):
            """Takes user back to the main screen.
            """
            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)
            self.manager.current = "main"

        self.screen_text.text = INVESTMENT_MOLD_PREPARATION["screen_9"][self.manager.lang]
        self.screen_text.parent.height += 80

        self.button_1_label.text = PROCESS_COMMON["repeat"][self.manager.lang]
        self.button_1_icon.source = ICON_BUTTON_REPEAT
        self.button_2_label.text = PROCESS_COMMON["finish"][self.manager.lang]
        self.button_2_icon.source = ICON_BUTTON_FINISH

        calculate_button_inner_layout(self.button_1)
        calculate_button_inner_layout(self.button_2)
        calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)

        self.time_icon.opacity = OPACITY_ZERO
        self.time_label.opacity = OPACITY_ZERO

        self.button_1_area.disabled = False
        self.button_2_area.disabled = False
        bind_callback(self.button_1, _repeat_process)
        bind_callback(self.button_2, _finish_process)

        self.next_button.disabled = True
        unbind_all_callbacks(self.next_button)
