from kivy.lang import Builder
from kivy.uix.screenmanager import Screen
from kivy.properties import ObjectProperty

from Buttons import (
    bind_callback,
    unbind_all_callbacks,
    calculate_button_inner_layout,
    calculate_two_button_layout,
    calculate_nav_buttons,
)

from Constants import (
    OPACITY_FULL,
    OPACITY_ZERO,
    OPACITY_WARNING
)
from Images import (
    ICON_BUTTON_REUSE,
    ICON_BUTTON_NEW,
    ICON_BUTTON_DRY,
    ICON_BUTTON_ACCEPT,
    ICON_BUTTON_REPEAT,
    ICON_BUTTON_FINISH
)
from Strings import (
    PROCESS_COMMON,
    SAND_MOLD_PREPARATION
)

Builder.load_file("screens/processes/sand/SandMoldPreparationProcess.kv")


class SandMoldPreparationProcess(Screen):
    """Implementation of the Sand Mold Preparation process.
    Each function which name starts with "screen" corresponds
    to following process' steps.
    """
    exit_button_background = ObjectProperty(None)
    exit_button_label = ObjectProperty(None)
    next_button_background = ObjectProperty(None)
    next_button_label = ObjectProperty(None)
    next_button = ObjectProperty(None)
    warning_triangle = ObjectProperty(None)
    centered_text = ObjectProperty(None)
    screen_text = ObjectProperty(None)
    button_1_left_end = ObjectProperty(None)
    button_1_middle = ObjectProperty(None)
    button_1_right_end = ObjectProperty(None)
    button_1_icon = ObjectProperty(None)
    button_1_label = ObjectProperty(None)
    button_1_area = ObjectProperty(None)
    button_2_left_end = ObjectProperty(None)
    button_2_middle = ObjectProperty(None)
    button_2_right_end = ObjectProperty(None)
    button_2_icon = ObjectProperty(None)
    button_2_label = ObjectProperty(None)
    button_2_area = ObjectProperty(None)

    def __init__(self, **kwargs):
        super(SandMoldPreparationProcess, self).__init__(**kwargs)
        calculate_nav_buttons(
            self.exit_button_label,
            self.exit_button_background,
            self.next_button_label,
            self.next_button_background
        )

    def on_pre_enter(self):
        # Set up all of the buttons
        self.button_1 = [
            self.button_1_left_end,
            self.button_1_middle,
            self.button_1_right_end,
            self.button_1_icon,
            self.button_1_label,
            self.button_1_area,
        ]

        self.button_2 = [
            self.button_2_left_end,
            self.button_2_middle,
            self.button_2_right_end,
            self.button_2_icon,
            self.button_2_label,
            self.button_2_area,
        ]

        # Hide all of the buttons
        self.button_1_area.hidden = True
        self.button_2_area.hidden = True
        self.screen_1()

    # > All of the screens defined below correspond to the steps of the process
    # > which are described in the file the processes are described in. They
    # > are left with the [summary] placeholders here because the steps might
    # > still change a little so it was a bit pointless to write all of their
    # > descriptions here right now.

    def screen_1(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_1"][self.manager.lang]
        self.centered_text.text = PROCESS_COMMON["caution"][self.manager.lang]
        self.centered_text.bold = True
        bind_callback(self.next_button, self.screen_2)

    def screen_2(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_2"][self.manager.lang]
        self.screen_text.texture_update()  # Required for correct buttons' placement

        self.warning_triangle.opacity = OPACITY_ZERO
        self.centered_text.text = ""
        self.centered_text.size_hint = (0, 0)
        self.centered_text.opacity = OPACITY_ZERO

        self.button_1_label.text = SAND_MOLD_PREPARATION["used"][self.manager.lang]
        self.button_1_icon.source = ICON_BUTTON_REUSE
        self.button_2_label.text = SAND_MOLD_PREPARATION["new"][self.manager.lang]
        self.button_2_icon.source = ICON_BUTTON_NEW

        calculate_button_inner_layout(self.button_1)
        calculate_button_inner_layout(self.button_2)
        calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)

        self.button_1_area.disabled = False
        self.button_2_area.disabled = False
        bind_callback(self.button_1, self.screen_3)
        bind_callback(self.button_2, self.screen_6)
        self.next_button.disabled = True
        unbind_all_callbacks(self.next_button)

    def screen_3(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_3"][self.manager.lang]
        self.button_1_area.hidden = True
        self.button_2_area.hidden = True
        self.next_button.disabled = False
        unbind_all_callbacks(self.button_1)
        unbind_all_callbacks(self.button_2)
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_4)

    def screen_4(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_4"][self.manager.lang]
        self.screen_text.texture_update()

        self.button_1_label.text = SAND_MOLD_PREPARATION["too_dry"][self.manager.lang]
        self.button_1_icon.source = ICON_BUTTON_DRY
        self.button_2_label.text = SAND_MOLD_PREPARATION["okay"][self.manager.lang]
        self.button_2_icon.source = ICON_BUTTON_ACCEPT

        calculate_button_inner_layout(self.button_1)
        calculate_button_inner_layout(self.button_2)
        calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)

        self.button_1_area.disabled = False
        self.button_2_area.disabled = False
        self.next_button.disabled = True
        bind_callback(self.button_1, self.screen_5)
        bind_callback(self.button_2, self.screen_6)
        unbind_all_callbacks(self.next_button)

    def screen_5(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_5"][self.manager.lang]
        self.button_1_area.hidden = True
        self.button_2_area.hidden = True
        self.next_button.disabled = False
        unbind_all_callbacks(self.button_1)
        unbind_all_callbacks(self.button_2)
        bind_callback(self.next_button, self.screen_3)

    def screen_6(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_6"][self.manager.lang]
        self.button_1_area.hidden = True
        self.button_2_area.hidden = True
        self.next_button.disabled = False
        unbind_all_callbacks(self.button_1)
        unbind_all_callbacks(self.button_2)
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_7)

    def screen_7(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_7"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_8)

    def screen_8(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_8"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_9)

    def screen_9(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_9"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_10)

    def screen_10(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_10"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_11)

    def screen_11(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_11"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_12)

    def screen_12(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_12"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_13)

    def screen_13(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_13"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_14)

    def screen_14(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_14"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_15)

    def screen_15(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_15"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_16)

    def screen_16(self, *args):
        """[summary]
        """
        self.screen_text.text = SAND_MOLD_PREPARATION["screen_16"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_17)

    def screen_17(self, *args):
        """[summary]
        """

        def _repeat_process(*args):
            """Sets up process repetition.
            """
            self.warning_triangle.opacity = OPACITY_WARNING
            self.centered_text.size_hint = (None, None)
            self.centered_text.opacity = OPACITY_FULL
            self.button_1_area.hidden = True
            self.button_2_area.hidden = True
            self.next_button.disabled = False
            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)
            self.screen_1()

        def _finish_process(*args):
            """Takes user back to the main screen.
            """
            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)
            self.manager.current = "main"

        self.screen_text.text = SAND_MOLD_PREPARATION["screen_17"][self.manager.lang]
        self.screen_text.texture_update()

        self.button_1_label.text = PROCESS_COMMON["repeat"][self.manager.lang]
        self.button_1_icon.source = ICON_BUTTON_REPEAT
        self.button_2_label.text = PROCESS_COMMON["finish"][self.manager.lang]
        self.button_2_icon.source = ICON_BUTTON_FINISH

        calculate_button_inner_layout(self.button_1)
        calculate_button_inner_layout(self.button_2)
        calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)

        self.button_1_area.disabled = False
        self.button_2_area.disabled = False
        bind_callback(self.button_1, _repeat_process)
        bind_callback(self.button_2, _finish_process)
        self.next_button.disabled = True
        unbind_all_callbacks(self.next_button)
