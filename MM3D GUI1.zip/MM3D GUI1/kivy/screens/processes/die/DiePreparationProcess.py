from kivy.lang import Builder
from kivy.uix.screenmanager import Screen
from kivy.properties import ObjectProperty

from Buttons import (
    bind_callback,
    unbind_all_callbacks,
    calculate_button_inner_layout,
    calculate_two_button_layout,
    calculate_nav_buttons
)
from Images import ICON_BUTTON_START_CASTING_PROCESS, ICON_BUTTON_ACCEPT
from Strings import PROCESS_COMMON, DIE_PREPARATION

Builder.load_file("screens/processes/die/DiePreparationProcess.kv")


class DiePreparationProcess(Screen):
    """Implementation of the Die Preparation process.
    Each function which name starts with "screen" corresponds
    to following process' steps.
    """
    exit_button_background = ObjectProperty(None)
    exit_button_label = ObjectProperty(None)
    next_button_background = ObjectProperty(None)
    next_button_label = ObjectProperty(None)
    next_button = ObjectProperty(None)
    screen_text = ObjectProperty(None)
    button_1_left_end = ObjectProperty(None)
    button_1_middle = ObjectProperty(None)
    button_1_right_end = ObjectProperty(None)
    button_1_icon = ObjectProperty(None)
    button_1_label = ObjectProperty(None)
    button_1_area = ObjectProperty(None)
    button_2_left_end = ObjectProperty(None)
    button_2_middle = ObjectProperty(None)
    button_2_right_end = ObjectProperty(None)
    button_2_icon = ObjectProperty(None)
    button_2_label = ObjectProperty(None)
    button_2_area = ObjectProperty(None)

    def __init__(self, **kwargs):
        super(DiePreparationProcess, self).__init__(**kwargs)
        calculate_nav_buttons(
            self.exit_button_label,
            self.exit_button_background,
            self.next_button_label,
            self.next_button_background
        )

    def on_pre_enter(self):
        """Defines what happens just before the screen is being entered into.
        """
        # Set up all of the buttons
        self.button_1 = [
            self.button_1_left_end,
            self.button_1_middle,
            self.button_1_right_end,
            self.button_1_icon,
            self.button_1_label,
            self.button_1_area,
        ]

        self.button_2 = [
            self.button_2_left_end,
            self.button_2_middle,
            self.button_2_right_end,
            self.button_2_icon,
            self.button_2_label,
            self.button_2_area,
        ]

        # Hide all of the buttons
        self.button_1_area.hidden = True
        self.button_2_area.hidden = True
        self.screen_1()

    # > All of the screens defined below correspond to the steps of the process
    # > which are described in the file the processes are described in. They
    # > are left with the [summary] placeholders here because the steps might
    # > still change a little so it was a bit pointless to write all of their
    # > descriptions here right now.

    def screen_1(self):
        """[summary]
        """
        self.screen_text.text = DIE_PREPARATION["screen_1"][self.manager.lang]
        bind_callback(self.next_button, self.screen_2)

    def screen_2(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_PREPARATION["screen_2"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_3)

    def screen_3(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_PREPARATION["screen_3"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_4)

    def screen_4(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_PREPARATION["screen_4"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_5)

    def screen_5(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_PREPARATION["screen_5"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_6)

    def screen_6(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_PREPARATION["screen_6"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_7)

    def screen_7(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_PREPARATION["screen_7"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_8)

    def screen_8(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_PREPARATION["screen_8"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_9)

    def screen_9(self, *args):
        """[summary]
        """

        def _casting_process(*args):
            """Takes user to the Die Casting process.
            Not implemented yet, right now it only takes the user to the main
            menu as if the process was just finished.
            It is required to move the user to a preprocess screen, sync
            Bluetooth and then start the casting process.
            """
            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)
            self.manager.current = "main"

        def _finish_process(*args):
            """Takes user back to the main screen.
            """
            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)
            self.manager.current = "main"

        self.screen_text.text = DIE_PREPARATION["screen_9"][self.manager.lang]

        self.button_1_label.text = PROCESS_COMMON["casting"][self.manager.lang]
        self.button_1_icon.source = ICON_BUTTON_START_CASTING_PROCESS
        self.button_2_label.text = PROCESS_COMMON["finish"][self.manager.lang]
        self.button_2_icon.source = ICON_BUTTON_ACCEPT

        calculate_button_inner_layout(self.button_1)
        calculate_button_inner_layout(self.button_2)
        calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)

        self.button_1_area.disabled = False
        self.button_2_area.disabled = False
        bind_callback(self.button_1, _casting_process)
        bind_callback(self.button_2, _finish_process)
        self.next_button.disabled = True
        unbind_all_callbacks(self.next_button)
