from kivy.lang import Builder
from kivy.uix.screenmanager import Screen
from kivy.properties import ObjectProperty

from Buttons import (
    bind_callback,
    unbind_all_callbacks,
    calculate_button_inner_layout,
    calculate_one_button_layout,
    calculate_two_button_layout,
    calculate_recycled_material_buttons_layout,
    calculate_nav_buttons,
)
from Constants import (
    OPACITY_ZERO,
    OPACITY_FULL,
    OPACITY_WARNING
)
from Images import (
    ICON_BUTTON_ACCEPT,
    ICON_BUTTON_CANCEL,
    ICON_BUTTON_REPEAT,
    ICON_BUTTON_START_HEATING_CRUCIBLE,
    ICON_BUTTON_HOME_LEFT_DIE,
    ICON_BUTTON_HOME_RIGHT_DIE,
    ICON_BUTTON_CLOSE_DIES,
    ICON_BUTTON_OPEN_DIES,
    ICON_BUTTON_START_CASTING_PROCESS
)
from Strings import (
    PROCESS_COMMON,
    DIE_METAL_CASTING,
    CM3
)

Builder.load_file("screens/processes/die/DieMetalCastingProcess.kv")


class DieMetalCastingProcess(Screen):
    """Implementation of the Die Metal Casting process.
    Each function which name starts with "screen" corresponds
    to following process' steps.
    """
    exit_button_background = ObjectProperty(None)
    exit_button_label = ObjectProperty(None)
    next_button_background = ObjectProperty(None)
    next_button_label = ObjectProperty(None)
    next_button = ObjectProperty(None)
    warning_triangle = ObjectProperty(None)
    centered_text = ObjectProperty(None)
    screen_text = ObjectProperty(None)
    recycled_material_buttons_layout = ObjectProperty(None)
    button_0_background = ObjectProperty(None)
    button_0_label = ObjectProperty(None)
    button_0_area = ObjectProperty(None)
    button_10_background = ObjectProperty(None)
    button_10_label = ObjectProperty(None)
    button_10_area = ObjectProperty(None)
    button_20_background = ObjectProperty(None)
    button_20_label = ObjectProperty(None)
    button_20_area = ObjectProperty(None)
    button_30_background = ObjectProperty(None)
    button_30_label = ObjectProperty(None)
    button_30_area = ObjectProperty(None)
    button_40_background = ObjectProperty(None)
    button_40_label = ObjectProperty(None)
    button_40_area = ObjectProperty(None)
    button_50_background = ObjectProperty(None)
    button_50_label = ObjectProperty(None)
    button_50_area = ObjectProperty(None)
    button_left_end = ObjectProperty(None)
    button_middle = ObjectProperty(None)
    button_right_end = ObjectProperty(None)
    button_icon = ObjectProperty(None)
    button_label = ObjectProperty(None)
    button_area = ObjectProperty(None)
    button_1_left_end = ObjectProperty(None)
    button_1_middle = ObjectProperty(None)
    button_1_right_end = ObjectProperty(None)
    button_1_icon = ObjectProperty(None)
    button_1_label = ObjectProperty(None)
    button_1_area = ObjectProperty(None)
    button_2_left_end = ObjectProperty(None)
    button_2_middle = ObjectProperty(None)
    button_2_right_end = ObjectProperty(None)
    button_2_icon = ObjectProperty(None)
    button_2_label = ObjectProperty(None)
    button_2_area = ObjectProperty(None)
    time_icon = ObjectProperty(None)
    time_label = ObjectProperty(None)
    setpoint_crucible_icon = ObjectProperty(None)
    setpoint_crucible_label = ObjectProperty(None)
    setpoint_dies_icon = ObjectProperty(None)
    setpoint_dies_label = ObjectProperty(None)

    def __init__(self, **kwargs):
        super(DieMetalCastingProcess, self).__init__(**kwargs)
        calculate_nav_buttons(
            self.exit_button_label,
            self.exit_button_background,
            self.next_button_label,
            self.next_button_background
        )

    def on_pre_enter(self):
        """Defines what happens just before the screen is being entered into.
        """
        self.manager.bcm.bluetooth_connection_required = True

        self.left_die_home_requested = False
        self.right_die_home_requested = False
        self.left_die_homed = False
        self.right_die_homed = False

        # Set up all of the buttons
        self.percentage_buttons = [
            self.button_0_background,
            self.button_0_label,
            self.button_0_area,
            self.button_10_background,
            self.button_10_label,
            self.button_10_area,
            self.button_20_background,
            self.button_20_label,
            self.button_20_area,
            self.button_30_background,
            self.button_30_label,
            self.button_30_area,
            self.button_40_background,
            self.button_40_label,
            self.button_40_area,
            self.button_50_background,
            self.button_50_label,
            self.button_50_area,
        ]

        self.percentage_buttons_list = [
            self.button_0_area,
            self.button_10_area,
            self.button_20_area,
            self.button_30_area,
            self.button_40_area,
            self.button_50_area,
        ]

        self.button = [
            self.button_left_end,
            self.button_middle,
            self.button_right_end,
            self.button_icon,
            self.button_label,
            self.button_area,
        ]

        self.button_1 = [
            self.button_1_left_end,
            self.button_1_middle,
            self.button_1_right_end,
            self.button_1_icon,
            self.button_1_label,
            self.button_1_area,
        ]

        self.button_2 = [
            self.button_2_left_end,
            self.button_2_middle,
            self.button_2_right_end,
            self.button_2_icon,
            self.button_2_label,
            self.button_2_area,
        ]

        # Hide all of the buttons
        for button in self.percentage_buttons_list:
            button.hidden = True
        self.button_area.hidden = True
        self.button_1_area.hidden = True
        self.button_2_area.hidden = True

        self.time_icon.opacity = OPACITY_ZERO
        self.time_label.opacity = OPACITY_ZERO
        self.setpoint_crucible_icon.opacity = OPACITY_ZERO
        self.setpoint_crucible_label.opacity = OPACITY_ZERO
        self.setpoint_dies_icon.opacity = OPACITY_ZERO
        self.setpoint_dies_label.opacity = OPACITY_ZERO
        self.screen_1()

    # > All of the screens defined below correspond to the steps of the process
    # > which are described in the file the processes are described in. They
    # > are left with the [summary] placeholders here because the steps might
    # > still change a little so it was a bit pointless to write all of their
    # > descriptions here right now.

    def screen_1(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_METAL_CASTING["screen_1"][self.manager.lang]
        self.centered_text.text = PROCESS_COMMON["caution"][self.manager.lang]
        self.centered_text.bold = True
        bind_callback(self.next_button, self.screen_2)

    def screen_2(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_METAL_CASTING["screen_2"][self.manager.lang]
        self.screen_text.texture_update()

        self.warning_triangle.opacity = OPACITY_ZERO
        self.centered_text.text = ""
        self.centered_text.size_hint = (0, 0)
        self.centered_text.opacity = OPACITY_ZERO

        self.button_1_label.text = PROCESS_COMMON["no"][self.manager.lang]
        self.button_1_icon.source = ICON_BUTTON_CANCEL
        self.button_2_label.text = PROCESS_COMMON["yes"][self.manager.lang]
        self.button_2_icon.source = ICON_BUTTON_ACCEPT

        calculate_button_inner_layout(self.button_1)
        calculate_button_inner_layout(self.button_2)
        calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)

        self.button_1_area.disabled = False
        self.button_2_area.disabled = False
        bind_callback(self.button_1, self.screen_4)
        bind_callback(self.button_2, self.screen_3)
        self.next_button.disabled = True
        unbind_all_callbacks(self.next_button)

    def screen_3(self, *args):
        """[summary]
        """
        self.manager.ccm.PERCENTAGE_RECYCLED = 0
        self.screen_text.text = DIE_METAL_CASTING["screen_3"][self.manager.lang]
        self.screen_text.texture_update()
        calculate_recycled_material_buttons_layout(self.recycled_material_buttons_layout, self.screen_text)

        for button in self.percentage_buttons_list:
            button.disabled = False
            bind_callback(button, self.screen_4)

        unbind_all_callbacks(self.button_1)
        unbind_all_callbacks(self.button_2)
        self.button_1_area.hidden = True
        self.button_2_area.hidden = True

    def screen_4(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_METAL_CASTING["screen_4"][self.manager.lang]

        for button in self.percentage_buttons_list:
            button.hidden = True
            unbind_all_callbacks(button)

        self.button_1_area.hidden = True
        self.button_2_area.hidden = True
        unbind_all_callbacks(self.button_1)
        unbind_all_callbacks(self.button_2)
        self.next_button.disabled = False
        bind_callback(self.next_button, self.screen_5)

    def screen_5(self, *args):
        """[summary]
        """
        self.new_material_amount_callback()
        self.manager.ccm.bind(WEIGHT=self.new_material_amount_callback)
        unbind_all_callbacks(self.next_button)
        if self.manager.ccm.PERCENTAGE_RECYCLED > 0:
            bind_callback(self.next_button, self.screen_6)
        else:
            bind_callback(self.next_button, self.screen_7)

    def new_material_amount_callback(self, *args):
        """Called when the new material weight changes.
        """
        self.screen_text.text = (
            PROCESS_COMMON["new_material_add"][self.manager.lang]
            + PROCESS_COMMON["new_material_required"][self.manager.lang]
            + str(round(self.manager.ccm.REQUIRED_MATERIAL, 2))
            + CM3
            + "\n\n"
            + PROCESS_COMMON["new_material_measured"][self.manager.lang]
            + str(round(self.manager.ccm.WEIGHT[0] / float(self.manager.dm.DATA_MATERIAL_CASTING_SELECTED[1]), 1))
            + CM3
        )

    def screen_6(self, *args):
        """[summary]
        """
        self.screen_text.opacity = OPACITY_ZERO  # glitch fix
        self.manager.ccm.unbind(WEIGHT=self.new_material_amount_callback)
        self.recycled_material_amount_callback()
        self.screen_text.opacity = OPACITY_FULL  # glitch fix
        self.manager.ccm.bind(WEIGHT=self.recycled_material_amount_callback)
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_7)

    def recycled_material_amount_callback(self, *args):
        """Called when the recycled material weight changes.
        """
        self.screen_text.text = (
            PROCESS_COMMON["recycled_material_add"][self.manager.lang]
            + PROCESS_COMMON["recycled_material_required"][self.manager.lang]
            + str(round(self.manager.ccm.REQUIRED_RECYCLED, 2))
            + CM3
            + "\n\n"
            + PROCESS_COMMON["recycled_material_measured"][self.manager.lang]
            + str(round(self.manager.ccm.WEIGHT[1] / float(self.manager.dm.DATA_MATERIAL_CASTING_SELECTED[1]), 1))
            + CM3
        )

    def screen_7(self, *args):
        """[summary]
        """
        self.manager.ccm.unbind(WEIGHT=self.new_material_amount_callback)
        self.manager.ccm.unbind(WEIGHT=self.recycled_material_amount_callback)
        self.screen_text.text = DIE_METAL_CASTING["screen_7"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_8)

    def screen_8(self, *args):
        """[summary]
        """

        def _begin_heating(*args):
            """Heating of the crucible and dies will be called by this function
            some day. Right now it only changes the UI.
            """
            self.manager.bcm.bluetooth_connection_required = False

            self.time_icon.opacity = OPACITY_FULL
            self.time_label.opacity = OPACITY_FULL
            self.setpoint_crucible_icon.opacity = OPACITY_FULL
            self.setpoint_crucible_label.opacity = OPACITY_FULL
            self.setpoint_dies_icon.opacity = OPACITY_FULL
            self.setpoint_dies_label.opacity = OPACITY_FULL

            self.button_area.hidden = True
            unbind_all_callbacks(self.button)
            self.next_button.disabled = False
            bind_callback(self.next_button, self.screen_9)

        self.screen_text.text = DIE_METAL_CASTING["screen_8"][self.manager.lang]

        self.button_label.text = PROCESS_COMMON["begin_process"][self.manager.lang]
        self.button_icon.source = ICON_BUTTON_START_HEATING_CRUCIBLE

        calculate_button_inner_layout(self.button)
        calculate_one_button_layout(self.button, self.screen_text)

        self.button_area.disabled = False
        bind_callback(self.button, _begin_heating)
        self.next_button.disabled = True
        unbind_all_callbacks(self.next_button)

    def screen_9(self, *args):
        """[summary]
        """

        def _home_left_die(*args):
            """Homing of the left die will be called by this function some day.
            Right now it only changes the UI.
            """
            self.left_die_home_requested = True
            self.left_die_homed = True
            self.button_1_area.hidden = True
            unbind_all_callbacks(self.button_1)
            if self.right_die_home_requested and self.right_die_homed:
                self.next_button.disabled = False
                bind_callback(self.next_button, self.screen_10)

        def _home_right_die(*args):
            """Homing of the right die will be called by this function some day.
            Right now it only changes the UI.
            """
            self.right_die_home_requested = True
            self.right_die_homed = True
            self.button_2_area.hidden = True
            unbind_all_callbacks(self.button_2)
            if self.left_die_home_requested and self.left_die_homed:
                self.next_button.disabled = False
                bind_callback(self.next_button, self.screen_10)

        self.screen_text.text = DIE_METAL_CASTING["screen_9"][self.manager.lang]

        self.screen_text.parent.height -= 80

        self.button_1_label.text = PROCESS_COMMON["home_left_die"][self.manager.lang]
        self.button_1_icon.source = ICON_BUTTON_HOME_LEFT_DIE
        self.button_2_label.text = PROCESS_COMMON["home_right_die"][self.manager.lang]
        self.button_2_icon.source = ICON_BUTTON_HOME_RIGHT_DIE

        calculate_button_inner_layout(self.button_1)
        calculate_button_inner_layout(self.button_2)
        calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)

        self.button_1_area.disabled = False
        self.button_2_area.disabled = False
        bind_callback(self.button_1, _home_left_die)
        bind_callback(self.button_2, _home_right_die)
        self.next_button.disabled = True
        unbind_all_callbacks(self.next_button)

    def screen_10(self, *args):
        """[summary]
        """

        def _close_dies(*args):
            """Closing of the dies will be called by this function some day.
            Right now it only changes the UI.
            """
            self.button_area.hidden = True
            unbind_all_callbacks(self.button)
            self.next_button.disabled = False
            bind_callback(self.next_button, self.screen_11)

        self.screen_text.text = DIE_METAL_CASTING["screen_10"][self.manager.lang]
        self.button_label.text = PROCESS_COMMON["close_dies"][self.manager.lang]

        self.button_icon.source = ICON_BUTTON_CLOSE_DIES

        calculate_button_inner_layout(self.button)
        calculate_one_button_layout(self.button, self.screen_text)

        self.button_area.disabled = False
        bind_callback(self.button, _close_dies)
        self.next_button.disabled = True
        unbind_all_callbacks(self.next_button)

    def screen_11(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_METAL_CASTING["screen_11"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_12)

    def screen_12(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_METAL_CASTING["screen_12"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_13)

    def screen_13(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_METAL_CASTING["screen_13"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_14)

    def screen_14(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_METAL_CASTING["screen_14"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_15)

    def screen_15(self, *args):
        """[summary]
        """

        def _start_casting(*args):
            """Starting of the casting action will be called by this function
            some day. Right now it only changes the UI.
            """
            self.button_area.hidden = True
            unbind_all_callbacks(self.button)
            self.next_button.disabled = False
            bind_callback(self.next_button, self.screen_16)

        self.screen_text.text = DIE_METAL_CASTING["screen_15"][self.manager.lang]
        self.button_label.text = PROCESS_COMMON["start_casting"][self.manager.lang]

        self.button_icon.source = ICON_BUTTON_START_CASTING_PROCESS

        calculate_button_inner_layout(self.button)
        calculate_one_button_layout(self.button, self.screen_text)

        self.button_area.disabled = False
        bind_callback(self.button, _start_casting)
        self.next_button.disabled = True
        unbind_all_callbacks(self.next_button)

    def screen_16(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_METAL_CASTING["screen_16"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_17)

    def screen_17(self, *args):
        """[summary]
        """

        def _open_dies(*args):
            """Opening of the dies will be called by this function some day.
            Right now it only changes the UI.
            """
            self.button_area.hidden = True
            unbind_all_callbacks(self.button)
            self.next_button.disabled = False
            bind_callback(self.next_button, self.screen_18)

        self.screen_text.text = DIE_METAL_CASTING["screen_17"][self.manager.lang]
        self.button_label.text = PROCESS_COMMON["open_dies"][self.manager.lang]

        self.button_icon.source = ICON_BUTTON_OPEN_DIES

        calculate_button_inner_layout(self.button)
        calculate_one_button_layout(self.button, self.screen_text)

        self.button_area.disabled = False
        bind_callback(self.button, _open_dies)

        self.next_button.disabled = True
        unbind_all_callbacks(self.next_button)

    def screen_18(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_METAL_CASTING["screen_18"][self.manager.lang]
        self.warning_triangle.opacity = OPACITY_WARNING
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_19)

    def screen_19(self, *args):
        """[summary]
        """
        self.screen_text.text = DIE_METAL_CASTING["screen_19"][self.manager.lang]
        unbind_all_callbacks(self.next_button)
        bind_callback(self.next_button, self.screen_20)

    def screen_20(self, *args):
        """[summary]
        """

        def _repeat_process(*args):
            """Starts this process from the beginning.
            """
            self.button_1_area.hidden = True
            self.button_2_area.hidden = True

            self.warning_triangle.opacity = OPACITY_WARNING
            self.centered_text.size_hint = (None, None)
            self.centered_text.opacity = OPACITY_FULL

            self.screen_text.parent.height += 80

            self.next_button.disabled = False

            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)

            self.screen_1()

        def _finish_process(*args):
            """Takes user back to the main screen.
            """
            self.manager.current = "main"

        self.screen_text.text = DIE_METAL_CASTING["screen_20"][self.manager.lang]
        self.screen_text.texture_update()

        self.warning_triangle.opacity = OPACITY_ZERO
        self.time_icon.opacity = OPACITY_ZERO
        self.time_label.opacity = OPACITY_ZERO
        self.setpoint_crucible_icon.opacity = OPACITY_ZERO
        self.setpoint_crucible_label.opacity = OPACITY_ZERO
        self.setpoint_dies_icon.opacity = OPACITY_ZERO
        self.setpoint_dies_label.opacity = OPACITY_ZERO

        self.button_1_label.text = PROCESS_COMMON["repeat"][self.manager.lang]
        self.button_1_icon.source = ICON_BUTTON_REPEAT
        self.button_2_label.text = PROCESS_COMMON["finish"][self.manager.lang]
        self.button_2_icon.source = ICON_BUTTON_ACCEPT

        calculate_button_inner_layout(self.button_1)
        calculate_button_inner_layout(self.button_2)
        calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)

        self.button_1_area.disabled = False
        self.button_2_area.disabled = False
        bind_callback(self.button_1, _repeat_process)
        bind_callback(self.button_2, _finish_process)
        self.next_button.disabled = True
        unbind_all_callbacks(self.next_button)

    def on_pre_leave(self):
        """In case user breaks the process before the callbacks are unbound,
        they are being unbound here.
        """
        self.manager.ccm.unbind(WEIGHT=self.new_material_amount_callback)
        self.manager.ccm.unbind(WEIGHT=self.recycled_material_amount_callback)
