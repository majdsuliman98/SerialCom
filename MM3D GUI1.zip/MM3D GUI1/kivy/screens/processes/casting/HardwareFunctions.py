import json 
from kivy.clock import Clock
from Constants import OPACITY_FULL, OPACITY_ZERO, SETTINGS_FILE
from Strings import OTHER_STRINGS


def skimming_hardware(self):
    codigo = 'X\n'
    # codigo = '$$\n'
    self.manager.ccm.nucleo_gcode.flushInput() 
    self.manager.ccm.nucleo_gcode.flushOutput()
    self.manager.ccm.nucleo_gcode.write(codigo.encode())

    ssk="1800"
    self.move("C","112","1000")
    # print("Moving Turret")

    # self.move("B","-0.22",ssk)
    # print("Moving Skimmer")
    # print("Down x axis")
    self.move("B","2.80","ssk")
    # print("Moving Skimmer")

    codigo = '$J=G21G91 C-22 F1000\r\n'
    # print("Moving Turret")
    
    self.move("B","-0.10",ssk)
    # print("Moving Skimmer")
    
    self.move("C","-18","1000")
    # print("Moving Turret")

    self.move("B","-0.10",ssk)
    # print("Moving Skimmer")

    self.move("C","-4","1000")
    # print("Moving Turret")
    
    self.move("B","1.90",ssk)
    # print("Moving Skimmer")
    
    self.move("C","22","1000")
    # print("Moving Turret")
    
    self.move("B","0.10",ssk)
    # print("Moving Skimmer")
    
    self.move("C","22","1000")
    # print("Moving Turret")

    self.move("B","2.60",ssk)
    # print("Moving Skimmer")

    self.move("C","-112","1000")
    # print("Moving Turret")


def move(self,stepper,pos,speed):
    codigo = '$J=G21G91'+stepper+pos+'F'+speed+'\r\n'
    self.manager.ccm.nucleo_gcode.flushInput() 
    self.manager.ccm.nucleo_gcode.flushOutput()
    self.manager.ccm.nucleo_gcode.write(codigo.encode())


def init_cont_temp(self):
    self.manager.ccm.STATE_T = False 
    self.manager.ccm.last_state_t = self.manager.ccm.STATE_T
    self.temp_cont = Clock.schedule_interval(self.manager.ccm.temp_control, 0.3)

def cancel_cont_temp(self):
    try:
        self.manager.ccm.TEMP_CONTROL= False
        self.temp_cont.cancel()
        # Clock.unschedule(self.temp_cont)
        self.manager.ccm.arduino_control.write(bytes("U" + str(0), "UTF-8"))
        self.manager.ccm.arduino_control.write(bytes("U" + str(2), "UTF-8"))
        self.manager.ccm.arduino_control.write(bytes("U" + str(1), "UTF-8"))
        self.manager.ccm.STATE_T = False 
    except:
        print("No habia event")