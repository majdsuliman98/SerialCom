import json 
from Constants import OPACITY_FULL, OPACITY_ZERO, SETTINGS_FILE
from Strings import OTHER_STRINGS

def show_buttom_right(self):
    """Show 2 icon menu along with its buttons.
    """
    self.screen_text.text = ""
    self.centered_text.text = ""
    self.menu3_button_left.disabled = False
    self.menu3_button_middle.disabled = False
    self.menu3_button_right.disabled = True

    self.menu2_button_left.hidden = True
    self.menu2_button_right.hidden = True
    self.skimming_degassing_icon.opacity = OPACITY_ZERO




def show_menu3(self):
    """Show 2 icon menu along with its buttons.
    """
    self.skimming_degassing_icon.opacity = OPACITY_ZERO
    self.screen_text.text = ""
    self.centered_text.text = ""
    self.menu3_button_left.disabled = False
    self.menu3_button_middle.disabled = False
    self.menu3_button_right.disabled = False

    self.menu2_button_left.hidden = True
    self.menu2_button_right.hidden = True
    self.warning_triangle.opacity = OPACITY_ZERO
    self.manager.ccm.unbind(WEIGHT=self._new_material_amount_callback)
    self.manager.ccm.unbind(WEIGHT=self._recycled_material_amount_callback)


def show_menu2(self):
    """Show 2 icon menu along with its buttons.
    """
    self.screen_text.text = ""
    self.centered_text.text = ""
    self.manager.ccm.unbind(WEIGHT=self._new_material_amount_callback)
    self.manager.ccm.unbind(WEIGHT=self._recycled_material_amount_callback)
    #self.next_button.disabled = False
    self.menu2_button_left.disabled = False
    self.menu2_button_right.disabled = False

    self.menu2_button_left.hidden = False
    self.menu2_button_right.hidden = False


    self.menu3_button_left.hidden = True
    self.menu3_button_right.hidden = True
    self.menu3_button_middle.hidden = True
    self.warning_triangle.opacity = OPACITY_ZERO
    self.skimming_degassing_icon.opacity = OPACITY_ZERO

    self.button_1_area.hidden = True
    self.button_2_area.hidden = True

def hide_menus(self):
    #self.menu3_button_left2.hidden = True
    self.menu3_button_right2.hidden = True
    self.menu3_button_middle2.hidden = True

    self.menu3_button_left.hidden = True
    self.menu3_button_right.hidden = True
    self.menu3_button_middle.hidden = True

    self.menu2_button_left.hidden = True
    self.menu2_button_right.hidden = True

    self.button_1_area.hidden = True
    self.button_2_area.hidden = True

    self.close_monitoring_button.hidden = True

    self.skimming_degassing_icon.opacity = OPACITY_ZERO
    self.time_icon.opacity = OPACITY_ZERO
    self.time_label.opacity = OPACITY_ZERO
    self.screen_text.text = ""
    self.centered_text.text = ""
    self.menu3_label_left2.text = ""
    self.warning_triangle.opacity = OPACITY_ZERO
    self.warning_triangle.opacity = OPACITY_ZERO
    self.time_icon2.opacity = OPACITY_ZERO
    self.time_label2.opacity = OPACITY_ZERO
    self.pressure_icon.opacity = OPACITY_ZERO
    self.pressure_label.opacity = OPACITY_ZERO
    self.setpoint_crucible_icon.opacity = OPACITY_ZERO
    self.setpoint_crucible_label.opacity = OPACITY_ZERO
    self.menu3_icon_left2.opacity = OPACITY_ZERO
    self.manager.ccm.unbind(WEIGHT=self._new_material_amount_callback)
    self.manager.ccm.unbind(WEIGHT=self._recycled_material_amount_callback)

def hide_menu2(self):
    self.menu2_button_left.hidden = True
    self.menu2_button_right.hidden = True


def reset_material(self):
    try:
        with open(SETTINGS_FILE, "r+") as file:
            loaded = json.load(file)
            self.manager.ccm.MATERIAL="null"
            self.manager.ccm.CRUICIBLE_VOLUME = 0
            loaded["material"] = "null"
            loaded["volume"] = 0
        with open(SETTINGS_FILE, "w+") as file:
            json.dump(loaded, file)
        
    except IOError:
        Logger.exception(OTHER_STRINGS["exception_file_read"][self.lang])



def skimming_hardware(self):

    ssk="1800"
    self.move("C","112","1000")
    print("Moving Turret")

    # self.move("B","-0.22",ssk)
    # print("Moving Skimmer")
    # print("Down x axis")
    self.move("B","2.80","ssk")
    print("Moving Skimmer")

    codigo = '$J=G21G91 C-22 F1000\r\n'
    print("Moving Turret")
    
    self.move("B","-0.10",ssk)
    print("Moving Skimmer")
    
    self.move("C","-18","1000")
    print("Moving Turret")

    self.move("B","-0.10",ssk)
    print("Moving Skimmer")

    self.move("C","-4","1000")
    print("Moving Turret")
    
    self.move("B","1.90",ssk)
    print("Moving Skimmer")
    
    self.move("C","22","1000")
    print("Moving Turret")
    
    self.move("B","0.10",ssk)
    print("Moving Skimmer")
    
    self.move("C","22","1000")
    print("Moving Turret")

    self.move("B","2.60",ssk)
    print("Moving Skimmer")

    self.move("C","-112","1000")
    print("Moving Turret")


def move(self,stepper,pos,speed):
    codigo = '$J=G21G91'+stepper+pos+'F'+speed+'\r\n'
    self.manager.ccm.nucleo_gcode.flushInput() 
    self.manager.ccm.nucleo_gcode.flushOutput()
    self.manager.ccm.nucleo_gcode.write(codigo.encode())



    