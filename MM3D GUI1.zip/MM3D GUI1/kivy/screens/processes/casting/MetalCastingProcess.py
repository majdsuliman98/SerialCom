from kivy.app import App
from kivy.lang import Builder
from kivy.clock import Clock
from kivy.uix.screenmanager import Screen
from picamera import PiCamera
from picamera.array import PiRGBArray
from kivy.logger import Logger
import json
import time 
from time import gmtime, strftime
from kivy.properties import ObjectProperty, NumericProperty, ListProperty, BooleanProperty
from MetalCastingProcessUtilities import (
    show_menu3,
    show_menu2,
    hide_menus,
    hide_menu2,
    show_buttom_right,
    reset_material,
)

from Buttons import (
    bind_callback,
    unbind_all_callbacks,
    calculate_button_inner_layout,
    calculate_one_button_layout,
    calculate_two_button_layout,
    calculate_recycled_material_buttons_layout,
    calculate_nav_buttons,
)
from Constants import (
    OPACITY_FULL,
    OPACITY_ZERO,
    OPACITY_WARNING,
    SETTINGS_FILE,
    MELTING_TIME,
    SETPOINT_TEMP,
    PROFILES_DATA_DIR,
    TYPE_ID_SKIMMERS,
    TYPE_ID_NOZZLE,
    TYPE_ID_CRUCIBLE,
    MIN_LIFESPAN_SKIMMER,
    MIN_LIFESPAN_CRUCIBLE,
    MIN_LIFESPAN_NOZZLE
)
from Images import (
    IMAGE_WARNING_TRIANGLE,
    ICON_BUTTON_CANCEL,
    ICON_BUTTON_ACCEPT,
    ICON_BUTTON_REPEAT,
    ICON_BUTTON_FINISH,
    ICON_BUTTON_START_HEATING_CRUCIBLE,
    ICON_MENU_SHUTDOWN,
    ICON_MENU_UTILITIES,
    ICON_MENU_PROCESS,
    ICON_MENU_DIE_CASTING,
    ICON_MENU_INVESTMENT_CASTING,
    ICON_MENU_SAND_CASTING,
    ICON_MENU_LANGUAGE,
    ICON_MENU_INVERT_TO_DARK,
    ICON_MENU_INVERT_TO_LIGHT,
    ICON_MENU_CONSUMABLES,
    ICON_MENU_SETTINGS,
    ICON_MENU_CUSTOM,
    ICON_MENU_DATA,
    ICON_HOME,
    ICON_SKIMMING_AND_DEGASSING,
    ICON_SKIMMING,
    ICON_CONTINUE,
    ICON_MATERIAL_AL,
    ICON_MATERIAL_ZA,
    ICON_CONTINUE,
    ICON_BOTTOM_PANEL_CRUCIBLE,
    ICON_SKIMMING_AND_DEGASSING,
    ICON_START_BUTTON,
    ICON_STOP_BUTTON,
    ICON_MONITOR_BUTON,
    ICON_MELTING_MATERIAL,
    ICON_MENU_CUSTOM_PROFILE,
    ICON_MENU_CUSTOM_PROFILE_PROCESS,
    ICON_MENU_SKIMMER,
    ICON_MENU_NOZZLE,
    ICON_BOTTOM_PANEL_AL,
    ICON_BOTTOM_PANEL_ZA,
    ICON_BOTTOM_PANEL_NULL

)

from Strings import (
    CM3,
    METAL_CASTING,
    PROCESS_COMMON
)
from IconControlManager import(
    icon_material_manager,
    icon_crucible_manager,
    icon_temperature_manager
)

Builder.load_file("screens/processes/casting/MetalCastingProcess.kv")

class MetalCastingProcess(Screen):
    """Implementation of the Investment Metal Casting process.
    Each function which name starts with "screen" corresponds
    to following process' steps.
    """
    # new_material = NumericProperty(0)
    skimming_degassing_icon = ObjectProperty(None)
    back_a_button = ObjectProperty(None)
    close_monitoring_button = ObjectProperty(None)
    menu3_icon_left2 = ObjectProperty(None)
    menu3_label_left2 = ObjectProperty(None)
    #menu3_button_left2 = ObjectProperty(None)
    menu3_icon_middle2 = ObjectProperty(None)
    menu3_label_middle2 = ObjectProperty(None)
    menu3_button_middle2 = ObjectProperty(None)
    menu3_icon_right2 = ObjectProperty(None)
    menu3_label_right2 = ObjectProperty(None)
    menu3_button_right2 = ObjectProperty(None)
    monitoring_layout = ObjectProperty(None)
    close_monitoring_layout = ObjectProperty(None)
    menu3_icon_middle = ObjectProperty(None)
    menu3_label_middle = ObjectProperty(None)
    menu3_button_middle = ObjectProperty(None)
    menu3_icon_right = ObjectProperty(None)
    menu3_label_right = ObjectProperty(None)
    menu3_button_right = ObjectProperty(None)
    centered_textt = ObjectProperty(None)
    menu_loading_icon = ObjectProperty(None)
    menu_loading_label = ObjectProperty(None)
    menu2_icon_left = ObjectProperty(None)
    menu2_label_left = ObjectProperty(None)
    menu2_button_left = ObjectProperty(None)
    menu2_icon_right = ObjectProperty(None)
    menu2_label_right = ObjectProperty(None)
    menu2_button_right = ObjectProperty(None)
    exit_button_background = ObjectProperty(None)
    exit_button_label = ObjectProperty(None)
    next_button_background = ObjectProperty(None)
    next_button_label = ObjectProperty(None)
    next_button = ObjectProperty(None)
    warning_triangle = ObjectProperty(None)
    centered_text = ObjectProperty(None)
    screen_text = ObjectProperty(None)
    # recycled_material_buttons_layout = ObjectProperty(None)
    button_left_end = ObjectProperty(None)
    button_middle = ObjectProperty(None)
    button_right_end = ObjectProperty(None)
    button_icon = ObjectProperty(None)
    button_label = ObjectProperty(None)
    button_area = ObjectProperty(None)
    button_1_left_end = ObjectProperty(None)
    button_1_middle = ObjectProperty(None)
    button_1_right_end = ObjectProperty(None)
    button_1_icon = ObjectProperty(None)
    button_1_label = ObjectProperty(None)
    button_1_area = ObjectProperty(None)
    button_2_left_end = ObjectProperty(None)
    button_2_middle = ObjectProperty(None)
    button_2_right_end = ObjectProperty(None)
    button_2_icon = ObjectProperty(None)
    button_2_label = ObjectProperty(None)
    button_2_area = ObjectProperty(None)
    time_icon = ObjectProperty(None)
    time_label = ObjectProperty(None)
    time_icon2 = ObjectProperty(None)
    time_label2 = ObjectProperty(None)
    setpoint_crucible_icon = ObjectProperty(None)
    setpoint_crucible_label = ObjectProperty(None)
    pressure_icon = ObjectProperty(None)
    pressure_label = ObjectProperty(None)
    brightness = NumericProperty(50)
    contrast = NumericProperty(0)
    exposure_compensation = NumericProperty(0)
    sharpness = NumericProperty(0)
    zoom = ListProperty([0, 0, 1, 1, 1])
    BT_SIGNAL = BooleanProperty(False)

    bottom_material_icon = ObjectProperty(None)
    bottom_crucible_icon = ObjectProperty(None)
    bottom_temperature_icon = ObjectProperty(None)

    def __init__(self, **kwargs):
        super(MetalCastingProcess, self).__init__(**kwargs)
        self._new_material = 0
        self._last_new_material = self._new_material

        self.icon_material_callback()
        self.icon_crucible_callback()
        self.icon_temperature_callback()
        # self.bt_signal = False

        # calculate_nav_buttons(
        #     self.exit_button_label,
        #     self.exit_button_background,
        #     self.next_button_label,
        #     self.next_button_background
        # )

    def on_pre_enter(self):
        self.manager.bcm.bluetooth_connection_required = False
        self.current_screen = "metal_casting"
        # Set up all of the buttons
        self.button = [
            self.button_left_end,
            self.button_middle,
            self.button_right_end,
            self.button_icon,
            self.button_label,
            self.button_area,
        ]

        self.button_1 = [
            self.button_1_left_end,
            self.button_1_middle,
            self.button_1_right_end,
            self.button_1_icon,
            self.button_1_label,
            self.button_1_area,
        ]
        self.button_2 = [
            self.button_2_left_end,
            self.button_2_middle,
            self.button_2_right_end,
            self.button_2_icon,
            self.button_2_label,
            self.button_2_area,
        ]
        self.manager.ccm.bind(STEP_PROCESS = self.step)
        # Hide all of the buttons
        # for element in self.percentage_buttons_list:
        #     element.hidden = True
        self.manager.ccm.bind(MATERIAL=self.icon_material_callback)
        self.manager.ccm.bind(CRUCIBLE_MICROCHIP_EN=self.icon_crucible_callback)
        self.manager.ccm.bind(CRUCIBLE_TILTED=self.icon_crucible_callback)
        self.manager.ccm.bind(TEMP_CONTROL=self.icon_temperature_callback)
        self.manager.ccm.bind(CRUCIBLE_MICROCHIP_EN=self.icon_temperature_callback)

        self.button_area.hidden = True
        self.button_1_area.hidden = True
        self.button_2_area.hidden = True
        self.manager.ccm.CRUCIBLE_TILTED = False

        self.warning_triangle.opacity = OPACITY_ZERO
        self.time_icon.opacity = OPACITY_ZERO
        self.time_label.opacity = OPACITY_ZERO
        self.time_icon2.opacity = OPACITY_ZERO
        self.time_label2.opacity = OPACITY_ZERO
        self.setpoint_crucible_icon.opacity = OPACITY_ZERO
        self.setpoint_crucible_label.opacity = OPACITY_ZERO
        self.pressure_icon.opacity = OPACITY_ZERO
        self.pressure_label.opacity = OPACITY_ZERO
        self.hide_menus()
        self.screen_1()

    # > All of the screens defined below correspond to the steps of the process
    # > which are described in the file the processes are described in. They
    # > are left with the [summary] placeholders here because the steps might
    # > still change a little so it was a bit pointless to write all of their
    # > descriptions here right now.
# S SCREEN 1

    def step(self, *args):
        Logger.info(f"MetalCastingProcess: Step: {self.manager.ccm.STEP_PROCESS}")
        try:
            self.manager.mqtt.share_process_data_mqtt()
            # self.manager.bcm.share_process_data()
        except Exception as exception:
            #todo: ADD ACTION WHAT TO DO WHEN THERE IS NO BLUETOOTH CONECTION
            Logger.exception("MetalCastingProcess: No connection present to share process data")

        

    def screen_1(self, *args):
        """[summary]
        """
        def _change_hardware(*args):
            self.change_hardware(TYPE_ID_CRUCIBLE)
        
        def _aluminum(*args):
            # print("Se elige aluminum")
            if self.manager.ccm.MATERIAL == "za":
                self.wrong_material()
            elif self.manager.ccm.MATERIAL == "null":
                try:
                    with open(SETTINGS_FILE, "r+") as file:
                        loaded = json.load(file)
                        loaded["material"] = "al"
                    self.manager.ccm.MATERIAL ="al"
                    with open(SETTINGS_FILE, "w+") as file:
                        json.dump(loaded, file)
                except:
                    Logger.debug("Metal Casting: ")
                self.manager.ccm.SETPOINT_CRUCIBLE = SETPOINT_TEMP["al"]
                print(SETPOINT_TEMP["al"])
                self.screen_2()
            else:
                #Set parameters
                self.screen_2()
                self.manager.ccm.SETPOINT_CRUCIBLE = SETPOINT_TEMP["al"]

        def _z_aluminum(*args):
            # print("Se elige zinc-aluminum")
            if self.manager.ccm.MATERIAL == "al":
                self.wrong_material()
            elif self.manager.ccm.MATERIAL == "null":
                try:
                    with open(SETTINGS_FILE, "r+") as file:
                        loaded = json.load(file)
                        loaded["material"] = "za"
                    self.manager.ccm.MATERIAL ="za"
                    with open(SETTINGS_FILE, "w+") as file:
                        json.dump(loaded, file)
                except:
                    pass
                self.manager.ccm.SETPOINT_CRUCIBLE = SETPOINT_TEMP["za"]
                self.open()
            else :
                #Set parameters
                self.open()
                self.manager.ccm.SETPOINT_CRUCIBLE = SETPOINT_TEMP["za"]

        def _back_screen(*args):
            self.manager.ccm.PROCESS_IN_PROGRESS = False
            self.manager.current = "main"

        def _screen_1(*args):
            self.manager.ccm.STEP_PROCESS = "choose_material"
            # self.init_cont_temp()
            self.manager.ccm.TEMP_CONTROL_ON = True

            self.hide_menus()
            self.show_menu2()
            self.button_left_end.disabled = False
            self.back_a_button.disabled = True
            
            unbind_all_callbacks(self.menu2_button_left)
            unbind_all_callbacks(self.menu2_button_right)
            bind_callback(self.menu2_button_left, _aluminum)
            bind_callback(self.menu2_button_right, _z_aluminum)


            self.back_a_button.disabled = False
            unbind_all_callbacks(self.back_a_button)
            bind_callback(self.back_a_button, _back_screen)

            self.centered_text.font_size = 27
            self.menu2_icon_left.source = ICON_MATERIAL_AL
            self.menu2_icon_right.source = ICON_MATERIAL_ZA
            self.menu2_label_left.text = "ALUMINIUM"
            self.menu2_label_right.text = "ZINC-ALUMINIUM"

        def _warning_screen(*args):
            def _set_screen(*args):
                self.hide_menus()
                # self.current_screen = "exceed_material"
                self.warning_triangle.opacity = OPACITY_WARNING
                self.screen_text.text = "The lifespan of the crucible is about to end, to have the best results"+ " and safety in your production, it is highly recommended to change it as"+" soon as possible. If you want to continue the process anyway, press skip."
                self.centered_text.font_size = 27
                self.screen_text.font_size = 30
                self.centered_text.text = "CRUCIBLE LIFESPAN WARNING"
                self.centered_text.bold = True
                self.back_a_button.disabled = True
                self.button_1_label.text = "SKIP"

                self.button_1_icon.source = ICON_BUTTON_FINISH
                self.button_2_label.text = "CHANGE IT"
                self.button_2_icon.source = ICON_BOTTOM_PANEL_CRUCIBLE

                unbind_all_callbacks(self.button_1)
                unbind_all_callbacks(self.button_2)

                calculate_button_inner_layout(self.button_1)
                calculate_button_inner_layout(self.button_2)
                calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)
                self.button_1_area.disabled = False
                self.button_2_area.disabled = False

                bind_callback(self.button_1, _screen_1)
                bind_callback(self.button_2, _change_hardware)

            Clock.schedule_once(_set_screen, -1)



        ok = self.manager.dm.check_up_hardware(TYPE_ID_CRUCIBLE)

        if ok:
            _screen_1()
        else:
            _warning_screen()

# S WRONG MATERIAL
    def wrong_material(self, *args):
        """[summary]
        """
        def _finish_process(*args):
            """Takes user back to the main screen.
            """
            self.manager.ccm.PROCESS_IN_PROGRESS = False
            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)
            self.current_screen = "metal_casting"
            self.manager.current = "main"

        def _change_crucible(*args):
            # self.reset_material()
            self.manager.ccm.PROCESS_IN_PROGRESS = False
            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)
            self.manager.current = "main"

        self.manager.ccm.STEP_PROCESS = "wrong_material"
        self.hide_menus()
        self.current_screen = "wrong_material"
        self.warning_triangle.opacity = OPACITY_WARNING
        self.screen_text.text = "Please change crucible or finish process."
        self.screen_text.font_size = 30
        self.centered_text.text = "THE CRUCIBLE HAS INCOMPATIBLE MATERIAL"
        self.centered_text.bold = True
        self.back_a_button.disabled = False
        unbind_all_callbacks(self.back_a_button)
        bind_callback(self.back_a_button, self.screen_1)

        self.button_1_label.text = "CRUCIBLE"
        self.button_1_icon.source = ICON_BOTTOM_PANEL_CRUCIBLE
        self.button_2_label.text = "FINISH"
        self.button_2_icon.source = ICON_BUTTON_FINISH

        calculate_button_inner_layout(self.button_1)
        calculate_button_inner_layout(self.button_2)
        calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)

        self.button_1_area.disabled = False
        self.button_2_area.disabled = False

        bind_callback(self.button_1, _change_crucible)
        bind_callback(self.button_2, _finish_process)

# S OPEN LATCH 

    def open(self, *args):
        """[summary]
        """       
        def _open(*kargs):
            #print("open latch")
            self.button_2_area.disabled = False
            self.button_1_area.disabled = True
            #>Add material function
            # self.manager.ccm.toggle_output_mcp(dev="LATCH_TOP", state=True)
            self.close_event = Clock.schedule_once(_close_latch, 3)
            # self.manager.hcm.routines('add_material')

        def _close_latch(*kargs):
            #print("close latch")
            self.button_1_area.disabled = False
            # self.manager.ccm.toggle_output_mcp(dev="LATCH_TOP", state=False)

        def _next_screen(*kargs):
            #TODO: Here has to be implemented the condition that if the enstops of the latch are not open you cannot

            # Clock.unschedule(self.close_event)
            self.screen_2()
            # self.manager.ccm.toggle_output_mcp(dev="LATCH_TOP", state=False)
            pass
        
        def _back_screen(*kargs):
            # self.manager.ccm.toggle_output_mcp(dev="LATCH_TOP", state=False)
            Clock.unschedule(self.close_event)
            Clock.unschedule(self.open_latch)
            self.reset_material()
            self.screen_1()

        if self.manager.ccm.CRUCIBLE_VOLUME == 0:
            self.back_a_button.disabled = False
            unbind_all_callbacks(self.back_a_button)
            bind_callback(self.back_a_button, _back_screen)
        else: pass

        #Start temp_control
        # self.manager.ccm.start_temp_control()
        self.hide_menus()
        #Tare loadcells
        self.manager.ccm.ADD_MATERIAL = True
        self.manager.ccm.STEP_PROCESS = "add_material"
        # self.manager.ccm.tare(0)
        # self.manager.ccm.tare(1)
        self.open_latch = Clock.schedule_once(_open, 2)
        self.centered_text.text = "Open the hopper on top of the front door to the foundry"
        self.centered_text.bold = True
        self.centered_text.font_size = 30

        
        self.button_1_label.text = "Retry"
        self.button_1_icon.source = ICON_BUTTON_REPEAT
        self.button_2_label.text = "Continue"
        self.button_2_icon.source = ICON_BUTTON_FINISH

        calculate_button_inner_layout(self.button_1)
        calculate_button_inner_layout(self.button_2)
        calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)
        
        self.button_1_area.disabled = True
        self.button_2_area.disabled = False
        self.button_2_area.disabled = True

        # unbind_all_callbacks(self.button_1)
        unbind_all_callbacks(self.button_2)

        bind_callback(self.button_1, _open)
        bind_callback(self.button_2, _next_screen)

# S SCREEN 2
    def screen_2(self, *args):
        """[summary]
        """
        def _next_screen(*args):
            try:
                self._update_material_db(self._amount, "AL_A356")
                Logger.info("MetalCastingProcess:  AL_A356 update request substract amount---> {str(self._amount)} ")
                # print(self._new_material)
                # print(self.manager.ccm.CRUCIBLE_VOLUME + self._new_material)
                self.manager.ccm.CRUCIBLE_VOLUME += self._new_material
            except Exception as exception:
                Logger.exception("MetalCastingProcess: " + str(exception))
            # self.manager.ccm.toggle_output_mcp(dev="BUZZER_OUTPUT", state=False)
            self.close()

        self.hide_menus()
    #Continue Button
        self.menu3_button_right.disabled = True
        self.menu3_icon_right.source = ICON_CONTINUE
        self.menu3_label_right.text = "CONTINUE"
        unbind_all_callbacks(self.menu3_button_right)
        bind_callback(self.menu3_button_right, _next_screen)
    #Text
        self.centered_text.text = ""
        self.centered_text.bold = True
    #Back button
        self.screen_text.font_size = 35
        self.back_a_button.disabled = False
    #Variables to handle the material update
        self._new_material = 0
        self._last_new_material = self._new_material
        self._amount = 0

        unbind_all_callbacks(self.back_a_button)
        bind_callback(self.back_a_button, self.open)
        self.manager.ccm.bind(WEIGHT=self._new_material_amount_callback)

    def _update_material_db(self, amount, material, *args):
        #todo: hanlde exceptions properly and manage the next steps of the process in case something had gone wrong
        try:
            self.manager.bcm.request_update_material(material, amount)
            Logger.info(f"MetalCastingProcess: {material} update request substract amount---> {str(amount)} ")
        except Exception as exception:
            #todo: ADD ACTION WHAT TO DO WHEN THERE IS NO BLUETOOTH CONECTION
            Logger.exception("MetalCastingProcess: " + str(exception))


#_NEWMATERIAL
    def _new_material_amount_callback(self, *args):
        """Called when the new material weight changes.
        """
        ##TODO: Improve the algorithm to remove the first peak of the weight 
        if round(self.manager.ccm.NEW_VOLUME_MATERIAL) > self._new_material:
            self._new_material = round(self.manager.ccm.NEW_VOLUME_MATERIAL)
            self._amount = self._new_material - self._last_new_material
            print(self._amount)
            if self._amount > 10:
                self._update_material_db(self._amount, "AL_A356")
                self._last_new_material = self._new_material
                self._amount = 0
            else:
                pass
        self.screen_text.text = ("ADD MATERIAL: \n"
        + str(int(round(self._new_material, 0))) + CM3
        + " / " + self.manager.ccm.full_crucible_volume + CM3 + "\n\n\n"
        + "Then press continue and wait \n"
        + "20 sec to melt the material"
        )
        if self.manager.ccm.NEW_VOLUME_MATERIAL > 1:
            self.menu3_button_right.disabled = False
        if (self.manager.ccm.NEW_VOLUME_MATERIAL + self.manager.ccm.CRUCIBLE_VOLUME) > (int(self.manager.ccm.full_crucible_volume) * 0.90):
            self.exceeded_material()  

# S EXCEEDED MATERIAL
    def exceeded_material(self, *args):
        """[summary]
        """
        def _continue(*args):
            """Takes user back to the main screen.
            """
            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)
            self.manager.ccm.toggle_output_mcp(dev="BUZZER_OUTPUT", state=False)
            self.screen_3()

        # try:
        #     with open(SETTINGS_FILE, "r+") as file:
        #         loaded = json.load(file)
        #         self.manager.ccm.CRUCIBLE_VOLUME += self.manager.ccm.NEW_VOLUME_MATERIAL
        #         loaded["volume"] = self.manager.ccm.CRUCIBLE_VOLUME
        #     with open(SETTINGS_FILE, "w+") as file:
        #         json.dump(loaded, file)
        # except:
        #     #todo: hanlde exception properly
        #     pass
        # self.manager.ccm.toggle_output_mcp(dev="BUZZER_OUTPUT",state=True)
        self.hide_menus()
        # self.current_screen = "exceed_material"
        self.warning_triangle.opacity = OPACITY_WARNING
        self.screen_text.text = "Please close the latch and press continue."
        self.screen_text.font_size = 30
        self.centered_text.text = "THE CRUCIBLE HAS ENOUGH MATERIAL"
        self.centered_text.bold = True
        self.back_a_button.disabled = True
        self.button_2_label.text = "CONTINUE"
        self.button_2_icon.source = ICON_BUTTON_FINISH

        unbind_all_callbacks(self.button_1)
        unbind_all_callbacks(self.button_2)

        calculate_button_inner_layout(self.button_1)
        calculate_button_inner_layout(self.button_2)
        calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)

        self.button_1_area.disabled = True
        self.button_2_area.disabled = False
        bind_callback(self.button_2, _continue)

# S CLOSE LATCH 
    def close(self, *args):
        """[summary]
        """       
        def _next_screen(*args):
            self.manager.ccm.ADD_MATERIAL = False
            self.melting()

        self.hide_menus()
        self.centered_text.text = "CLOSE THE HOPPER ON TOP OF THE FRONT DOOR TO THE FOUNDRY"
        self.centered_text.bold = True
        self.centered_text.font_size = 30
        self.button_1_label.text = "Retry"
        self.button_1_icon.source = ICON_BUTTON_REPEAT
        self.button_2_label.text = "Continue"
        self.button_2_icon.source = ICON_BUTTON_FINISH
        calculate_button_inner_layout(self.button_1)
        calculate_button_inner_layout(self.button_2)
        calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)
        self.button_1_area.hidden = True
        self.button_2_area.disabled = False
        #bind_callback(self.button_1, _open)
        unbind_all_callbacks(self.button_1)
        unbind_all_callbacks(self.button_2)
        bind_callback(self.button_2, _next_screen)
        
# S MELTING SCREEN
    def melting(self, *args):
        def _next_screen(*args):
            self.event2.cancel()
            self.manager.ccm.MELTING = False
            self.material()

        def _decrease_time(*args):
            self.count -= 1
            self.time_label.text = str(self.count) +" sec."

        self.manager.ccm.MELTING = True
        self.manager.ccm.STEP_PROCESS = "melting_material"
        self.count=MELTING_TIME
        self.hide_menus()
        self.time_label.text = str(MELTING_TIME)+" sec."
        self.time_icon.opacity = OPACITY_FULL
        self.time_label.opacity = OPACITY_FULL
        # self.current_screen = "melting"
        self.back_a_button.disabled = True
        self.skimming_degassing_icon.source = ICON_MELTING_MATERIAL
        self.skimming_degassing_icon.opacity = OPACITY_FULL
        self.centered_text.text = "MELTING IN PROGRESS"
        self.centered_text.texture_update()
        self.centered_text.bold = True
        self.event1 = Clock.schedule_once(_next_screen, MELTING_TIME)
        self.event2 = Clock.schedule_interval(_decrease_time, 1)

# S MATERIAL SCREEN
    def material(self, *args):
        """[summary]
        """       
        self.hide_menus()
        self.centered_text.text = "DO YOU WANT TO ADD MORE MATERIAL?"
        self.centered_text.bold = True
        self.centered_text.font_size = 30
        self.button_1_label.text = "Add more"
        self.button_1_icon.source = ICON_BUTTON_REPEAT
        self.button_2_label.text = "Continue"
        self.button_2_icon.source = ICON_BUTTON_FINISH

        calculate_button_inner_layout(self.button_1)
        calculate_button_inner_layout(self.button_2)
        calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)
    #<It will block the add more material button if there is more than enough material
        if self.manager.ccm.CRUCIBLE_VOLUME >= (0.80 * int(self.manager.ccm.full_crucible_volume)):
            self.button_1_area.disabled = True
            self.button_2_area.disabled = False
    #>It will block the continue button if there is not enough material,
    #>So, it will force to add more material
        elif self.manager.ccm.CRUCIBLE_VOLUME <= 50: #Here should be the material needed for the piece
            self.button_1_area.disabled = False
            self.button_2_area.disabled = True
        else:
            self.button_1_area.disabled = False
            self.button_2_area.disabled = False

        unbind_all_callbacks(self.button_1)
        unbind_all_callbacks(self.button_2)

        bind_callback(self.button_1, self.open)
        bind_callback(self.button_2, self.screen_3)

# S SCREEN_3
    def screen_3(self, *args):
        
        self.hide_menus()
        self.show_menu3()
        self.manager.ccm.unbind(WEIGHT=self._new_material_amount_callback)

        self.menu3_icon_left.source = ICON_SKIMMING_AND_DEGASSING
        self.menu3_label_left.text = "SKIMMING \n& DEGASSING"

        self.menu3_icon_middle.source = ICON_SKIMMING
        self.menu3_label_middle.text = "SKIMMING"

        self.menu3_icon_right.source = ICON_CONTINUE
        self.menu3_label_right.text = "CONTINUE"
    #back buttion 
        unbind_all_callbacks(self.back_a_button)
        bind_callback(self.back_a_button, self.screen_2)
    #left button 
        unbind_all_callbacks(self.menu3_button_left)
        bind_callback(self.menu3_button_left, self.skimming_degassing_screen)
    #Middle button 
        unbind_all_callbacks(self.menu3_button_middle)
        bind_callback(self.menu3_button_middle, self.skimming_screen)
    #Right button 
        unbind_all_callbacks(self.menu3_button_right)
        bind_callback(self.menu3_button_right, self.screen_4)




# S SKIMMING SCREEN
    def skimming_screen(self, *args):
        #TODO:  Add the function which will do the transition to the next screen or process according with the enstops
        def _next_screen(*args):
            self.manager.ccm.SKIMMING = False
            self.manager.dm.update_hardware_lifespan(TYPE_ID_SKIMMERS, 1)
            self.screen_4()
        def _change_hardware(*args):
            self.change_hardware(TYPE_ID_SKIMMERS)
        def _skimming_screen(*args):
            self.manager.ccm.SKIMMING = True
            self.manager.ccm.STEP_PROCESS = "skimming"
            self.hide_menus()
            # self.current_screen = "skimming"
            self.back_a_button.disabled = True
            self.skimming_degassing_icon.source = ICON_SKIMMING
            self.skimming_degassing_icon.opacity = OPACITY_FULL
            self.centered_text.text = "SKIMMING IN PROGRESS"
            self.centered_text.texture_update()
            self.centered_text.bold = True
            event2 = Clock.schedule_once(_next_screen, 5)

        def _warning_screen(*args):
            self.hide_menus()
            # self.current_screen = "exceed_material"
            self.warning_triangle.opacity = OPACITY_WARNING
            self.screen_text.text = "The lifespan of the skimmer is about to end, to have the best results"+ " and safety in your production, it is highly recommended to change it as"+" soon as possible. If you want to continue the process anyway, press skip."

            self.screen_text.font_size = 30
            self.centered_text.text = "SKIMMER LIFESPAN WARNING"
            self.centered_text.bold = True
            self.back_a_button.disabled = True
            self.button_1_label.text = "SKIP"
            self.button_1_icon.source = ICON_BUTTON_FINISH
            self.button_2_label.text = "CHANGE IT"
            self.button_2_icon.source = ICON_MENU_SKIMMER

            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)

            calculate_button_inner_layout(self.button_1)
            calculate_button_inner_layout(self.button_2)
            calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)

            self.button_1_area.disabled = False
            self.button_2_area.disabled = False

            bind_callback(self.button_1, _skimming_screen)
            bind_callback(self.button_2, _change_hardware)

        ok = self.manager.dm.check_up_hardware(TYPE_ID_SKIMMERS)
        if ok:
            _skimming_screen()
        else:
            _warning_screen()



# S SKIMMING & DEGASSING SCREEN
    def skimming_degassing_screen(self, *args):
        #TODO:  Add the function which will do the transition to the next screen or process according with the enstops
        def _next_screen(*args):
            self.manager.ccm.SKIMMING = False
            self.manager.dm.update_hardware_lifespan(TYPE_ID_SKIMMERS, 1)
            self.degassing_screen()
        def _change_hardware(*args):
            self.change_hardware(TYPE_ID_SKIMMERS)
        def _skimming_degassing_screen(*args):
            self.manager.ccm.SKIMMING = True
            self.manager.ccm.STEP_PROCESS = "skimming"
            self.hide_menus()
            # self.current_screen = "skimming"
            self.back_a_button.disabled = True
            self.skimming_degassing_icon.source = ICON_SKIMMING
            self.skimming_degassing_icon.opacity = OPACITY_FULL
            self.centered_text.text = "SKIMMING IN PROGRESS"
            self.centered_text.texture_update()

            self.centered_text.bold = True

            event2 = Clock.schedule_once(_next_screen, 5)

        def _warning_screen(*args):
            self.hide_menus()
            # self.current_screen = "exceed_material"
            self.warning_triangle.opacity = OPACITY_WARNING
            self.screen_text.text = "The lifespan of the skimmer is about to end, to have the best results"+ " and safety in your production, it is highly recommended to change it as"+" soon as possible. If you want to continue the process anyway, press skip."
            self.screen_text.font_size = 30
            self.centered_text.text = "SKIMMER LIFESPAN WARNING"
            self.centered_text.bold = True
            self.back_a_button.disabled = True
            self.button_1_label.text = "SKIP"
            self.button_1_icon.source = ICON_BUTTON_FINISH
            self.button_2_label.text = "CHANGE IT"
            self.button_2_icon.source = ICON_MENU_SKIMMER

            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)

            calculate_button_inner_layout(self.button_1)
            calculate_button_inner_layout(self.button_2)
            calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)

            self.button_1_area.disabled = False
            self.button_2_area.disabled = False

            bind_callback(self.button_1, _skimming_degassing_screen)
            bind_callback(self.button_2, _change_hardware)

        ok = self.manager.dm.check_up_hardware(TYPE_ID_SKIMMERS)

        if ok:
            _skimming_degassing_screen()
        else:
            _warning_screen()

# S DEGASSING
    def degassing_screen(self, *args):
        #TODO:  Add the function which will do the transition to the next screen or process according with the enstops

        def _change_hardware(*args):
            self.change_hardware(TYPE_ID_SKIMMERS)

        def _degassing_screen(*args):
            self.manager.hcm.routines(name="degassing")
            self.manager.ccm.DEGASSING = True
            self.manager.ccm.STEP_PROCESS = "degassing"
            self.hide_menus()
            self.screen_text.text = ""
            # self.current_screen = "degassing"
            self.back_a_button.disabled = True
        #Skimming icon     
            self.skimming_degassing_icon.source = ICON_SKIMMING_AND_DEGASSING
            self.skimming_degassing_icon.opacity = OPACITY_FULL
        #Centered Text
            self.centered_text.text = "DEGASSING IN PROGRESS"
            self.centered_text.texture_update()

            self.centered_text.bold = True
        #Pressure icon 
            self.pressure_icon.opacity = OPACITY_FULL
            self.pressure_label.opacity = OPACITY_FULL
        #Event to change the screen with time
            # event2 = Clock.schedule_once(_next_screen, 4)
        
        def _warning_screen(*args):
            self.hide_menus()
            # self.current_screen = "exceed_material"
            self.warning_triangle.opacity = OPACITY_WARNING
            self.screen_text.text = "The lifespan of the nozzle is about to end, to have the best results"+ " and safety in your production, it is highly recommended to change it as"+" soon as possible. If you want to continue the process anyway, press skip."

            self.screen_text.font_size = 30
            self.centered_text.text = "NOZZLE LIFESPAN WARNING"
            self.centered_text.bold = True
            self.back_a_button.disabled = True
            self.button_1_label.text = "SKIP"
            self.button_1_icon.source = ICON_BUTTON_FINISH
            self.button_2_label.text = "CHANGE IT"
            self.button_2_icon.source = ICON_MENU_NOZZLE

            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)

            calculate_button_inner_layout(self.button_1)
            calculate_button_inner_layout(self.button_2)
            calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)

            self.button_1_area.disabled = False
            self.button_2_area.disabled = False

            bind_callback(self.button_1, _degassing_screen)
            bind_callback(self.button_2, _change_hardware)

        ok = self.manager.dm.check_up_hardware(TYPE_ID_NOZZLE)

        if ok:
            _degassing_screen()
        else:
            _warning_screen()

    def degassing_next_screen(self, *args):
        def _degassing_next_screen(*args):
            self.manager.ccm.DEGASSING = False
            self.manager.dm.update_hardware_lifespan(TYPE_ID_NOZZLE, 1)
            self.screen_4()
        Clock.schedule_once(_degassing_next_screen)


    def change_hardware(self, consumable_hardware_type, *args):
        self.manager.ccm.PROCESS_IN_PROGRESS=False
        if consumable_hardware_type == TYPE_ID_CRUCIBLE:
            self.manager.get_screen("main").current_screen = "crucibles"
            self.manager.current = 'main'

        elif consumable_hardware_type == TYPE_ID_NOZZLE:
            self.manager.get_screen("main").current_screen = "nozzles"
            self.manager.current = 'main'

        elif consumable_hardware_type == TYPE_ID_SKIMMERS:
            self.manager.get_screen("main").current_screen = "skimmers"
            self.manager.current = 'main'



# S SCREEN 4
    def screen_4(self, *args):
        # self.BT_SIGNAL = False
        self.manager.ccm.STEP_PROCESS = "waiting"
        self.hide_menus()   
        self.current_screen = "start process"
        self.time_label2.text ="0 min. 0 sec."
        self.time_icon2.opacity = OPACITY_FULL
        self.time_label2.opacity = OPACITY_FULL
    #Icon profile 
        try:
            if self.manager.get_screen("preprocess").custom == False:
                self.menu3_icon_left2.source = PROFILES_DATA_DIR + "/" + "%s" % self.manager.ccm.NAME_PROFILE +".png"
            else:
                self.menu3_icon_left2.source = ICON_MENU_CUSTOM_PROFILE_PROCESS
        except:
            self.menu3_icon_left2.source = ICON_MENU_CUSTOM_PROFILE_PROCESS
        # self.menu3_icon_left2.source = PROFILES_DATA_DIR + "/" + "%s" % self.manager.ccm.NAME_PROFILE[:-4] + ".png"
        self.menu3_icon_left2.opacity = OPACITY_FULL
        self.menu3_label_left2.align = "centered"
        self.menu3_label_left2.text = self.manager.ccm.NAME_PROFILE+"\n"+str(self.manager.ccm.REQUIRED_MATERIAL)+CM3
    #Pressure icon 
        self.pressure_icon.opacity = OPACITY_ZERO
        self.pressure_label.opacity = OPACITY_ZERO
    #Start Button
        self.menu3_button_middle2.disabled = False
        self.menu3_icon_middle2.source = ICON_START_BUTTON
        self.menu3_label_middle2.text = "START"
        unbind_all_callbacks(self.menu3_button_middle2)
        bind_callback(self.menu3_button_middle2, self.transition_start)
    #Monitor Button
        self.menu3_button_right2.disabled = False
        self.menu3_icon_right2.source = ICON_MONITOR_BUTON
        self.menu3_label_right2.text = "CAMERA FEED"
        unbind_all_callbacks(self.menu3_button_right2)
        bind_callback(self.menu3_button_right2, self.monitoring_screen)
    #back buttion 
        self.back_a_button.disabled = False
        unbind_all_callbacks(self.back_a_button)
        bind_callback(self.back_a_button, self.screen_3)
    #Header text    
        self.centered_text.text = ""
        self.centered_text.bold = True
    #Data text 
        self.screen_text.font_size = 35

        # self.bind(BT_SIGNAL = self.transition_start)

    def transition_start(self, *args):
            #Initialize time
        self.current_min = 0
        self.current_sec = 0
        self.inicio = time.time()
        self.screen_5()

# S SCREEN 5 in process
    def screen_5(self, *args):
        def _increase_time(*args):
            self.fin=time.time()
            self.current_sec=round(self.fin-self.inicio)

            if self.current_sec==60:
                self.current_min+=1
                self.inicio=time.time()
                self.current_sec=0           
            self.time_label2.text = str(self.current_min)+" min. "+str(self.current_sec)+" sec."
        def _set_screen(*args):
            self.hide_menus()
            self.menu3_label_left2.text = self.manager.ccm.NAME_PROFILE+"\n"+str(self.manager.ccm.REQUIRED_MATERIAL)+CM3
            self.current_screen = "process"
            self.manager.ccm.CRUCIBLE_TILTED=True
            self.manager.ccm.STEP_PROCESS = "pouring"
            self.menu3_icon_left2.opacity = OPACITY_FULL
        #Monitor Button
            self.menu3_button_right2.disabled = False
            self.menu3_icon_right2.source = ICON_MONITOR_BUTON
            self.menu3_label_right2.text = "CAMERA FEED"
        #Stop Button
            self.menu3_button_middle2.disabled = False
            self.menu3_icon_middle2.source = ICON_STOP_BUTTON
            self.menu3_label_middle2.text = "STOP"
        #text
            self.screen_text.font_size = 25
        #Time 
            #self.time_icon.opacity = OPACITY_FULL
            #self.time_label.opacity = OPACITY_FULL
            self.time_icon2.opacity = OPACITY_FULL
            self.time_label2.opacity = OPACITY_FULL
            
            

        self.unbind(BT_SIGNAL=self.transition_start)
        self.BT_SIGNAL = False
        Clock.schedule_once(_set_screen)
    #Middle Button 
        unbind_all_callbacks(self.menu3_button_middle2)
        # bind_callback(self.menu3_button_middle2, self.transition_finish )
    #Right button
        unbind_all_callbacks(self.menu3_button_right2)
        # bind_callback(self.menu3_button_right2, self.monitoring_screen)
    #back buttion 
        unbind_all_callbacks(self.back_a_button)
        # self.event4 = Clock.schedule_interval(_increase_time,1)
        # self.bind(BT_SIGNAL = self.transition_finish)

        Clock.schedule_once(self.start_pouring_routine, 1)
    def start_pouring_routine(self, *args):
        pass
        #self.manager.hcm.routines("pouring_routine")
    
    def transition_finish(self, *args):
        # self.unbind(BT_SIGNAL=self.transition_start)
        # self.BT_SIGNAL = False
        # self.manager.hcm.routines("cover")
        self.manager.ccm.CRUCIBLE_TILTED=False
        self.manager.ccm.STEP_PROCESS = ""
        # self.event4.cancel()
        self.screen_20()



# S MONITORING Screen 
    def monitoring_screen(self, *args):
        """Definition of the monitoring Screen.
        """
        def _leave(*args):
            """Takes the user back to the Consumables Screen.
            """
            self.manager.ccm.toggle_led_panel(state= False)
            self.camera.stop_preview()
            self.camera.close()
            self.monitoring_layout.opacity = OPACITY_ZERO
            self.close_monitoring_layout.opacity=OPACITY_ZERO
            self.manager.tpm.video_tab_locked = False
            if self.current_screen == "process":
                self.screen_5()
            elif self.current_screen == "start process":
                self.screen_4()

        def _read_settings(*args):
            """Reads camera settings from JSON file.
            """
            try:
                with open(SETTINGS_FILE, "r+") as file:
                    loaded = json.load(file)

                self.brightness = loaded["brightness"]
                self.contrast = loaded["contrast"]
                self.exposure_compensation = loaded["exposure_compensation"]
                self.sharpness = loaded["sharpness"]
                self.zoom = loaded ["zoom"]
            except:
                print("Failed")

        if self.manager.tpm.video_tab.streaming:
            self.manager.tpm.video_tab.stop_livefeed()

        self.unbind(BT_SIGNAL=self.transition_finish)
        self.BT_SIGNAL = False
        self.manager.ccm.toggle_led_panel(state= True)
        self.hide_menus()
        self.close_monitoring_layout.opacity=OPACITY_FULL-OPACITY_WARNING
        #Close button 
        self.close_monitoring_button.disabled = False
        unbind_all_callbacks(self.close_monitoring_button)
        bind_callback(self.close_monitoring_button, _leave) 
        #widget image
        self.manager.tpm.video_tab_locked = True
        self.monitoring_layout.opacity = OPACITY_FULL
        #Camera 
        self.camera = PiCamera()
        _read_settings()
        self.camera.brightness = self.brightness
        self.camera.contrast = self.contrast
        self.camera.exposure_compensation = self.exposure_compensation
        self.camera.sharpness = self.sharpness   
        self.camera.zoom = self.zoom[0:4]
        self.camera.vflip = False
        self.camera.resolution = (1024, 600)
        #self.camera.exposure_compensation = 16
        self.rawCapture = PiRGBArray(self.camera, size=self.camera.resolution)
        self.camera.start_preview(fullscreen=False, window=(0, 0, 1024, 600))  # x, y, size_x, size_y
        #back buttion 
        unbind_all_callbacks(self.back_a_button)


# S SCREEN_20 END SCREEN
    def screen_20(self, *args):
        """[summary]
        """
        def _repeat_process(*args):
            """Sets up process repetition.
            """
            self.manager.dm.update_hardware_lifespan(TYPE_ID_CRUCIBLE, 5)
            # self.screen_text.parent.height -= 80  # fix
            self.warning_triangle.opacity = OPACITY_WARNING
            self.centered_text.size_hint = (None, None)
            self.centered_text.opacity = OPACITY_FULL
            self.button_1_area.hidden = True
            unbind_all_callbacks(self.button_1)
            self.button_2_area.hidden = True
            unbind_all_callbacks(self.button_2)
            self.open()

        def _finish_process(*args):
            """Takes user back to the main screen.
            """
            self.manager.dm.update_hardware_lifespan(TYPE_ID_CRUCIBLE, 5)
            # self.cancel_cont_temp()
            self.manager.ccm.TEMP_CONTROL_ON = False

            self.manager.ccm.PROCESS_IN_PROGRESS=False
            unbind_all_callbacks(self.button_1)
            unbind_all_callbacks(self.button_2)
            self.manager.current = "main"
            

        def _set_screen(*args):
            self.manager.ccm.CRUCIBLE_TILTED=False
            self.hide_menus()
            
            self.centered_text.text = METAL_CASTING["screen_20"][self.manager.lang]
            self.centered_text.bold = True
            self.centered_text.font_size = 40
            self.centered_text.texture_update()

            self.button_1_label.text = PROCESS_COMMON["repeat"][self.manager.lang]
            self.button_1_icon.source = ICON_BUTTON_REPEAT
            self.button_2_label.text = PROCESS_COMMON["finish"][self.manager.lang]
            self.button_2_icon.source = ICON_BUTTON_FINISH

            calculate_button_inner_layout(self.button_1)
            calculate_button_inner_layout(self.button_2)
            calculate_two_button_layout(self.button_1, self.button_2, self.screen_text)
            self.back_a_button.disable = True
            unbind_all_callbacks(self.back_a_button)
            self.button_1_area.disabled = False
            self.button_2_area.disabled = False

        Clock.schedule_once(_set_screen, -1)


        bind_callback(self.button_1, _repeat_process)
        bind_callback(self.button_2, _finish_process)

        #self.next_button.disabled = False
        #unbind_all_callbacks(self.next_button)
#####
    def screen_6(self, *args):
        """[summary]
        """
        self.manager.ccm.unbind(WEIGHT=self._new_material_amount_callback)
        self._recycled_material_amount_callback()
        self.manager.ccm.bind(WEIGHT=self._recycled_material_amount_callback)
        # unbind_all_callbacks(self.next_button)
       # bind_callback(self.next_button, self.screen_7)
       

    def _recycled_material_amount_callback(self, *args):
        """Called when the recycled material weight changes.
        """
        self.screen_text.text = (
            PROCESS_COMMON["recycled_material_add"][self.manager.lang]
            + PROCESS_COMMON["recycled_material_required"][self.manager.lang]
            + str(round(self.manager.ccm.REQUIRED_RECYCLED, 2))
            + CM3
            + "\n\n"
            + PROCESS_COMMON["recycled_material_measured"][self.manager.lang]
            + str(round(self.manager.ccm.WEIGHT[1] /1, 1))
            + CM3
        )


    def screen_8(self, *args):
        """[summary]
        """
        def _begin_heating(*args):
            """Heating of the crucible will be called by this function
            some day. Right now it only changes the UI.
            """
            self.manager.bcm.bluetooth_connection_required = False

            self.time_icon.opacity = OPACITY_FULL
            self.time_label.opacity = OPACITY_FULL
            self.setpoint_crucible_icon.opacity = OPACITY_FULL
            self.setpoint_crucible_label.opacity = OPACITY_FULL
            self.pressure_icon.opacity = OPACITY_FULL
            self.pressure_label.opacity = OPACITY_FULL

            self.button_area.hidden = True
            unbind_all_callbacks(self.button)
            self.next_button.disabled = False
            bind_callback(self.next_button, self.screen_9)

        self.screen_text.text = METAL_CASTING["screen_8"][self.manager.lang]
        self.button_label.text = PROCESS_COMMON["begin_process"][self.manager.lang]
        self.button_icon.source = ICON_BUTTON_START_HEATING_CRUCIBLE

        calculate_button_inner_layout(self.button)
        calculate_one_button_layout(self.button, self.screen_text)

        self.button_area.disabled = False
        bind_callback(self.button, _begin_heating)
        #self.next_button.disabled = True
        #unbind_all_callbacks(self.next_button)



    def screen_16(self, *args):
        """[summary]
        """

        def _begin_pouring(*args):
            """Pouring from the crucible will be called by this function
            some day. Right now it only changes the UI.
            """
            self.screen_text.parent.height += 80
            self.button_area.hidden = True
            unbind_all_callbacks(self.button)
            #self.next_button.disabled = False
            #bind_callback(self.next_button, self.screen_17)
        self.hide_menus()
        self.screen_text.text = METAL_CASTING["screen_16"][self.manager.lang]

        self.button_label.text = PROCESS_COMMON["begin_process"][self.manager.lang]
        self.button_icon.source = ICON_BUTTON_START_HEATING_CRUCIBLE
        self.screen_text.parent.height -= 80

        calculate_button_inner_layout(self.button)
        calculate_one_button_layout(self.button, self.screen_text)

        self.button_area.disabled = False
        bind_callback(self.button, _begin_pouring)
        #self.next_button.disabled = True
        #unbind_all_callbacks(self.next_button)

    def screen_17(self, *args):
        """[summary]
        """
        self.screen_text.text = METAL_CASTING["screen_17"][self.manager.lang]
        #unbind_all_callbacks(self.next_button)
        #bind_callback(self.next_button, self.screen_18)

    def on_pre_leave(self):
        """In case user breaks the process before the callbacks are unbound,
        they are being unbound here.
        """
        print("leaving")
        self.manager.ccm.unbind(WEIGHT=self._new_material_amount_callback)
        self.manager.ccm.unbind(WEIGHT=self._recycled_material_amount_callback)
        self.manager.ccm.unbind(STEP_PROCESS = self.step)

        self.manager.ccm.unbind(MATERIAL=self.icon_material_callback)
        self.manager.ccm.unbind(CRUCIBLE_MICROCHIP_EN=self.icon_crucible_callback)
        self.manager.ccm.unbind(CRUCIBLE_TILTED=self.icon_crucible_callback)
        self.manager.ccm.unbind(TEMP_CONTROL=self.icon_temperature_callback)
        self.manager.ccm.unbind(CRUCIBLE_MICROCHIP_EN=self.icon_temperature_callback)



#callbacks
    def icon_material_callback(self, *args):
        self.icon_material_manager(self.bottom_material_icon)

    def icon_crucible_callback(self, *args):
        self.icon_crucible_manager(self.bottom_crucible_icon)

    def icon_temperature_callback(self, *args):
        self.icon_temperature_manager(self.bottom_temperature_icon)


## METAL CASTING PROCESS UTILITIES
    def show_menu3(self):
        show_menu3(self)

    def show_menu2(self):
        show_menu2(self)

    def hide_menus(self):
        hide_menus(self)

    def hide_menu2(self):
        hide_menu2(self)

    def show_buttom_right(self):
        show_buttom_right(self)

    def reset_material(self):
        reset_material(self)

                # --------------------------------- IconControl -------------------------------- #
    # ---------------------------- IconControlManager.py ---------------------------- #
    def icon_material_manager(self, icon):
        icon_material_manager(self, icon)

    def icon_crucible_manager(self, icon):
        icon_crucible_manager(self, icon)

    def icon_temperature_manager(self, icon):
        icon_temperature_manager(self, icon)