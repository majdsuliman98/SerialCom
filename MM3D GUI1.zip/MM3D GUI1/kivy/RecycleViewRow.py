from kivy.app import App
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import BooleanProperty, ListProperty, NumericProperty, ObjectProperty, StringProperty

from Buttons import calculate_button_inner_layout_no_icon
from Strings import CONSUMABLE_RV

Builder.load_file("RecycleViewRow.kv")


class RecycleViewRow(BoxLayout):
    """Implementation of a consumable RecycleView row which consists of
    multiple data cells and an adaptive "remove" button for removing
    a selected consumable from the list.
    """
    button_layout = ObjectProperty(None)
    button_left_end = ObjectProperty(None)
    button_middle = ObjectProperty(None)
    button_right_end = ObjectProperty(None)
    button_label = ObjectProperty(None)
    button_button = ObjectProperty(None)

    button_opacity = NumericProperty(1)
    button_disabled = BooleanProperty(False)

    index = NumericProperty()
    serial_id = StringProperty()
    type_id = StringProperty()

    data_1 = StringProperty()
    data_2 = StringProperty()
    data_3 = StringProperty()

    shx_data_1 = NumericProperty(1)
    shx_data_2 = NumericProperty(1)
    shx_data_3 = NumericProperty(1)
    shx_button = NumericProperty(1)

    background_color = ListProperty([0, 0, 0, 1])
    button_ripple_color = ListProperty([0, 0, 0, 1])

    def __init__(self, **kwargs):
        super(RecycleViewRow, self).__init__(**kwargs)
        self.manager = App.get_running_app().root
        self.manager.bind(lang=self.on_lang_change)

        self.button = [
            self.button_left_end,
            self.button_middle,
            self.button_right_end,
            self.button_label,
            self.button_button,
        ]

        self.button_label.text = CONSUMABLE_RV["remove_button"][self.manager.lang]
        self.button_label.texture_update()
        calculate_button_inner_layout_no_icon(self.button)

    def on_lang_change(self, *args):
        """Called on language change, changes the button's label.
        """
        self.button_label.text = CONSUMABLE_RV["remove_button"][self.manager.lang]
        self.button_label.texture_update()
        calculate_button_inner_layout_no_icon(self.button)

    def remove_consumable(self, *args):
        """Prompts user if he wants to remove a selected consumable
        (with a given serial_id unique idenfifier).
        """
        print("Remove Materia: "+ self.data_2)
        # self.manager.tpm.add_tab('confirmation')
        # self.manager.tpm.confirmation_tab.consumable_to_remove = self.serial_id
        # self.manager.bcm.type_id = self.type_id