
from re import M
from threading import Thread, Event
from Faults import ERROR_MICROCHIP_READING
from cbor_eeprom import (
    CBOR_EEPROM
    )

from kivy.logger import Logger
from kivy.event import EventDispatcher

from Constants import (
    ADDRESS_EEPROM,
    BUS_EEPROM,
    MODEL_EEPROM
)
class CrucibleMicrochipManager(EventDispatcher):

    def __init__(self, manager, **kwargs):
        super(CrucibleMicrochipManager, self).__init__(**kwargs)
        self.TAG = 'CrucibleMicrochipManager'
        self.manager = manager
        self.eeprom = None
        self._crucible_volume = 0
        self._crucible_assigned_material = ""
        self._crucible_lifespan = 0

        self.manager.ccm.bind(CRUCIBLE_MICROCHIP_EN=self.read_crucible_data)
        self.read_crucible_data()


    # ---------------------------------------------------------------------------- #
    #                                INITIALIZATION                                #
    # ---------------------------------------------------------------------------- #

    def _initialize_microchip(self):
        try:
            self.eeprom = CBOR_EEPROM(MODEL_EEPROM, BUS_EEPROM, ADDRESS_EEPROM)
            assert self.eeprom.read_file != "", 'Crucible not connected or microchip damaged.'
            return True
        except Exception as e:
            Logger.error(f'{self.TAG}: {e}')
            """TODO: rise exception that the crucible is not connected
            or the microchip is damaged"""
            self.manager.fm.fault_states[
                    self.manager.fm.fault_codes.index(ERROR_MICROCHIP_READING["code"])
                        ] = True
            return False

    def update_crucible_microchip_data(self, volume, material, lifespan):
        def _update_crucible_microchip_data(*args):

            self._initialize_microchip()
            self.eeprom.put('material', material)
            self.eeprom.put('volume', volume)
            self.eeprom.put('lifespan', lifespan)
            Logger.debug(f'{self.TAG}: The crucible data has been updated succesfully!')
        Thread(target=_update_crucible_microchip_data, name="Writting microchip").start()
    
    def read_microchip(self, *args):

        def _read_microchip(*args):
            try:
                if  self._initialize_microchip():
                    self._crucible_assigned_material = self.eeprom.get('material')
                    serie = self.eeprom.get('serie')
                    self._crucible_volume = self.eeprom.get('volume')
                    self._crucible_lifespan = self.eeprom.get('lifespan')
                    Logger.info(f"""{self.TAG}: The current cruicible has the next values
                    No.serie: {serie}\n
                    Material: {self._crucible_assigned_material}\n
                    Volume: {self._crucible_volume} cm\u00B3\n
                    Lifespan: {self._crucible_lifespan} %""")
                    del self.eeprom
                    self.manager.ccm.MATERIAL = self._crucible_assigned_material
                    self.manager.ccm.CRUCIBLE_LIFESPAN = self._crucible_lifespan
                    self.manager.ccm.CRUCIBLE_VOLUME = self._crucible_volume
                    self.manager.dm.update_crucible_local_data(self._crucible_volume, self._crucible_assigned_material ,self._crucible_lifespan)
                    self.manager.fm.fault_states[
                    self.manager.fm.fault_codes.index(ERROR_MICROCHIP_READING["code"])
                        ] = False
            except Exception as e:
                Logger.error(f"CMM: {e}")
                self.manager.fm.fault_states[
                            self.manager.fm.fault_codes.index(ERROR_MICROCHIP_READING["code"])
                        ] = True


        Thread(target=_read_microchip, name="Reading microchip").start()
    
    # ---------------------------------------------------------------------------- #
    #                            MISCELLANOUS FUNCTIONS                            #
    # ---------------------------------------------------------------------------- #

    def read_crucible_data(self, *args):
        if self.manager.ccm.CRUCIBLE_MICROCHIP_EN:
            self.read_microchip()
        else:
            self._crucible_volume = 0
            self._crucible_assigned_material = ""
            self._crucible_lifespan = 0
            self.manager.ccm.MATERIAL = self._crucible_assigned_material
            self.manager.ccm.CRUCIBLE_LIFESPAN = self._crucible_lifespan
            self.manager.ccm.CRUCIBLE_VOLUME = self._crucible_volume
            self.manager.dm.update_crucible_local_data(0, '', 0)


    def write_crucible_data(self, volume, material, lifespan):
        self.update_crucible_microchip_data(volume, material, lifespan)
        self.manager.dm.update_crucible_local_data(volume, material, lifespan)


    def on_quit(self):
        """Called while quitting application. Stop and join the threads
        so they can finish gracefully.
        """
    
