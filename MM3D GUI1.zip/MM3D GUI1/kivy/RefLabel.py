from kivy.uix.label import Label


class RefLabel(Label):
    """Modification of Kivy's Label class which changes "on_ref_press" event
    into "on_ref_release".
    """
    __events__ = ["on_ref_release"]

    def on_touch_up(self, touch):
        if super(Label, self).on_touch_up(touch):
            return True
        if not len(self.refs):
            return False
        tx, ty = touch.pos
        tx -= self.center_x - self.texture_size[0] / 2.0
        ty -= self.center_y - self.texture_size[1] / 2.0
        ty = self.texture_size[1] - ty
        for uid, zones in self.refs.items():
            for zone in zones:
                x, y, w, h = zone
                if x <= tx <= w and y <= ty <= h:
                    self.dispatch("on_ref_release", uid)
                    return True
        return False

    def on_ref_release(self, ref):
        pass
