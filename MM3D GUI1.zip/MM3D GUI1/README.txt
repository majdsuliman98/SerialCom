In this version will be the new configuration for the distribution board.

DQR.
START
19/07/2021