#include "serialwrite.h"
#include "QtSerialPort/QSerialPortInfo"
#include "QSerialPort"
#include "qdebug.h"
#include "QString"

SerialWrite::SerialWrite()
{
    serial = new QSerialPort(this);
    connect(serial,SIGNAL(readyRead()),this,SLOT(writeData()));
    open_port();
}
void SerialWrite::open_port(){

    serial->setPortName("/dev/ttyUSB0");
    serial->open(QIODevice::ReadWrite);

    serial->setBaudRate(QSerialPort::Baud115200);
    serial->setDataBits(QSerialPort::Data8);
    serial->setParity(QSerialPort::NoParity);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setFlowControl(QSerialPort::NoFlowControl);
    if(serial->isOpen()){
            qDebug() << "open";

       }
}


void SerialWrite::writeData(){

    serial->write("ON");





}
