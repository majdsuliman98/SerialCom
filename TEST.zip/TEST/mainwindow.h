#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "sensorread.h"
#include "serialcom.h"
#include "serialwrite.h"


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();



private slots:
    void on_pushButton_clicked();
    void DisplayData(QStringList data_split);
//    void serialRecieved();


private:
    Ui::MainWindow *ui;
    QByteArray Data, buffer;
    QString full_data;
    serialCom com;
    sensorRead info;
    SerialWrite write;


 // serialCom *esp = new serialCom;
friend class serialCom;

};
#endif // MAINWINDOW_H
