#ifndef SERIALWRITE_H
#define SERIALWRITE_H

#include "QSerialPort"
#include "QObject"


class SerialWrite : public QObject
{
    Q_OBJECT;
public:
    SerialWrite();
    void open_port();
public slots:

    void writeData();


private:
    QSerialPort *serial;
};

#endif // SERIALWRITE_H
