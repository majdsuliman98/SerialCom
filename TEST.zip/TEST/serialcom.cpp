//#include "serialcom.h"
//#include "QtSerialPort/QSerialPortInfo"
//#include "QSerialPort"
//#include "qdebug.h"
//#include "QString"
//#include "QMetaObject"
//#include <iostream>


//QSerialPort *serial;
//serialCom::serialCom()
//{
//    serial = new QSerialPort();
//    serial->setPortName("/dev/ttyUSB0");
//    serial->open(QIODevice::ReadWrite);

//    serial->setBaudRate(QSerialPort::Baud115200);
//    serial->setDataBits(QSerialPort::Data8);
//    serial->setParity(QSerialPort::NoParity);
//    serial->setStopBits(QSerialPort::OneStop);
//    serial->setFlowControl(QSerialPort::NoFlowControl);
//    if(serial->isOpen()){
//            qDebug() << "open";

//       }
//   connect(serial,SIGNAL(readyRead()),this,SLOT(serialRecieved()));
//}
//void serialCom::serialRecieved(){

//        Data = serial->readAll();
//        qDebug()<< Data;
//        buffer += Data;
//        if(buffer.contains("\r\n")){
//            full_data = QString(buffer);
//            QStringList data_split = full_data.split(";");
//            buffer = "";
//            Temp = data_split[0].toFloat();
//            temp_crucible_1 = data_split[1].toFloat();
//            error_crucible_1 = data_split[2];
//            temp_crucible_2 = data_split[3].toFloat();
//            error_crucible_2 = data_split[4];
//            pressure = data_split[5].toFloat();
//            qDebug() << full_data;

//        }




//}
