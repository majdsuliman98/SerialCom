#include "serialcom.h"
#include "QtSerialPort/QSerialPortInfo"
#include "QSerialPort"
#include "qdebug.h"
#include "QString"
#include <iostream>
#include "serialcom.h"





serialCom::serialCom()
{
serial = new QSerialPort(this);
connect(serial,SIGNAL(readyRead()),this,SLOT(serialRecieved()));
open_connection();


}

void serialCom::open_connection(){


    serial->setPortName("/dev/ttyUSB0");
    serial->open(QIODevice::ReadWrite);

    serial->setBaudRate(QSerialPort::Baud115200);
    serial->setDataBits(QSerialPort::Data8);
    serial->setParity(QSerialPort::NoParity);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setFlowControl(QSerialPort::NoFlowControl);
    if(serial->isOpen()){
            qDebug() << "open";

       }
}


serialCom::~serialCom(){

    if(serial->isOpen()){
        serial->close();
    }


}
void serialCom::serialRecieved(){

        Data = serial->readAll();
        buffer += Data;
        if(buffer.contains("\r\n")){
            full_data = QString(buffer);
            QStringList data_split = full_data.split(";");
            buffer = "";
            updateData(data_split);

        }




}

void serialCom::updateData(QStringList data_split){


    emit sendData(data_split);
}




