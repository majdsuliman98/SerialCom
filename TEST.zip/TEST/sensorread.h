#ifndef SENSORREAD_H
#define SENSORREAD_H

#include<QObject>

class sensorRead : public QObject
{
public:

    QString Temp, pressure,temp_crucible_1,temp_crucible_2;
    QString error_crucible_1,error_crucible_2;

    sensorRead();
    QString getTemp();
    void assignValues(QStringList list);


};

#endif // SENSORREAD_H
