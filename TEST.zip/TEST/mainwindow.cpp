#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QtSerialPort/QSerialPortInfo"
#include "QSerialPort"
#include "qdebug.h"


QSerialPort *serial;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    if(serial->isOpen()){
        serial->close();
    }
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    serial = new QSerialPort(this);
    serial->setPortName("/dev/ttyUSB0");
    serial->open(QIODevice::ReadWrite);

    serial->setBaudRate(QSerialPort::Baud115200);
    serial->setDataBits(QSerialPort::Data8);
    serial->setParity(QSerialPort::NoParity);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setFlowControl(QSerialPort::NoFlowControl);
    if(serial->isOpen()){
            qDebug() << "open";
//            serial->write("Connected");

       }
  connect(serial,SIGNAL(readyRead()),this,SLOT(serialRecieved()));

}

void MainWindow::serialRecieved(){

        Data = serial->readAll();

        buffer += Data;
        if(buffer.contains("\r\n")){
            full_data = QString(buffer);
            QStringList data_split = full_data.split(";");
            info.assignValues(data_split);
            buffer = "";
            qDebug() << full_data;

            ui->listWidget->addItem("Temp : " + info.Temp);
            ui->listWidget->addItem("temp_crucible_1 : " + info.temp_crucible_1);
            ui->listWidget->addItem("error_crucible_1 : " + info.error_crucible_1);
            ui->listWidget->addItem("temp_crucible_2 : " + info.temp_crucible_2);
            ui->listWidget->addItem("error_crucible_2 : " + info.error_crucible_2);
            ui->listWidget->addItem("pressure : " + info.pressure);
    }
}

//500.3;25.6;0x00;26.3;0x00;20.6;30;22.3;0b000101;0x00;

