#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QtSerialPort/QSerialPortInfo"
#include "QSerialPort"
#include "qdebug.h"
#include "QThread"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    com.serialRecieved();

   connect(&com,SIGNAL(sendData(QStringList)),this,SLOT(DisplayData(QStringList)));


}

MainWindow::~MainWindow()
{

    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    qDebug() << "hahaha";
     ui->listWidget->addItem("CLICKED");


}

void MainWindow::DisplayData(QStringList data_split){

    info.assignValues(data_split);

    ui->listWidget->addItem("Temp : " + info.getTemp() );
    ui->listWidget->addItem("temp_crucible_1 : " + info.temp_crucible_1);
    ui->listWidget->addItem("error_crucible_1 : " + info.error_crucible_1);
    ui->listWidget->addItem("temp_crucible_2 : " + info.temp_crucible_2);
    ui->listWidget->addItem("error_crucible_2 : " + info.error_crucible_2);
    ui->listWidget->addItem("pressure : " + info.pressure);


}

//500.3;25.6;0x00;26.3;0x00;20.6;30;22.3;0b000101;0x00;

