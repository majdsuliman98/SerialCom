//#ifndef SERIALCOM_H
//#define SERIALCOM_H

//#include "QObject"

//class serialCom : public QObject
//{
//    Q_OBJECT
//public:
//    serialCom();

//public slots:

//    void serialRecieved();

//private:

//    float Temp, pressure,temp_crucible_1,temp_crucible_2;
//    QString error_crucible_1,error_crucible_2;

//    QByteArray Data, buffer;
//    QString full_data;
//    QStringList list;


//};

//#endif // SERIALCOM_H
