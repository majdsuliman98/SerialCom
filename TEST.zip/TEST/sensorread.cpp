#include "sensorread.h"
#include "QDebug"

sensorRead::sensorRead()
{

}
void sensorRead::assignValues(QStringList list){

    Temp = list[0];
    temp_crucible_1 = list[1];
    error_crucible_1 = list[2];
    temp_crucible_2 = list[3];
    error_crucible_2 = list[4];
    pressure = list[5];

      qDebug() << Temp;

}

QString sensorRead::getTemp(){

    return Temp;
}
